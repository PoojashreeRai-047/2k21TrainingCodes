package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginObjs 
{
	WebDriver driver;
	public LoginObjs(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
		
	@FindBy(name="username")
	WebElement username;
	public WebElement getUsername() 
	{
		return username;		
	}
	
	@FindBy(name="password")
	WebElement passwd;
	public WebElement getPassword() 
	{
		return passwd;		
	}
	
	@FindBy(css="button[type='submit']")
	WebElement login;
	public WebElement getLogin() 
	{
		return login;		
	}
}
