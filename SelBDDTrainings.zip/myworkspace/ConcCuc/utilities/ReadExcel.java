package utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel 
{
//	static
	public List<String> readExcel()  throws IOException 
	{
		// TODO Auto-generated method stub
		FileInputStream file=new FileInputStream("C:\\Users\\POOJASRA\\AutomationWs2\\eclipse-workspace\\eclipse-workspace\\CucMvnPrjt\\src\\main\\java\\utilities\\Cucmvnexample.xlsx");
		Workbook book=new XSSFWorkbook(file);
		int sheets=book.getNumberOfSheets();
		
//		System.out.println("sheet"+sheets);
		Sheet sheet = book.getSheetAt(0);
//		comes sheet 0= sheet1
		
		Iterator<Row>rows=sheet.iterator();
		
//		List of data v need in testcase
		List<String> excelData=new ArrayList<String>();
		
		while(rows.hasNext())
//			if any row exist in sheet=true
		{
			Row row=rows.next();

			Iterator<Cell>cols=row.cellIterator();
//			goes to next column of that row = next cell
			while(cols.hasNext())
			{
				String data;
				Cell value=cols.next();
//				System.out.println(value);
				          if(value.getCellType()==CellType.NUMERIC)
				          {
//								System.out.println((int)value.getNumericCellValue());
								String result=(int)value.getNumericCellValue()+"";
								excelData.add(result);
							}
				          else
							{
//								System.out.println(value);
								excelData.add(value+"");
								
							}
			}
		}
		return excelData;
	}
//	public static void main(String args[]) throws IOException {System.out.println(readExcel());}
}
