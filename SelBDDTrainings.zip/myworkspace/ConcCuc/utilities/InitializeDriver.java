package utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;

public class InitializeDriver 
{
	public WebDriver driver;
	
	String readDateFile(String data) throws IOException 
	{
		Properties prop=new Properties();
		FileInputStream file=new FileInputStream("C:\\Users\\POOJASRA\\AutomationWs2\\eclipse-workspace\\eclipse-workspace\\CucMvnPrjt\\src\\main\\java\\utilities\\data.properties");
		prop.load(file);
		return prop.getProperty(data);
	}
	
	public String getUrl() throws IOException 
	{
		return this.readDateFile("url");
		
	}
	public void getBrowser() throws IOException 
	{
		String BrowserNAMe= this.readDateFile("browser");
		if(BrowserNAMe.equals("chrome"))
		{
//			Chromesetting
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//			WebDriver driver=new ChromeDriver();  if error rises		
			ChromeOptions co = new ChromeOptions();
			co.addArguments("--remote-allow-origins=*");
			driver = new ChromeDriver(co);
//			System.out.println("Chrome done");
		}
		else 
		{
//			EdgeCode
			System.setProperty("webdriver.edge.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\edgedriver\\msedgedriver.exe");
			driver=new EdgeDriver();
		}
		
	}

}
