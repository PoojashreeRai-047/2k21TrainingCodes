package stepDefinitions;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import cucumber.api.java.*;
import cucumber.api.java.en.*;
import pageObjects.LoginObjs;
import utilities.InitializeDriver;
import utilities.ReadExcel;

public class StepDefinition extends InitializeDriver
{
	LoginObjs lo;
	List<String> data;
	
	@Before
	public void setup() throws IOException
	{
		this.getBrowser();
		System.out.println("Chrome done");
		
		lo=new LoginObjs(driver);
		ReadExcel re=new ReadExcel();
		data=re.readExcel();
	}

 
	@Given("User is on the Website")
	public void user_is_on_the_Website() throws IOException, InterruptedException 
	{
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("++++++++++Given+++++++++");
//		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
//		String url= this.getUrl();
//		Thread.sleep(2000);
		driver.get(getUrl());
	}

/*	@When("Entered Username and Password")
	public void entered_Username_and_Password() throws InterruptedException 
	{
		System.out.println("++++++++++When+++++++++"); Thread.sleep(3000);
		lo.getUsername().sendKeys(data.get(0));
		lo.getPassword().sendKeys(data.get(1));
	}
*/

	@When("Entered Username")
	public void entered_Username() throws InterruptedException 
	{
		System.out.println("++++++++++When+++++++++"); Thread.sleep(3000);
		lo.getUsername().sendKeys(data.get(0));
	}

	@When("Entered Password")
	public void entered_Password() throws InterruptedException 
	{
		System.out.println("++++++++++When+++++++++"); Thread.sleep(3000);
		lo.getPassword().sendKeys(data.get(1));
	}
	@Then("User should login")
	public void user_should_login() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("++++++++++Then+++++++++");
//		driver.findElement(By.cssSelector("button[type='submit']")).click();
		lo.getLogin().click();
		Thread.sleep(3000);
	}
	
/*
 * @Given("^I want to write a step with (.+)$") public void
 * i_want_to_write_a_step_with(String name) throws Throwable {
 * System.out.println("_________________"+name+"_________________"); }
 * 
 * @When("^I check for the (.+) in step$") public void
 * i_check_for_the_in_step(Integer value) throws Throwable {
 * System.out.println("_________________"+value+"_________________"); }
 * 
 * @Then("^I verify the (.+) in step$") public void i_verify_the_in_step(String
 * status) throws Throwable {
 * System.out.println("_________________"+status+"_________________"); }
 */
	
	
	@After
	public void teardown() throws InterruptedException
	{
		Thread.sleep(3000);
//		closing chrome
		driver.close();
	}

}
