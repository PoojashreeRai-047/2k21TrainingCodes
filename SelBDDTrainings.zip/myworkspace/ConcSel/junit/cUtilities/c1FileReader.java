package junit.cUtilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class c1FileReader 
{
//
	public String getURL() throws IOException
	{
		Properties prop=new Properties();
		FileInputStream file=new FileInputStream("C:\\Users\\POOJASRA\\AutomationWs2\\eclipse-workspace\\eclipse-workspace\\ConceptsSelenium\\data.properties");
		prop.load(file);
		return prop.getProperty("url");
	}
}
