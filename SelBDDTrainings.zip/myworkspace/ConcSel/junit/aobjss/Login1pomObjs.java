package junit.aobjss;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Login1pomObjs 
{
//	POM : Page Object Model exammple  By, This.driver
	WebDriver driver;
	public Login1pomObjs(WebDriver driver) 
	{
		this.driver=driver;
	}
	
	
	By username=By.name("username");
	public WebElement usernamee() 
	{
		return driver.findElement(username);
	}
	By pswrd=By.name("password");
	public WebElement pswrdd() 
	{
		return driver.findElement(pswrd);
	}
	By login=By.cssSelector("button[type='submit']");
	public WebElement loginn() 
	{
		return driver.findElement(login);
	}
	
}
