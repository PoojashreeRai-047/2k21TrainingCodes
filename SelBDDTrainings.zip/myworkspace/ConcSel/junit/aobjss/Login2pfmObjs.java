package junit.aobjss;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class Login2pfmObjs 
{
//	PFM: PAge Factory Model   
//	@FindBy(),PageFActory.initElements() or AjaxElemLocatorFactory: pagelevel wait
	WebDriver driver;
	public Login2pfmObjs(WebDriver driver) 
	{
		AjaxElementLocatorFactory factory=new AjaxElementLocatorFactory(driver,10);;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(name="username")
	WebElement user;
	
	public WebElement getusernmm() 
	{
		return user;
	}
	
	@FindBy(name="password")
	WebElement pswd;
	
	public WebElement getpaswrdd() 
	{
		return pswd;
	}
	
	@FindBy(css="button[type='submit']")
	WebElement login;
//	cssSelector("button[type='submit']");
	public WebElement getloginn() 
	{
		return login;
	}
}
