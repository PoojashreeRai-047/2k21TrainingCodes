package junit.btestcases;

import java.io.IOException;
import java.time.Duration;

import org.junit.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import junit.aobjss.Login2pfmObjs;
import junit.cUtilities.c1FileReader;

public class Login2pfmtestcase extends c1FileReader
{
//	PFm TEStCAse
	WebDriver driver;
	
	@Before
	public void setup() 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();  if error rises		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(co);		
		System.out.println("normal webdriver didn't work\nso used chromeOptions");
	}
	@Test
	public void test1() throws InterruptedException, IOException 
	{
		
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(15));
		
//		url>>dataproperties>>filereadercode>> junittest
		String url=this.getURL();
		
		driver.get(url);Thread.sleep(2000);
		driver.manage().window().maximize();
		
		Login2pfmObjs lp=new Login2pfmObjs(driver);
		lp.getusernmm().sendKeys("8908uio");
		lp.getpaswrdd().sendKeys("909opi");
		lp.getloginn().click();
//		29th 1st part 2:35
	}
	@After
	public void teardown() throws InterruptedException 
	{
		Thread.sleep(3000);
//		Closing chrome
		driver.close();
	}

}
