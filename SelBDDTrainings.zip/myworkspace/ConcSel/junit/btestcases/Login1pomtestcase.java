package junit.btestcases;

import java.time.Duration;

import org.junit.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import junit.aobjss.Login1pomObjs;

public class Login1pomtestcase 
{
//	POM : Page Object Model exammple
	WebDriver driver;
	@Before
	public void setup() 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();  if error rises		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(co);		
		System.out.println("normal webdriver didn't work\n so used chromeOptions");
	}
	@Test
	public void test() throws InterruptedException 
	{
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(15));
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");Thread.sleep(2000);
		driver.manage().window().maximize();
		
//		
		Login1pomObjs lo=new Login1pomObjs(driver);
		lo.usernamee().sendKeys("1234uuu");
		lo.pswrdd().sendKeys("ty565783");
		lo.loginn().click();
		
		
	}
	@After
	public void teardown() throws InterruptedException 
	{
		Thread.sleep(3000);
//		Closing chrome
		driver.close();
	}
}
