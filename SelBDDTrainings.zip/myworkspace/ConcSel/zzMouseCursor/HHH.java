package zzMouseCursor;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HHH 
{
	public static void main(String[] args) 
	{
		PangramCode pp=new PangramCode();
	}	
	
	void winHan()
	{
		WebDriver driver=new ChromeDriver();
		driver.get(" ");
		Set<String> winset=driver.getWindowHandles();
		Iterator<String> itr=	winset.iterator();
		
		String winf2=itr.next();
		String winf3=itr.next();
		
		driver.switchTo().window(winf2);
		driver.navigate().back();
	}
	
}

class PangramCode
{
	PangramCode()
	{
		Panagram();
		Anagram("getthere","thereget");
	}
	
	
	void createAnagram(String str)
	{
		
	}
	
	void Anagram(String a1,String a2)
	{
		char[] ar1=a1.toCharArray();
		char[] ar2=a2.toCharArray();
		
		Arrays.sort(ar1);
		Arrays.sort(ar2);
		
		String res=Arrays.equals(ar1, ar2)?"Anagram":"NOT Anagram";
		System.out.println(ar1+" and "+ar2+" are "+res);
	}
	
	void Panagram()
	{
		String s1="The quick brown fox jumps over the lazy dog";
		
		HashSet<Character> h1=new HashSet();
		for(char c:s1.toCharArray())
		{
			if(Character.isLetter(c))
			{
				h1.add(Character.toLowerCase(c));
			}
		}
			
		String res= h1.size()==26? "Pangram":"NOT pangram";
		System.out.println(h1 +"\n and \n"+s1+"\n are a "+res);
		
	}
	
	
	void trial2() 
	{
		String s1="The quick brown fox jumps over the lazy dog";
		String s3=s1.toLowerCase();
		char[] c1=s3.toCharArray();
		///System.out.println(s3);
		String s2="abcdefghijklmnopqrstuvwxyz";
		Set<Character> c2=new HashSet();
		for(int i=1;i<c1.length;i++)
		{
			if(c2.contains(c1[i])) {System.out.println("************"+c2);}
			else{c2.add(c1[i]);}
		}
		System.out.println(c2);
		
	
		
		String res= c1.equals(c2)? "Pangram":"NOT pangram";
		System.out.println(c1 +" and "+c2+" are "+res);
	}
	
    void trail1()
    {
    	String s1="",s2="";
    	char[] c1=s1.toCharArray();
		char[] c2=s2.toCharArray();
		char[] c3;
		// remove dups
		for(int i=0;i>c1.length;i++)
		{
			for(int j=i+1;j>c1.length;j++)
			{
				if(c1[i]!=c1[j])
				{//c3=c3+c1[i];
				
				}
			}
		}
		
		Arrays.sort(c1);Arrays.sort(c2);
		
		
		String res= c1.equals(c2)? "Pangram":"NOT pangram";
		System.out.println(c1 +" and "+c2+" are "+res);
    }

	
}
