package concc.ac;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class c1Xbrwsr 
{
//     Edge And Firefox
	public static void main(String[] args) throws InterruptedException 
	{
//		EdgeCode
		System.setProperty("webdriver.edge.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\edgedriver\\msedgedriver.exe");
		WebDriver driver=new EdgeDriver();
		driver.get("https://www.spicejet.com/");
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.close();
		
//		Firefox
//		webdriver.gecko.driver>> extract geckoDriver>> new FirefoxDriver;
	}
}
