package concc.ac;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class c2CaptchAutomat 
{
// CAptcha Automation
	public static void main(String[] args) throws InterruptedException 
	{
//		Chromesetting
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();  if error rises		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		WebDriver driver = new ChromeDriver(co);
		System.out.println("normal webdriver didn't work\n so used chromeOptions\n");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		driver.get("https://www.orangehrm.com/contact-sales/");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
//		Scrolling- JavaScript
		JavascriptExecutor js= (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,800)");
		System.out.println("Scrolled!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		Thread.sleep(2000);   
		
//		framing
		driver.findElement(By.cssSelector("iframe[title='reCAPTCHA']")).click();
//		driver.findElement(By.id("recaptcha-anchor")).click();
		System.out.println("clicked frame");Thread.sleep(3000);
		driver.close();

	}

}
