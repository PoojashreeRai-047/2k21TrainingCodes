package concc.ab;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class b5ListOptnsMakmytrp 
{
// CLICKING AT A POINT,using JS // working List option using FindElements
	public static void main(String[] args) throws Exception 
	{
//		Chromesetting
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();  if error rises		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		WebDriver driver = new ChromeDriver(co);
		System.out.println("normal webdriver didn't work\n so used chromeOptions\n");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		driver.get("https://www.makemytrip.com/");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("document.elementFromPoint(0,10)");
		System.out.println("clicked");
		
		driver.findElement(By.xpath("//span[normalize-space()='From']")).click();
		driver.findElement(By.cssSelector("input[placeholder='From']")).sendKeys("Delhi");Thread.sleep(3000);
		
//		System.out.println(driver.findElements(By.xpath("//li@role='option'")).get(0).getText()); 
//		driver.findElements(By.xpath("//li@role='option'")).get(0).click();    
//		-----------------------didn't work now--------------------------
	
		driver.findElement(By.xpath("//div[normalize-space()='DEL']")).click(); Thread.sleep(3000);
		
		driver.findElement(By.className("searchToCity")).click();
		driver.findElement(By.cssSelector("input[placeholder='To']")).sendKeys("Mumbai");Thread.sleep(3000);
		
		driver.findElement(By.xpath("//div[normalize-space()='BOM']")).click(); Thread.sleep(3000);
		
		
		
//		Closing chrome
		Thread.sleep(5000);
		driver.close();	
	}

}
