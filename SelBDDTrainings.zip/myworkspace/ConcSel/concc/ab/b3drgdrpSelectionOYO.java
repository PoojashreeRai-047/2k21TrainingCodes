package concc.ab;

import java.time.Duration;
import java.util.List;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

public class b3drgdrpSelectionOYO 
{
//	
	public static void main(String[] args) throws Exception 
	{
//		Chromesetting
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();  if error rises		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		WebDriver driver = new ChromeDriver(co);
		System.out.println("normal webdriver didn't work\n so used chromeOptions\n");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		driver.get("https://www.oyorooms.com/");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
//		date selection
		/*
		 * Scanner sc=new Scanner(System.in); sc.nextInt();Thread.sleep(3000);
		 */
		
//		datePickerDesktop ,  dateRangePicker
		driver.findElement(By.className("datePickerDesktop")).click();
		driver.findElement(By.className("DateRangePicker__PaginationArrowIcon--next")).click();
		
		List<WebElement> dates=driver.findElements(By.className("DateRangePicker__DateLabel"));
	
//		1st Case
		try {
		for(WebElement date: dates) 
		{
			if(date.getText().equals("20")||date.getText().equals("31"))
				date.click();	
				Thread.sleep(3000);		
				}
		}
		catch(Exception e) {}
		
		
//		2nd Case
		
		 WebElement drag = null,drop = null; 
		 boolean isdragselected=false,isdropselected=false; 
		 try 
		 { 
			 for(WebElement date: dates)
			 {
				 if(date.getText().equals("20" )&& isdragselected==false)
				 {drag=date; isdragselected=true;}
				 
				 if(date.getText().equals("30") && isdropselected==false) 
				 {drop=date; isdropselected=true;} 
				 
			 }
		} catch(Exception e) {} 
		 finally 
		 {
			 Actions act= new Actions(driver); 
			 act.dragAndDrop(drag,drop).build().perform();
			 Thread.sleep(3000); 
		 }
		 
//		Closing chrome
		Thread.sleep(3000);
		driver.close();
	}

}
