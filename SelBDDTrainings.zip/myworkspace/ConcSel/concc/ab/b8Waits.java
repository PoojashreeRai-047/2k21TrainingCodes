package concc.ab;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class b8Waits 
{
//Implict Wait, Explicitwait, Fluent wait
//	Pageload-TimeOut Exception
	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();  if error rises		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		WebDriver driver = new ChromeDriver(co);		
		System.out.println("normal webdriver didn't work\n so used chromeOptions");
		
//		---------PAGE LOAD TIME OUT EXCEPTION - need to be b4 the getURL()----------------
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(15));
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");Thread.sleep(2000);
		driver.manage().window().maximize();
		
		
//		------------IMPLICIT WAIT aT  DRIVER- LEVEL------------------ b4 geturl
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
//		           ====> waits until 30secs
		
//		------------EXPLICIT WAIT for element level specified SEPERATELY(duration&Element)----------
		WebElement el1=driver.findElement(By.id(""));
		
		WebDriverWait wait1=new WebDriverWait(driver, Duration.ofSeconds(10));
		wait1.until(ExpectedConditions.elementToBeClickable(el1)).click();
//	                 --------------------------
		WebElement el2=driver.findElement(By.id(""));
		
		WebDriverWait wait2=new WebDriverWait(driver, Duration.ofSeconds(10));
		wait2.until(ExpectedConditions.elementToBeClickable(el2)).click();
//		                    ===> waits until 10secs
		
//		------------FLUENT WAIT-------------
		WebElement el3=driver.findElement(By.id(""));
		Wait<WebDriver> wait3= new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(10))
				.pollingEvery(Duration.ofSeconds(2))
				.ignoring(NoSuchElementException.class);
		wait3.until(ExpectedConditions.elementToBeClickable(el2)).click();
//		           =====> waits 10secs but checks after every 2secs, 5times max for element
		
		
//		Closing Chrome
		Thread.sleep(2000);
		driver.close();
	}

}
