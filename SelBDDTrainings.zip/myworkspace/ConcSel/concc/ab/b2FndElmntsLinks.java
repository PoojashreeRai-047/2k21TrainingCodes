package concc.ab;

import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class b2FndElmntsLinks 
{
//	FindElements: list, iterate, check list is working
	public static void main(String[] args) throws InterruptedException, Exception 
	{
//		Chromesetting
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();  if error rises		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		WebDriver driver = new ChromeDriver(co);
		System.out.println("normal webdriver didn't work\n so used chromeOptions\n");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		Thread.sleep(3000);
	
//		store ID in We, Find All ElementS with a tags, iterate in for loop
		WebElement con = driver.findElement(By.id("pageFooter"));
		List<WebElement> linkz=con.findElements(By.tagName("a"));
		System.out.println(linkz.size());
		
//		200 series is working, 400 series is not working
		
		for(WebElement link:linkz) 
		{
			HttpURLConnection con1= (HttpURLConnection) new URL(link.getAttribute("href")).openConnection();
			con1.setRequestMethod("GET");
			con1.connect();
			
//			200&300 series are working, 400 are not working- Forbidden,500 are server error
			if(con1.getResponseCode()==401||con1.getResponseCode()==402||con1.getResponseCode()==403) 
			{
				System.out.println(link.getText()+": Not Working");
			}
			else 
			{
				System.out.println(link.getText()+": Working");
			}
		}
		
		
		
//		Closing Chrome
		Thread.sleep(3000);
		driver.close();
		
		
	}

}
