package concc.ab;

import java.time.Duration;
import java.util.List;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class b4DDDSpyjet 
{
//	DDD Dynamic Drop Down
	public static void main(String[] args) throws InterruptedException 
	{
//		Chromesetting
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();  if error rises		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		WebDriver driver = new ChromeDriver(co);
		System.out.println("normal webdriver didn't work\n so used chromeOptions\n");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		driver.get("https://www.spicejet.com/");
		driver.manage().window().maximize();
		Thread.sleep(3000);

		Scanner sc=new Scanner(System.in);
		sc.nextInt();Thread.sleep(3000);
//		dynamic dropdown
		driver.findElement(By.xpath("//div[contains(text(),'From')]")).click();	
		try 
		{
			List<WebElement> dd1=driver.findElements(By.className("css-1dbjc4n"));
			for(WebElement dd:dd1)
			{
				if(dd.getText().equals("DEL"))
					dd.click();				
			}
			List<WebElement> dd2=driver.findElements(By.className("css-1dbjc4n"));
			for(WebElement dd:dd2)
			{
				if(dd.getText().equals("BOM"))
					dd.click();				
			}			
		}catch(Exception e) {}
		finally 
		{
//			Closing chrome
			Thread.sleep(5000);
			driver.close();	
		}
		
		/* FINAL OPTION
		 * driver.findElement(By.
		 * xpath("//*[contains(@class,'css-76zvg2') and text()='DEL']")).click();
		 * driver.findElement(By.
		 * xpath("//*[contains(@class,'css-76zvg2') and text()='BOM']")).click(); //
		 * $x("//*[contains(@class,'css-76zvg2') and text()='DEL']")
		 */	}
}
