package concc.ab;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class b6ScrnShotCode 
{
//  add commons-io-2.11.0.jar file for screenshot, 
	public static void main(String[] args) throws InterruptedException, IOException 
	{
//		Chromesetting
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();  if error rises		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		WebDriver driver = new ChromeDriver(co);
		System.out.println("normal webdriver didn't work\n so used chromeOptions\n");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		driver.get("https://www.makemytrip.com/");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
//		ScreenShot code of 2lines
//		run code & refersh project,then scrnsht will be visible
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("./image.png"));		
		System.out.println("****************PNG DONE************");  // png is visible in the eclipse
		
		FileUtils.copyFile(src, new File("./image.jpg"));
		System.out.println("****************JPG DONE************");
		
		FileUtils.copyFile(src, new File("./image.jpeg"));
		System.out.println("****************JPEG DONE************");
//		24th jan 3rd part
		
	}

}
