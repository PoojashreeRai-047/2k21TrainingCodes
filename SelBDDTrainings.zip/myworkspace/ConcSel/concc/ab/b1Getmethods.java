package concc.ab;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class b1Getmethods 
{
//	Get methods: driver level, Element Level
	public static void main(String[] args) throws InterruptedException 
	{
//		Chromesetting
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();  if error rises		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		WebDriver driver = new ChromeDriver(co);
		System.out.println("normal webdriver didn't work\n so used chromeOptions\n");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
//		GetMethods
//		driverlevel
		System.out.println(driver.getCurrentUrl());
		System.out.println(driver.getTitle());
		
//		elementLevel
		WebElement Em=driver.findElement(By.name("login"));
		System.out.println(Em); //dynamic ID  created by selenium for that element
		System.out.println(Em.getAccessibleName());
		System.out.println(Em.getAriaRole());
		System.out.println(Em.getAttribute("class"));
		System.out.println(Em.getCssValue("color"));
		System.out.println("================================");
		System.out.println(Em.getDomAttribute("value"));
		System.out.println(Em.getDomProperty("innerHTML"));
		System.out.println(Em.getTagName());
		System.out.println(Em.getText());
//		================================
		System.out.println(Em.getClass());
		System.out.println(Em.getLocation().getX());
		System.out.println(Em.getRect().getHeight());
		System.out.println(Em.isSelected());
		System.out.println(Em.isDisplayed());
		System.out.println(Em.isEnabled());
		
		
//		System.out.println();
		
//		closing chrome
		Thread.sleep(3000);
		driver.close();
		
	}

}
