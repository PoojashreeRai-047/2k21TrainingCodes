package concc.ab;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class b7LocationBlockChrmOptns 
{
//  Blocking chrome options using Seleinium code
	public static void main(String[] args) throws InterruptedException, AWTException 
	{
//		Chromesetting
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
		
		
		
		/*
		 * // WebDriver driver=new ChromeDriver(); if error rises ChromeOptions co = new
		 * ChromeOptions(); co.addArguments("--remote-allow-origins=*"); WebDriver
		 * driver = new ChromeDriver(co);
		 * System.out.println("normal webdriver didn't work\n so used chromeOptions\n");
		 * driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		 * 
		 * driver.get("https://www.spicejet.com/"); driver.manage().window().maximize();
		 * Thread.sleep(3000);
		 */

		//CODE1
		Map<String, Object> prefs = new HashMap<String, Object>();
		     //add key and value to map as follow to switch off browser notification
		     //Pass the argument 1 to allow and 2 to block
		prefs.put("profile.default_content_setting_values.notifications", 2);
		     //prefs.put("profile.default_content_setting_values.geolocation", 2);          //Create an instance of ChromeOptions
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		    // set ExperimentalOption - prefs
		options.setExperimentalOption("prefs", prefs);
		
		 // WebDriver driver=new ChromeDriver(); if error rises 
//		ChromeOptions co = new ChromeOptions(); 
		options.addArguments("--remote-allow-origins=*"); 
		WebDriver driver = new ChromeDriver(options);
		 System.out.println("normal webdriver didn't work\n so used chromeOptions\n");
		 
		 driver.get("https://www.spicejet.com/");
		
		
		//CODE2  worked!!!!!!!!!!!!
		
//		 Thread.sleep(3000);
		 Robot robot = new Robot();
		 robot.delay(5000);
		 robot.keyPress(KeyEvent.VK_TAB); 
		 robot.keyPress(KeyEvent.VK_ENTER);
		 robot.keyRelease(KeyEvent.VK_TAB); 
		 robot.keyPress(KeyEvent.VK_ENTER);
		 
		 
//		 closing chrome
		 Thread.sleep(3000);
		 driver.close();
		 
	}

}
