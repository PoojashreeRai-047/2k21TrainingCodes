package concc.afSelGrid;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;


public class f1gridpract 
{

	public static void main(String[] args) throws MalformedURLException, InterruptedException 
	{
	/*
	 * Goto selenium downloads >> download selenium serverGrid
	 * cmd:  java --version >>java env var setup
	 * 
	 * Hub-node concept; 28th nov 2021// 2nd part
	 * 
	 * goto filExplorer//Downloads// (location of grid folder)>> type cmd
	 * in cmd type : java -jar selenium-server-4.8.1.jar hub

	 * paste chromedriver in the same folder/drive
	 * open cmd from that Grid folder as node
	 *in cmd type : java -jar selenium-server-4.8.1.jar node --detect-drivers true

	 * HUB console should "Hub started"
	 * Node console should "Node has added"
	 * 
	 * Then Run this code
	 * */

		String baseURL = "https://www.geeksforgeeks.org/";
		String nodeURL = "http://localhost:4444/wd/hub";
		DesiredCapabilities capability =new DesiredCapabilities();
		capability.setBrowserName("chrome");
		capability.setPlatform(Platform.WINDOWS);
		WebDriver driver = new RemoteWebDriver(new URL(nodeURL),capability);
		driver.get(baseURL);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		driver.close();
		
		/*
		 * java -jar selenium-server-4.8.1.jar node --detect-drivers true --port 5544
		 * */

	}

}
