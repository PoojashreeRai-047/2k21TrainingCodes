package concc.aejunitcases;

import java.time.Duration;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
//@TestMethodOrder(OrderAnnotation.class)
public class e1JunitOrdr 
{
//	Junit Practice:
	WebDriver driver;
	@Before
	public void setup() 
	{
//		Chromesetting
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();  if error rises		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(co);
		System.out.println("normal webdriver didn't work\n so used chromeOptions\n");
	}
	
	@Test 
//	@Order(2)
	public void testB() throws InterruptedException 
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));		
		driver.get("https://www.makemytrip.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);                      
		System.out.println("testB");
	}
	@Test 
//	@Order(1)
	public void testA() throws InterruptedException 
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));		
		driver.get("https://www.spicejet.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);                    
		System.out.println("testA\n Alphabetical order of method used for execution");
	}
	
	@After
	public void teardown() 
	{
		System.out.println("After");
//		Closing Chrome
		driver.close();
	}
	
}
