package concc.adselide;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

public class s1Idecode 
{
//	28th dec 2021 1st part
	
	WebDriver driver;
	  private Map<String, Object> vars;
	  JavascriptExecutor js;
	  @Before
	  public void setUp() 
	  {
		  System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//			WebDriver driver=new ChromeDriver();  if error rises		
			ChromeOptions co = new ChromeOptions();
			co.addArguments("--remote-allow-origins=*");
			driver = new ChromeDriver(co);	
		  
//	    driver = new ChromeDriver();
	    js = (JavascriptExecutor) driver;
	    vars = new HashMap<String, Object>();
	  }
	  @After
	  public void tearDown() 
	  {
	    driver.quit();
	  }
	  public String waitForWindow(int timeout) 
	  {
	    try 
	    {
	      Thread.sleep(timeout);
	    }
	    catch (InterruptedException e) 
	    {
	      e.printStackTrace();
	    }
	    Set<String> whNow = driver.getWindowHandles();
	    Set<String> whThen = (Set<String>) vars.get("window_handles");
	    if (whNow.size() > whThen.size()) 
	    {
	      whNow.removeAll(whThen);
	    }
	    return whNow.iterator().next();
	  }
	  @Test
	  public void tst1() 
	  {
	    driver.get("https://www.seleniumframework.com/practiceform/");
	    driver.manage().window().setSize(new Dimension(1296, 688));
	    vars.put("window_handles", driver.getWindowHandles());
	    driver.findElement(By.id("button1")).click();
	    vars.put("win1035", waitForWindow(2000));
	    vars.put("root", driver.getWindowHandle());
	    driver.switchTo().window(vars.get("win1035").toString());
	    driver.close();
	    driver.switchTo().window(vars.get("root").toString());
	    vars.put("window_handles", driver.getWindowHandles());
	    driver.findElement(By.cssSelector("p:nth-child(5) > button")).click();
	    vars.put("win8455", waitForWindow(2000));
	    driver.switchTo().window(vars.get("win8455").toString());
	    driver.close();
	    driver.switchTo().window(vars.get("root").toString());
	    vars.put("window_handles", driver.getWindowHandles());
	    driver.findElement(By.cssSelector("p:nth-child(6) > button")).click();
	    vars.put("win5882", waitForWindow(2000));
	    driver.switchTo().window(vars.get("win5882").toString());
	    driver.switchTo().window(vars.get("root").toString());
	    driver.findElement(By.id("alert")).click();
	    assertEquals(driver.switchTo().alert().getText(),("Please share this website with your friends and in your organization."));
	    driver.findElement(By.id("timingAlert")).click();
	    assertEquals(driver.switchTo().alert().getText(),("Please share this website with your friends and in your organization."));
	    driver.findElement(By.id("colorVar")).click();
	    driver.findElement(By.id("colorVar")).click();
	    driver.findElement(By.id("colorVar")).click();
	    driver.findElement(By.id("colorVar")).click();
	    driver.findElement(By.id("doubleClick")).click();
	    driver.findElement(By.id("doubleClick")).click();
	    {
	      WebElement dragged = driver.findElement(By.id("draga"));
	      WebElement dropped = driver.findElement(By.id("dragb"));
	      Actions builder = new Actions(driver);
	      builder.dragAndDrop(dragged, dropped).perform();
	    }
	    driver.switchTo().window(vars.get("win5882").toString());
	    driver.close();
	    driver.switchTo().window(vars.get("root").toString());
	    driver.close();
	  }
}
