package newprjts;

import java.util.Iterator;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

///// Junit  code for Epass
public class Epass 
{
	WebDriver driver;
	String parWindow,chilWindow;
	
	@Before
	public void setup() 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		driver=new ChromeDriver();   // if error raises
		
		ChromeOptions co= new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		driver=new ChromeDriver(co);
		driver.get("https://www.google.com");
	}
	
	@Test
	public void testcase1() throws InterruptedException 
	{
		driver.manage().window().maximize();
		driver.get("https://telanganaepass.cgg.gov.in/");
		Thread.sleep(5000);
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,400)");
		
		driver.findElement(By.xpath("//a[contains(text(),'Post Matric')]")).click();
		js.executeScript("window.scrollBy(0,400)");
		driver.findElement(By.xpath("/html/body/div[4]/div/div/table/tbody/tr[8]/td[2]/a")).click();
		
		//window handling
		Set<String> windows = driver.getWindowHandles();
		Iterator<String> it=windows.iterator();
		
		parWindow= it.next();
		chilWindow=it.next();
		
//		-------------------------------------------
//		--------------------------------------------
		System.out.println("data to be entered");
		//data to be entered
		WebElement selectdropdown = driver.findElement(By.xpath("/html/body/div[4]/div/div/form/fieldset/div[2]/div/div[3]/div[2]/select"));
		Select ssctype = new Select(selectdropdown);
		ssctype.selectByVisibleText("SSC Regular");
		driver.findElement(By.xpath("/html/body/div[4]/div/div/form/fieldset/div[2]/div/div[2]/div[2]/input")).sendKeys(
		"1502115220");
//		Sscno);
		driver.findElement(By.xpath("/html/body/div[4]/div/div/form/fieldset/div[2]/div/div[1]/div[2]/input")).sendKeys(
		"202008437870");
//		Appno);
		driver.findElement(By.xpath("/html/body/div[4]/div/div/form/fieldset/div[2]/div/div[2]/div[4]/input")).sendKeys(
		"2015");
//		Sscyr);
		driver.findElement(By.xpath("/html/body/div[4]/div/div/form/fieldset/div[2]/div/div[3]/div[4]/input")).sendKeys(
		"04031999");
//		Dob);
		
		WebElement selectAcyr= driver.findElement(By.xpath("/html/body/div[4]/div/div/form/fieldset/div[2]/div/div[1]/div[4]/select"));
		Select Acyr=new Select(selectAcyr);
		Acyr.selectByVisibleText(
		"2020-21");
//		Acdyr);
		
		driver.findElement(By.xpath("/html/body/div[4]/div/div/form/fieldset/div[2]/div/div[4]/div/center/button")).click();
		js=(JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,400)");
		
	}
	
	@After
	public void teardown() throws InterruptedException 
	{
		Thread.sleep(3000);
		driver.close();
		driver.switchTo().window(parWindow);
		driver.close();	
	}
}
