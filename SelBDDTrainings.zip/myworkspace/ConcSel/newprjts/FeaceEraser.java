package newprjts;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class FeaceEraser 
{
	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
		
		WebDriver driver;
		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(co);
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		
		String face="https://www.facebook.com/login/";
		String log="//input[@id='email']";
		String pass="//input[@id='pass']";
		
		String mail="raiarunjyothi824@gmail.com";
		String pwd="OPkl..99";
		
		driver.get(face);
		driver.findElement(By.xpath(log)).sendKeys(mail);
		driver.findElement(By.xpath(pass)).sendKeys(pwd);
		
		String login="//*[@id=\"loginbutton\"]";
		driver.findElement(By.xpath(login)).click();
		wait(2);
//		pop up handling
		
		wait(10);
		String myicon="//*[@id=\"mount_0_0_ua\"]/div/div[1]/div/div[2]/div[5]/div[1]/span/div/div[1]/div/svg/g/image";
		driver.findElement(By.xpath(myicon)).click();
		
		String myname="//span[@class='x193iq5w xeuugli x13faqbe x1vvkbs x1xmvt09 x1lliihq x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x xudqn12 x676frb x1lkfr7t x1lbecb7 x1s688f xzsf02u x1yc453h'][normalize-space()='Elegant Splendo']";
		driver.findElement(By.xpath(myname)).click();
		wait(2);
		
		String posts="//span[@class='x193iq5w xeuugli x13faqbe x1vvkbs x1xmvt09 x1lliihq x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x xudqn12 x3x7a5m x6prxxf xvq8zen x1s688f x1qq9wsj'][normalize-space()='Posts']";
		driver.findElement(By.xpath(posts)).click();
		wait(2);
		
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,400)");
		
		String licj="";
//		driver.findElement(By.xpath())
		for(int i=0; i<=20; i++)
		{
			
		}
	
	}
	
	public static void wait(int n) throws InterruptedException
	{
		int x=n*1000;
		Thread.sleep(x);
	}
}
