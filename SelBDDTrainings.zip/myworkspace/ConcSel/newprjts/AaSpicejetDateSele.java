package newprjts;

import java.time.Duration;

import org.junit.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class AaSpicejetDateSele 
{
//	Junit5 code to select 10th date from SpiceJet WebPage
//	                 and select goa and Amritsar via dynamic drop-down DD
	WebDriver driver;
	@Before
	public void setup() 
	{
//		WebBrowser/chrome setup
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
		
//		WebDriver driver=new ChromeDriver();  //if error rises
		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(co);
		driver.get("https://www.google.com");
		
	}
	@Test
	public void testcase() throws InterruptedException
	{
//		actual testcase
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		String Spicejet="https://www.spicejet.com/";
		driver.get(Spicejet);
		driver.manage().window().maximize();;
	
//       *****Dynamic Drop-down -- DD***********

		String from="//div[contains(text(),'From')]";
		driver.findElement(By.xpath(from)).click();
		
//		normal code /*
//		for dynamic drop we just need to add a delay so that the dd loads properly

		driver.findElement(By.xpath("//input[@data-focusvisible-polyfill='true']")).sendKeys("goa");
		driver.findElement(By.xpath("//div[contains(text(),'Goa (Dabolim)')]")).click();
	
		String to="//input[@data-focusvisible-polyfill='true']";
		System.out.println("ffdflkfdflkd11111");Thread.sleep(5000);

		driver.findElement(By.xpath(to)).sendKeys("Amritsar");	
		driver.findElement(By.xpath("//div[contains(text(),'ATQ')]")).click();
//		may raise no such element exception 
		
		System.out.println("ffdflkfdflkd11111");
		Thread.sleep(3000);
		for(int i=10;i<12;i++)
		{System.out.println("i = "+i);}
		
		System.out.println("odneoddf");
		
//		for date selection we can use normal click operation or drag and drop with Actions class obj 
		
		
		
	}
	@After
	public void teardown() throws InterruptedException
	{
//		Closing the WebBrowser
		Thread.sleep(3000);
		
		driver.close();
		
	}
	
}
