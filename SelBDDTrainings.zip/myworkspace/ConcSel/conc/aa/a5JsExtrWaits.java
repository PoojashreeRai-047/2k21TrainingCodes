package conc.aa;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class a5JsExtrWaits 
{
//	JavascriptExecutor &&& waits &&& ActiveElement Switchto
	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();  if error rises		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		WebDriver driver = new ChromeDriver(co);
		
		driver.get("https://www.tutorialspoint.com/index.htm");	
		driver.manage().window().maximize();
		System.out.println("normal webdriver didn't work\n so used chromeOptions");
		Thread.sleep(2000);
		
//		Scrolling- JavaScript
		JavascriptExecutor js= (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,800)");
		System.out.println("Scrolled!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		Thread.sleep(3000);                                                                      
		
//		Waits: Implicit wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.get("https://www.geeksforgeeks.org/");
		driver.findElement(By.linkText("Sign In")).click();
//		----------------------------SWITCH-TO-ACTIVE-ELEMENT----------------------------
		driver.switchTo().activeElement();
		driver.findElement(By.id("luser")).sendKeys("ererererrerr");
		driver.findElement(By.className("signin-button")).click();
		
//		driver.findElement(By.id("synery")).click();
		
		Thread.sleep(3000);
//		closing Chrome
		driver.close();
	}
}
