package conc.aa;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class a3FormHandling 
{
//	inputbox, radio_buttons,checkboxes, Select class for list of options
	public static void main(String[] args) throws InterruptedException 
	{
//		Chromesetting
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();  if error rises		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		WebDriver driver = new ChromeDriver(co);
		driver.get("https://itera-qa.azurewebsites.net/home/automation");		
		System.out.println("normal webdriver didn't work\n so used chromeOptions");
		
		driver.manage().window().maximize();
//		write name
		driver.findElement(By.id("name")).sendKeys("Rai Poojashree");Thread.sleep(2000);
//		select gender
		driver.findElement(By.id("female")).click();
//		select 3 days
		driver.findElement(By.id("monday")).click();
		driver.findElement(By.id("tuesday")).click();
		driver.findElement(By.id("wednesday")).click();
		
//		Select Class
		WebElement optselctr=driver.findElement(By.className("custom-select"));
		Select country=new Select(optselctr);
		country.selectByIndex(5); Thread.sleep(2000);
		country.selectByValue("2"); Thread.sleep(2000);
		country.selectByVisibleText("Greece"); Thread.sleep(2000);
		
		
//		closing browser
		Thread.sleep(3000);
		driver.close();
	}
}
