package conc.aa;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

public class a6Actnsss 
{
//	Action class, hover, key up and down
	public static void main(String[] args) throws InterruptedException 
	{
//		Chromesetting
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();  if error rises		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		WebDriver driver = new ChromeDriver(co);
		System.out.println("normal webdriver didn't work\n so used chromeOptions");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			
		driver.get("https://www.amazon.in/");		
		driver.manage().window().maximize();
		
//		HOvering
		WebElement button=driver.findElement(By.id("nav-link-accountList")); Thread.sleep(3000);
		Actions actn=new Actions(driver);
		actn.moveToElement(button).build().perform();
		
		System.out.println("Mouse hovering done");	
		
//		press shift through keyboard
		WebElement inpbox=driver.findElement(By.id("twotabsearchtextbox"));
		actn.keyDown(Keys.SHIFT).build().perform();
//		Sendkeys 
		inpbox.sendKeys("hileo");
		
//		release shift
		actn.keyUp(Keys.SHIFT).build().perform();
		inpbox.sendKeys("hileo");
		
//		closing chrome
		Thread.sleep(3000);
		driver.close();
		
		
	}
}
