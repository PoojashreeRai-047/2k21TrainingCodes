package conc.aa;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class a8WindowHandling 
{
//	Window Handling
	public static void main(String[] args) throws InterruptedException 
	{
//		Chromesetting
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();  if error rises		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		WebDriver driver = new ChromeDriver(co);
		System.out.println("normal webdriver didn't work\n so used chromeOptions");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		driver.get("https://engineerdiaries.com/test");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		try 
		{
			driver.findElement(By.xpath("//*[contains(text(),'Advanced')]")).click();
			driver.findElement(By.linkText("Proceed to engineerdiaries.com (unsafe)")).click();
		}
		catch(Exception e) {System.out.println(e);}
		finally 
		{
			JavascriptExecutor js= (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,800)");
			driver.findElement(By.linkText("Visit W3Schools.com!")).click();
			Thread.sleep(3000);
			
//			windowhandle()=> store in Setofstring, itratr() store in Itrt of string
			Set<String> winds=driver.getWindowHandles();
			Iterator<String> itr=winds.iterator();
			String first=itr.next();
			String secnd=itr.next();
			Thread.sleep(2000);
			
//			store both windows with and >> use iterator to move - WH
//			driver.switchTo().window(secnd);Thread.sleep(2000);
			driver.switchTo().window(first);Thread.sleep(2000);
			driver.switchTo().window(secnd); Thread.sleep(2000);driver.close();Thread.sleep(2000);
			driver.switchTo().window(first); driver.close();
			
		}
	
	
	}
}
	
