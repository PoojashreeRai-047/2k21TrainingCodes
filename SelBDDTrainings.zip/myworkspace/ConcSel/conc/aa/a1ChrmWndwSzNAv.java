package conc.aa;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class a1ChrmWndwSzNAv 
{
//	chrome_setting, window(sizing&navigation),
	public static void main(String[] args) throws InterruptedException 
	{
		System.out.println("lets start>>>>>>>>>>>>>");

//		Chromesetting
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();  if error rises		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		WebDriver driver = new ChromeDriver(co);
		driver.get("https://www.tutorialspoint.com/index.htm");		
		System.out.println("normal webdriver didn't work\n so used chromeOptions");
		Thread.sleep(3000);
		
//		windowNavigation
		driver.navigate().to("https://www.tutorialspoint.com/latest/prime-packs"); 
		Thread.sleep(2000);
		driver.navigate().back();
		Thread.sleep(2000);
		driver.navigate().forward();
		Thread.sleep(2000);
		driver.navigate().refresh();
		Thread.sleep(2000);
		
//		window sizing
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.manage().window().minimize();
		Thread.sleep(2000);
		driver.manage().window().fullscreen();
		Thread.sleep(2000);
		driver.manage().window().setSize(new Dimension(320,313));
		Thread.sleep(2000);
		
		System.out.println("closing the chrome");
		driver.close();
	}

}
