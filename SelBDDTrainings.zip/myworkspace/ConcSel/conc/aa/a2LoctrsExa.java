package conc.aa;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class a2LoctrsExa 
{
//	id,name,linktext,partialLinkText,tagname,classname,XPATH,cssSelector
	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();  if error rises		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		WebDriver driver = new ChromeDriver(co);		
		System.out.println("normal webdriver didn't work\n so used chromeOptions");
		
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(15));
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");Thread.sleep(2000);
		driver.manage().window().maximize();
		
//		locators
		driver.findElement(By.name("username")).sendKeys("Admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
		Thread.sleep(2000);
		
		driver.get("https://www.facebook.com/");Thread.sleep(2000);
//		driver.findElement(By.id("email")).sendKeys("122adfd@gmail.com");
//		driver.findElement(By.className("_9npi")).sendKeys("pswswswwswsw");
//		driver.findElement(By.name("login")).click();
//		driver.findElement(By.linkText("Forgotten password?")).click();
//		driver.findElement(By.partialLinkText("Forgo")).click();
//		driver.findElement(By.tagName("button")).click();
//		driver.findElement(By.partialLinkText("Forgo")).click();
//		driver.findElement(By.className("inputtext _9o1w")).sendKeys("12334567"); //compounded classnames are not allowed
//		driver.findElement(By.id("identify_email")).sendKeys("12334567");
		
//		Xpath of Password
//		Full: /html/body/div[1]/div[1]/div[1]/div/div/div/div[2]/div/div[1]/form/div[1]/div[2]/div/input
//		Xpath://*[@id="pass"]
		driver.findElement(By.xpath("//input[@name='email']")).sendKeys("122adfd@gmail.com");
		
//		Css Selector
		driver.findElement(By.cssSelector("input[id='pass']")).sendKeys("1212321w");
//		//input[@id='pass']=xpath to css^^^^^^^^^^^^^^^^^^^^TagName[attribute=’value’]
		
//		Closing Chrome
		Thread.sleep(20000);
		driver.close();
	}
}
