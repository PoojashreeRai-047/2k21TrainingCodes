package conc.aa;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class a4PopupHandling 
{
//	Alert, Prompt, Confirm using Alert Class
	public static void main(String[] args) throws InterruptedException 
	{
//		Chromesetting
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();  if error rises		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		WebDriver driver = new ChromeDriver(co);
		driver.get("https://engineerdiaries.com/test");		
		System.out.println("normal webdriver didn't work\n so used chromeOptions");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		try 
		{
			driver.findElement(By.xpath("//*[contains(text(),'Advanced')]")).click();
			driver.findElement(By.linkText("Proceed to engineerdiaries.com (unsafe)")).click();
		}
		catch(Exception e) {System.out.println(e);}
		finally 
		{
//			Alert Box
			driver.findElement(By.id("alert")).click();
			Alert alrtbx=driver.switchTo().alert();
			System.out.println(alrtbx.getText());
			Thread.sleep(3000);
			alrtbx.accept();
			
//			Confirm Box
			driver.findElement(By.id("confirm")).click();
			Alert cnfrmbx=driver.switchTo().alert();
			System.out.println(cnfrmbx.getText());
			Thread.sleep(2000);
			cnfrmbx.dismiss();
			
//			Prompt
			driver.findElement(By.id("prompt")).click();
			Alert Prmp=driver.switchTo().alert();
			System.out.println(Prmp.getText());
			Prmp.sendKeys("klklkjlk");
			Thread.sleep(2000);
			Prmp.accept();
			
			Alert Prmp2=driver.switchTo().alert();
			Prmp2.accept();
			Thread.sleep(2000);
			
		}
		
		
//		closing browser
		Thread.sleep(3000);
		driver.close();
		
	}
}
