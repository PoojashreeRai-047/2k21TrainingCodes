package conc.aa;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

public class a7dragndropFrame 
{
//	HAndling frame N Drag&drop()
	public static void main(String[] args) throws InterruptedException 
	{
//		Chromesetting
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();  if error rises		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		WebDriver driver = new ChromeDriver(co);
		System.out.println("normal webdriver didn't work\n so used chromeOptions");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			
		driver.get("https://jqueryui.com/droppable/");		
		driver.manage().window().maximize();
		
//		scroll
		JavascriptExecutor js= (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,200)"); Thread.sleep(3000);
		
		
//		switch control to frame
		WebElement frms=driver.findElement(By.tagName("iframe"));
		driver.switchTo().frame(frms); Thread.sleep(3000);
		
//		storing in Webelement
		WebElement dragn=driver.findElement(By.id("draggable"));
		WebElement dropn=driver.findElement(By.id("droppable"));
		
//		build action&perform
		Actions act=new Actions(driver);
		act.dragAndDrop(dragn, dropn).build().perform();
		
//		closing chrome
		driver.close();
	}

}
