package tng.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class bAssrtns 
{
//	Assertions:  validate if testcase is passed or not
//	to check if conditon is matched or not
//	

	@BeforeTest
	void setup() 
	{		}
	
	@Test
	void test() 
	{
		try {		int i=10/0;		}catch(Exception e) {}		
		
		Assert.assertTrue(true);
		Assert.assertFalse(false);

		Assert.assertEquals("abcd", "abcd");
		Assert.assertNotEquals(null, "");
		
		Assert.assertSame(getClass(), getClass(), null);
		Assert.assertNotSame(getClass(), getClass(), null);
		
		Assert.assertNull(getClass());
		Assert.assertNotNull(getClass());
		
		Assert.assertThrows(null, null);
		
		
		
//		Assert.assertTrue(false);	
//		Assert.assertFalse(true);
//		Assert.assertEquals("abcd", "Abcd");
		
		
		
	}
	
	@AfterTest
	void teardown() 
	{	}
}
