package tng.testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class aDTprvdr
{
//	TEstNg code, Dataprovider to run same testcase multiple times in single testcase using multipe datasets

	
	WebDriver driver;
	
	@BeforeTest
	public void setup() 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();  if error rises		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(co);		
		System.out.println("normal webdriver didn't work\nso used chromeOptions");
	}
	@Test(dataProvider="getdata")
	public void test(String usrnm, String pswd) throws Exception 
	{
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");Thread.sleep(2000);
		driver.manage().window().maximize();
		driver.findElement(By.name("username")).sendKeys(usrnm);
		driver.findElement(By.name("password")).sendKeys(pswd);
	}
	@DataProvider
	Object[][] getdata()
	{
//		excutes 3 testcases with 3 diff datesets in a single testcase
		Object[][] data=new Object[3][2];
		data[0][0]="user1";
		data[0][1]="pass1";
		data[1][0]="user2";
		data[1][1]="pass2";
		data[2][0]="user3";
		data[2][1]="pass3";
		return data;
	}
	@AfterTest
	public void teardown() throws InterruptedException 
	{
		Thread.sleep(2000);
		driver.close();
	}

}
