package tng.testcases;

import org.testng.annotations.Test;

public class dPrioritsetting 
{
//	without priority: AlphatIcal Order
//	with priority: Acsending Order, lower pri val executed first
//	             
	@Test (priority=2)
	void Btest1() {System.out.println("Second Execution ");}
	@Test (priority=1)
	void Atest1() {System.out.println(" first Execution prior = 1");}
}
