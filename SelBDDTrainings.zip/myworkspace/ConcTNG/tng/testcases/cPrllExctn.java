package tng.testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

public class cPrllExctn 
{	
//	in testng.xml file : EDit 
//	thread-count="2"
//	<Suite name="Suite" parallel="methods">
	
	WebDriver driver;
	
	@Test
	void test1() throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();  if error rises		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(co);		
		System.out.println("normal webdriver didn't work\nso used chromeOptions");
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");Thread.sleep(2000);
		driver.manage().window().maximize();
		driver.findElement(By.name("username")).sendKeys("user222");
		driver.findElement(By.name("password")).sendKeys("papap");
		
		
	}
	@Test
	void test2() throws InterruptedException 
	{
		System.setProperty("webdriver.edge.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\edgedriver\\msedgedriver.exe");
		WebDriver driver=new EdgeDriver();
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");Thread.sleep(2000);
		driver.manage().window().maximize();
		driver.findElement(By.name("username")).sendKeys("user555");
		driver.findElement(By.name("password")).sendKeys("pappapa");
		
		
	}
	
	
}
