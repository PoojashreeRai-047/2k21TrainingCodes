package tngg.assignmts;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.*;

import io.netty.util.internal.SystemPropertyUtil;

public class AStestcase extends ASfileReader
{
//	TestNG + Pom + Selenium + dataproperties
	
	
	WebDriver driver;
	@BeforeTest
	void setup() 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();  if error rises		
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(co);		
		System.out.println("normal webdriver didn't work\n so used chromeOptions");
	}
	@Test(dataProvider="getdata")
	void test( String fnm, String lnm, String num, String npsd,
			String dte, String mnth, String yrs,String prpr
			    ) throws InterruptedException, IOException 
	{
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(15));
		String url=this.getURL(); System.out.println(url);
		
//		-----url working------------
		driver.get(getURL()); driver.get(url);
		driver.manage().window().maximize();
		
		ASobjs aob= new ASobjs(driver);
		aob.getCreAcc().click();Thread.sleep(2000);
		aob.getFNAme().sendKeys(fnm);
		aob.getsNAme().sendKeys(lnm);
		aob.getemail().sendKeys(num);
		aob.getnewpswd().sendKeys(npsd);
		
		
//	;;;;;;;;;;unable to use By elements for select class;;;;;;;;;;;
//		Select BDay=new Select(aob.getdate());
//		BDay.selectByValue("20");
		
		WebElement date=driver.findElement(By.id("day"));
		Select daob=new Select(date);
		daob.selectByValue(dte); 
		
		WebElement moth=driver.findElement(By.id("month"));
		Select month=new Select(moth);
		month.selectByVisibleText(mnth);
		
		WebElement yr=driver.findElement(By.id("year"));
		Select yob=new Select(yr);
		yob.selectByValue(yrs);
		
		aob.getGen().click();
		Thread.sleep(1000);
		
//		
		WebElement pp=driver.findElement(By.name("preferred_pronoun"));
		Select ppr=new Select(pp);
		ppr.selectByValue(prpr);
		Thread.sleep(3000);
		
		aob.getSignup().click();
	}
	@DataProvider
	Object[][] getdata()
	{
		Object[][] data=new Object[1][8];
		
		data[0][0]="aoaoaoa";
		data[0][1]="bobobob";
		data[0][2]="9090909090";
		data[0][3]="REREREeee";
		data[0][4]="5";
		data[0][5]="Jan";
		data[0][6]="1988";
		data[0][7]="6";
		
//		data[][]="";
		
		return data;
	}
	@AfterTest
	void teardown() throws InterruptedException 
	{
		Thread.sleep(3000);
//		Closing chrome
		driver.close();
	}
}
