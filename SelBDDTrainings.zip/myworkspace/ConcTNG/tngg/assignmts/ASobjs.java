package tngg.assignmts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;


public class ASobjs 
{
//	TestNG + Pom + Selenium + dataproperties
	WebDriver driver;
	public ASobjs(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By CreAcc=By.xpath("(//a[normalize-space()='Create new account'])[1]");
	    public WebElement getCreAcc()
	    {
		return driver.findElement(CreAcc);
		}
	
	 By FNAME=By.xpath("//input[@placeholder='First name']");
		public WebElement getFNAme()
		{
			return driver.findElement(FNAME);
		}
	
	 By sNAME=By.xpath("//input[@name='lastname']");
		public WebElement getsNAme()
		{
			return driver.findElement(sNAME);
		}	
	 By email=By.xpath("//input[@name='reg_email__']");
		public WebElement getemail()
		{
			return driver.findElement(email);
		}
	 By Npswd=By.xpath("//input[@id='password_step_input']");
		public WebElement getnewpswd()
		{
			return driver.findElement(Npswd);
		}
		/*	
//		date
		WebElement dd=driver.findElement(By.id("day"));
		public WebElement getdate() 
		{
			return dd;			
		}
		
//	month
	WebElement months=driver.findElement(By.xpath("//select[@id='month']"));	 
	    public WebElement getmonth() 
		{
			Select month=new Select(months);
			month.selectByValue("4");
			
			return months;			
		}
		
//	year
	WebElement years=driver.findElement(By.xpath("//select[@id='month']"));	 
	    public WebElement getyear() 
		{
			Select year=new Select(years);
			year.selectByValue("4");
			
			return years;			
		}
		*/
	
	/*
	 
	 By Npswd=By.xpath("//input[@id='password_step_input']");
		public WebElement getnewpswd()
		{
			return driver.findElement(Npswd);
		}
	  
	 */
	By custm = By.xpath("//label[normalize-space()='Custom']");
	public WebElement getGen() 
	{
		return driver.findElement(custm);
		
	}
	By signup = By.name("websubmit");
	public WebElement getSignup() 
	{
		return driver.findElement(signup);
	}
}
