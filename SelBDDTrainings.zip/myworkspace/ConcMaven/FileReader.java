package AutoPract.ConcMvnPrjt;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class FileReader 
{
//29th 1st part 3:23
//	REading data from excel file cells
	public static void main(String[] args) throws IOException 
	{
		// TODO Auto-generated method stub
		FileInputStream file=new FileInputStream(
//				"C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Desktop\\23training\\Selenium\\Excelfile\\mvjunittd.xlsx"
				"C:\\Users\\POOJASRA\\AutomationWs2\\eclipse-workspace\\eclipse-workspace\\EpsMvnCuc\\src\\main\\java\\utilities\\EpExcldata.xlsx"
				);
		Workbook book=new XSSFWorkbook(file);
		int sheets=book.getNumberOfSheets();
		
//		System.out.println("sheet"+sheets);
		Sheet sheet = book.getSheetAt(0);
//		comes sheet 0= sheet1
		
		Iterator<Row>rows=sheet.iterator();
		List<String> excelData=new ArrayList<String>();
		while(rows.hasNext())
//			if any row exist in sheet=true
		{
			Row row=rows.next();

			Iterator<Cell>cols=row.cellIterator();
//			goes to next column of that row = next cell
			while(cols.hasNext())
			{
				Cell value=cols.next();
//				System.out.println(value);
				String s1=value.toString();
				          if(value.getCellType()==CellType.NUMERIC)
				          {
								//System.out.println((int)value.getNumericCellValue());
								int num=(int)value.getNumericCellValue();
								s1=num+"";
								excelData.add(s1);
							}
				          else
							{
								//System.out.println(value);
								excelData.add(s1);
								
							}
			}
		}
		for(
				String data:excelData
				)
		{
		  System.out.println(data);
		}
	}
//29th 2nd part 1:15 TEStNG

}
