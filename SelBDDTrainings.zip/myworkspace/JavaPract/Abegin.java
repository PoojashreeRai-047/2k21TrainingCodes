package ajavpract;

public class Abegin 
{
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Hello World");
		fdndfj f=new fdndfj();
//		f.nnn(6);
//		f.f(6);
		
//		Java All Topics
//		f.dttps();
//		f.oprts();
		f.deciMakng();
	}

}
class fdndfj
{
	public static void Met(int n) 
	{
		for(int i=1;i<=n;++i) 
		{
			int j=1;
			do {
				for(int q=1;q<=i;++q) 
				{
					System.out.print(q+" ");
					++j;
					
				}
			}while(j<i); 
			System.out.println("j");
		}
	}
	
	public void nnn(int n) 
	{
		for(int i=1;i<=n;i++) 
		{
			int count=1;
			for(int j=1;j<=n;j++) 
			{
				if(j>=i) 
				{
					System.out.print(count);
				
				}
				//					System.out.print(i);
				else{ 
						
						System.out.print(i);
//						System.out.println(i+"=i value    " +j+"=javalue   "+count+"=count value");
					}			
			System.out.println("");
		}
	}}
	
	public void f(int n) 
	{
		for(int i=1;i<=n;i++) 
		{int count=0, one=1; 
		
			for(int j=1;j<=n;j++) 
			{ int diff=n-j;
				if(count>diff) 
				{
					System.out.print(i);
				}
				else 
				{
					System.out.print(one);
				}
				count++;
//				System.out.println(i+"=i " +j+"=j "+count+"=count "+diff+"=diff");
			}System.out.println("");
		} 
		
	}

// new course;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

//	Basics Of Java & Pre-Requisites
	public void dttps() 
	{
		System.out.println("\n*********DATATYPES********");
//		datatypes declaration:
		boolean b;
		int i;
		char c;
		double d;
		
//		Initialization:
		b=true;
		i=33;
		c='c';
		d=78.9865;
		
//		print:
		System.out.println("b variable value is :"+b);
		System.out.println("i variable value is :"+i);
		System.out.println("c variable value is :"+c);
		System.out.println("d variable value is :"+d);
		
		
	}
	public void oprts() 
	{
		System.out.println("\n*********OPERATORS*********");
		System.out.println("Arithmetic-----");
		int a,b=10,c=2;
		a=b+c;System.out.println("'+' of"+b+" & "+c +" is:" +a);
		a=b-c;System.out.println("'-' of"+b+" & "+c +" is:" +a);
		a=b*c;System.out.println("'*' of"+b+" & "+c +" is:" +a);
		a=b/c;System.out.println("'/' of"+b+" & "+c +" is:" +a);
		a=b%c;System.out.println("'%' of"+b+" & "+c +" is:" +a);
		b++;System.out.println("b++" +" is:"+b);
		c--;System.out.println("c--" +" is:"+c);
		
		System.out.println("Assignment-----");
		int i=10;System.out.println("i is Assigned with:"+i);
		
		System.out.println("Relational-----");
		int one=1,two=2,thr=3;
		System.out.println("'>' GreaterThan:  Two>One: "+(two>one));//true
//		System.out.println("                  One>Two: "+(one>two));//false
		System.out.println("'>=' GreaterThanOrEqualTo:  Two>=One: "+(two>=one));//true
//		System.out.println("                            One>=Two: "+(one>=two));//false
		System.out.println("'<' LessThan:  One<Two: "+(one<two));//true
//		System.out.println("               Two<One: "+(two<one));//false
		System.out.println("'<=' LessThanOrEqualTo:  One<=Two: "+(one<=two));//true
//		System.out.println("                         Two<=One: "+(two<=one));//false
		System.out.println("'==' EqualTo:    Three==Three: "+(thr==thr));//true
//		System.out.println("'==' EqualTo:    Three==Two:   "+(thr==two));//false
		System.out.println("'!=' NotEqualTo: Three!=Two: "+(thr!=two));//true
//		System.out.println("'!=' NotEqualTo: Three!=Three: "+(thr!=thr));//false
		
		
		System.out.println("Logical-----");
		boolean tr=true,fl=false;
		System.out.println("'&&': AND: (tr&&(!fl)):"+(tr&&(!fl)));//true
		System.out.println("'||': OR : (tr||fl)   :"+(tr||fl));//true
		System.out.println("'!' : NOT: (!fl)      :"+(!fl));//true
		
		System.out.println("Conditional-----");
//		also called as TernaryOperator
		boolean status; int q;
		q=(thr==(one+two))? 3:00;
		status=(b==(one+two+thr))? true:false;
		System.out.println("'q=(thr==(one+two))? 3:00; ' is: "+q);
		System.out.println("'status=(b==(one+two+thr))? true:false; 'is: "+status);
		
		System.out.println("Bitwise And Shift-----");
		int l=9,m=10,n=11;
		System.out.println("Bitwise AND (l<m & m<n): "+(l<m & m<n));
		System.out.println("Bitwise OR  (l<m | m<n): "+(l<m | m<n));
		
		System.out.println(20>>2);
		System.out.println(20>>>2);// 20/2^2=20/4=5
		
//		19:21
		System.out.println("Compound-----");
		int o,r=10,v=5;
		o=r+=v; System.out.println("r+=v is:"+o);
		o=r-=v; System.out.println("r-=v is:"+o);
		o=r*=v; System.out.println("r*=v is:"+o);
		o=r/=v; System.out.println("r/=v is:"+o);
		o=r%=v; System.out.println("r%=v is:"+o);
	}
	
	public void deciMakng() 
	{
		System.out.println("\n*********Decision Making********");
		System.out.println("IF Else-----");
		String tday="Monday";
		
		if(tday!="Sunday") 
		{
			System.out.println("Work Today aS");
			if(tday=="Saturday") 
			{
				System.out.print("::: HALF DAY");
			}
			else
			{
				System.out.print("::: FULL DAY");
			}
		} else if(tday.equals("Sunday"))
		 {
	        System.out.print("NO WORK TODAY");
         }  else 
              {
        	 System.out.print("NOT A RIGHT DAY");
              }
		        
		
		System.out.println("\nSwitch Case-----");
		int iday=1;
		switch(tday) 
		{
		case "Monday":
			System.out.println("Monday");
			break;
		case "Tuesday": 
			System.out.println("Tuesday");
			break;
		case "Wednesday": 
			System.out.println("Wednesday");
			break;
/*		case 4: 
			System.out.println("Thursday");
			break;
		case 5: 
			System.out.println("Friday");
			break;
		case 6: 
			System.out.println("Saturday");
			break;
		case 7: 
			System.out.println("Sunday");
			break;*/
			
		default:
			System.out.println("Weekday");
			break;

		}
	}
}
	

