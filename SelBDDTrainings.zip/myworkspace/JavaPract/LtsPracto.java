package ajavpract;

public class LtsPracto 
{
	public static void main(String[] args) 
	{
		oneOone Oe = new oneOone();
//		Oe.Met(5);
//		Oe.moo();
//		Oe.logicalprts();
//		Oe.dowhiledkf();
//		Oe.factwhile();
//		Oe.threeloops();
//		Oe.arrtraverser();
//		Oe.swtc();
//		Oe.swpr(56, 60);
//		Oe.shsum(5.29, 7.68, 9); 
		
//		System.out.println(Oe.loan(5000, 0.5, 2));
//		Oe.loan(5000, 0.5, 2);
//		Oe.checkTernary(50, 60);
		
		
		
	}

}
class oneOone
{
	void checkTernary(int i, int j) 
	{
		int r=(i>j)?(i-j):(j-i);
		System.out.println("Diff= "+r);
		
		char q='r';
		System.out.println(q=(i>j)? 'Y' : 'N');		
	}
	
	double loan(double amt, double inr, double yrs) 
	{
		double res= amt*inr*yrs ;
//		System.out.println(res);
		return res;
//		return amt*inr*yrs ;		
	}
	void shsum(double p, double q, float r)
	{
		for(int i=0;i<4; i++) 
		{
			diffpara(p,q,r);
			System.out.println("sum is: "+r);
		}
	}
	void diffpara(double x, double y, float z)
	{
		System.out.println("x:"+x+ " y:"+y+" z: "+z);
		z=(int) (x+y);
		
	}
	
	void swpr(int q, int r) 
	{
		System.out.println("Before Swapping: 1st="+q+" 2nd="+r);
		System.out.println("After Swapping:");
		allp(q,r);
		
	}
	
	
	void allp(int a, int b)
	{
		System.out.println("1st="+a+" 2nd="+b);
		int k=a;
		a=b;
		b=k;
		System.out.println("1st="+a+" 2nd="+b);
		
	}
	
	void swtc() 
	{
//		Arrays
		double[] v1= {20d, 30d, 40d, 50d};
		double[] v2= {2d, 10d, 4d, 30d};
		char[] Opcode= {'d','a','m','s'};
		double[] res=new double[Opcode.length];
		
//		Array traversal using for loop
		for(int i=0;i<Opcode.length;i++) 
		{
//			Switch CAse
			switch (Opcode[i]) 
			{
			case 'a':
				res[i] =v1[i] + v2[i]; break;
			case 's':
				res[i] =v1[i] - v2[i]; break;
			case 'm':
				res[i] =v1[i] * v2[i]; break;
			case 'd':
				res[i] =(v2[i] !=0)? v1[i]/v2[i]: 0.0d; break;
			default:
				System.out.println("Invalid Opcode"+Opcode[i]);
				res[i]=0.0d;
			}
		}
//		For Each Loop
		for(double curvalue : res)
		System.out.println(curvalue);
	}
	
	
	
	void arrtraverser()
	{
		int[] a= {1,4,7,98,890,6789,56789};
		System.out.println("length of a[] = "+ a.length);
		for(int index=0;index<a.length;index++) 
		{System.out.println("a["+index+"] = "+a[index]);}
		System.out.println("--------------------------\n");
		
		float[] b= new float[4];
		b[0]=4.44f;
		b[2]=3.333f;
		b[1]=8.88f;
		b[3]=7.980f;
		System.out.println("length of b[] = "+b.length);
		float sum=0.0f;
		for(int index=0;index<b.length;index++) 
		{
			System.out.println("b["+index+"] = "+b[index]);
			sum+=b[index];
		}
		System.out.println("Sum = "+sum);
		System.out.println("--------------------------\n");
	}
	
	void threeloops() 
	{
		int a=10,b=10;
		System.out.println("while loop pre a value= "+a );
		while(a<100)
		{ 
			a*=2;
			System.out.println("a value= "+a );
		}
		System.out.println("--------------------");
		
		System.out.println("DO while loop pre b value= "+b );
		do
		{ 
			b*=2;
			System.out.println("b value= "+b );
		}while(b<8 /*100*/ );
		System.out.println("--------------------");
		
		for(int c=10;c<100;c*=2) 
		{
			System.out.println("For loop pre c value= "+c);		
		}
	}
	
	int a=100, b=9, c=50;
	void logicalprts()
	{	
		System.out.println("In 100 9 50\n");
//		AND operator 
		if (a>b & a>c) // True & true
		{
		System.out.println("AND   Optr: "+a+" is greater");	
		}
		
//		OR operator
		if (a>b | b>c) //true | false
		{
			System.out.println("OR    Optr: "+a+" is greater or "+b+" is greater");	
		}
		
//		Exclusive OR
		if(b>a ^ a>c) //false ^ true 
		{
			System.out.println("EX-OR Optr: "+b+" is greater , "+a+" is greater");
		}
		
//		Negation  
		if(!(c<b)) // !false
		{
			System.out.println("Nega  Optr: "+b+" is greater");
		}
	}
	
	void factwhile() 
	{ int sval=4, val=sval,fact=1; 
		while(sval>1) 
		{
			fact *=sval;
			sval--;
			System.out.println("f="+fact+" s="+sval);
		} System.out.println(fact+" is factorial of "+val);
		System.out.println("------------------");
	}
	
	void dowhiledkf() 
	{ int /*i = 5*/ i=80 ;
		do 
		{
			System.out.print(i);
			i*=2;
			System.out.print(" *2= "+i+"\n");
		} while(i<25);
		System.out.println(i+" is >25------------------");

	}
	
	public void moo() 
	{
		int n = 2;
		for(int i=0;i<n;++i) 
		{
			
		}
	}
	public void Met(int n) 
	{
		for(int i=1;i<=n;++i) 
		{
			int j=1;
			do 
			{
				for(int q=1;q<=i;++q) 
				{
					System.out.print(q+" ");
					++j;
					
				}
			}while(j<i); 
			
			System.out.println("j");
		}
	}
}