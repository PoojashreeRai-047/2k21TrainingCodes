package automation.anzmavprj;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader 
{
	public static void main(String[] args) throws IOException 
	{
//		File attachment to code
		FileInputStream file=new FileInputStream("C:\\Users\\poojasra\\eclipse-workspace\\anzmavprj\\AnzMvnEpsp.xlsx");
		Workbook book=new XSSFWorkbook(file);
		
//		each Sheet<< each row << each column : each and every Cell in that file
		int sheets=book.getNumberOfSheets();
		//System.out.println("sheet"+sheets);
		Sheet sheet = book.getSheetAt(0);
		Iterator<Row>rows=sheet.iterator();
		List<String> excelData=new ArrayList<String>();
		while(rows.hasNext())
		{
			Row row=rows.next();
			Iterator<Cell>cols=row.cellIterator();
			while(cols.hasNext())
			{
				Cell value=cols.next();
				String s1=value.toString();
				
//           Converts numeric values(if found) into int , not taken as string 
//				1 => 1.0 XXXX                  1=>1
				if(value.getCellType()==CellType.NUMERIC)
				{
					//System.out.println((int)value.getNumericCellValue());
					int num=(int)value.getNumericCellValue();
					s1=num+"";
					excelData.add(s1);
				}
				else
				{
					//System.out.println(value);
					excelData.add(s1);
//					collecting all data into ArrayList
				}
			}
		}
		
//		printing the Arraylist
		for(String data:excelData)
		{
		  System.out.println(data);
		}
		
		

	}
}
