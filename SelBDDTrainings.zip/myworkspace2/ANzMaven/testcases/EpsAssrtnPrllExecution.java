package testcases;

import org.testng.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class EpsAssrtnPrllExecution 
{
	WebDriver driver;
	
	/*@Test(priority=1)
	
	public void assrtn()
	{
//		try{int i=10/0;
		
//		driver.manage().window().maximize();
//		driver.get("https://opensource-demo.orangehrmlive.com");
		System.out.println("for Assertions");
		
//		}catch(Exception e) {System.out.println("caught");}
		
		
		Assert.assertTrue(true);
		Assert.assertTrue(false);
		Assert.assertFalse(false);
		Assert.assertFalse(true);
		Assert.assertEquals("ABCD", "ABCD");
		Assert.assertEquals("abcd", "ABCD");
		
	}
	*/
	
//	PARALLEL EXECUTOIN IN DIFFERENT BROWSER
//	     right-click on project >> click on TestNG >>Click on convert to TestNG
//	in test-xml file --  <suite name="Suite" parallel="methods">
//	                     <test thread-count="2" name="Test">
//	@Test(priority=2,dataProvider="getdata")
	
	@Test(priority=2)
	public void paralelexctn() throws InterruptedException 
	{
		System.out.println("pri0222");
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://opensource-demo.orangehrmlive.com");
		Thread.sleep(3000);		
		driver.close();
	}
	@Test(priority=1)
	public void paralelexcton() throws InterruptedException 
	{
		System.out.println("prio111");
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
		driver=new ChromeDriver();
//		driver.manage().window().maximize();
		driver.get("https://opensource-demo.orangehrmlive.com");
		Thread.sleep(3000);   
		driver.close();
	}
}
