package objects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class FacebookLogin 
{   
	WebDriver driver;
	
	@FindBy(name="email")
	WebElement email;
	
	@FindBy(id="pass")
	WebElement password;
	
	@FindBy(name="login")
	WebElement login;
	
	public FacebookLogin(WebDriver driver)
	{
		AjaxElementLocatorFactory factory=new AjaxElementLocatorFactory(driver,10);
		PageFactory.initElements(driver, this);
	}
	
	public WebElement getEmail()
	{
		return email;
	}
	public WebElement getPassword()
	{
		return password;
	}
	public WebElement getLogin()
	{
		return login;
	}
}
