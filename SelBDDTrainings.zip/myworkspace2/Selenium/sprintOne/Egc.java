package sprintOne;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Egc {

	public static void main(String[] args) throws InterruptedException, IOException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		
		
		driver.get("https://www.spicejet.com/");
		
		driver.findElement(By.xpath("//*[text()='Gift Card']")).click();
		
		//Window Handling using Set of string
		Set<String> windows=driver.getWindowHandles();
		Iterator<String>it=windows.iterator();
		String parent=it.next();
		String child=it.next();
		driver.switchTo().window(child);
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[text()='Congratulations Gift Card']")).click();
		Thread.sleep(2000);
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,150)");
		
		driver.findElement(By.xpath("//img[@id='38893']")).click();
		
		driver.findElement(By.xpath("//input[@placeholder='₹500 - ₹50,000']")).sendKeys("5000");
		driver.findElement(By.xpath("//textarea[@placeholder='Your Message:']")).sendKeys("Congrats for New Job");
		
		WebElement seloptn = driver.findElement(By.xpath("//select[@id='quantity']"));
		Select quanty = new Select(seloptn);
		quanty.selectByVisibleText("2");
		
		
		driver.findElement(By.xpath("//label[contains(text(),'Send Later')]")).click();
		driver.findElement(By.xpath("//a[normalize-space()='15']")).click();
		driver.findElement(By.xpath("//a[normalize-space()='Preview E-Gift card']")).click();
		Thread.sleep(3000);
		
		js.executeScript("window.scrollBy(0,240)");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[normalize-space()='×']")).click();
		
		driver.findElement(By.xpath("//input[@placeholder=\"Sender's Name *\"]")).sendKeys("Pooja");
		driver.findElement(By.xpath("//input[@placeholder=\"Sender's e-mail Address *\"]")).sendKeys("pooja@gmail.com");
		driver.findElement(By.xpath("//input[@placeholder='Address line 1 *']")).sendKeys("Vinayak Nagar");
		driver.findElement(By.xpath("//input[@placeholder='Address line 2/Landmark']")).sendKeys("Shaikpet");
		driver.findElement(By.xpath("//input[@placeholder='Enter pincode to fetch city and state *']")).sendKeys("500008");
		driver.findElement(By.xpath("//input[@placeholder='City*']")).sendKeys("Hyderabad");
		driver.findElement(By.xpath("//input[@placeholder='State *']")).sendKeys("Telangana");
		driver.findElement(By.xpath("//input[@placeholder='Mobile Number *']")).sendKeys("6574321890");
		

		driver.findElement(By.xpath("//span[@class='hide-for-small-only']//input[@name='userdetails']")).click();
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"paymentSection\"]/div[2]/div/div[2]/div/div[2]/div/small/span/input")).click();
		
		js.executeScript("window.scrollBy(0,300)");
		driver.findElement(By.xpath("//input[@value='PAY NOW']")).click();
		
		//Screenshot
		File scrnsht1=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrnsht1, new File("./EgiftOutPut.jpg"));
		System.out.println("jpg done\n********************");
		
		
		
		
		Thread.sleep(6000);
		driver.close();
		Thread.sleep(2000);
		driver.switchTo().window(parent);
		driver.close();
	}

}
