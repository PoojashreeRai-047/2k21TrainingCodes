package refresh;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.Select;

public class AsgnFblogin 
{

		WebDriver driver;
		@FindBy(partialLinkText="New Account")
		WebElement createAcc;
		@FindBy(xpath="//*[@name=\"firstname\"]")
		WebElement fname;
		@FindBy(xpath="//*[@name=\"lastname\"]")
		WebElement lname;
		@FindBy(xpath="//*[@name=\"reg_email__\"]")
		WebElement mobilenum;
		@FindBy(xpath="//*[@name=\"reg_passwd__\"]")
		WebElement npswd;
		@FindBy(id="day")
		WebElement day;
		@FindBy(id="month")
		WebElement month;
		@FindBy(id="year")
		WebElement year;
		@FindBy(xpath="//label[text()=\"Custom\"]")
		WebElement gender;
		@FindBy(xpath="//select[@name=\"preferred_pronoun\"]")
		WebElement pp;
		@FindBy(name="custom_gender")
		WebElement cstm_gndr;
		
		public AsgnFblogin(WebDriver driver)
		{
			AjaxElementLocatorFactory factory=new AjaxElementLocatorFactory(driver,10);
			PageFactory.initElements(driver, this);
		}
		public WebElement getNewAcc() 
		{
			return createAcc;
		}
		public WebElement getfname() 
		{
			return fname;
		}
		public WebElement getlname() 
		{
			return lname;
		}
		public WebElement getphn() 
		{
			return mobilenum;
		}
		public WebElement getpswd()
		{
			return npswd;
		}
		
		public WebElement getdate()
		{
			return day;
		}
		WebElement selopt = driver.findElement(By.className("custom-select"));
		Select country = new Select(selopt);
		
		
		public WebElement getmonth()
		{
			return month;
		}
		
		public WebElement getyear()
		{
			return year;
		}
		
		public WebElement getgendr()
		{
			return gender;
		}
		public WebElement getprfrd_pronoun()
		{
			return pp;
		}
		public WebElement getGndrCstm()
		{
			return cstm_gndr;	
		}
		
}
