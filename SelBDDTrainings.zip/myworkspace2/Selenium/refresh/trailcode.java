package refresh;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class trailcode {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		JavascriptExecutor jz=(JavascriptExecutor)driver;
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		
		
		
		/*
		 * driver.get(
		 * "https://www.ecatering.irctc.co.in/?showQuery=true&showTrainSearch=true");
		 * driver.findElement(By.xpath("//input[@placeholder='Boarding Date']")).click()
		 * ; //driver.findElement(By.xpath("//span[text()='Boarding Date']")); jz.
		 * executeScript("document.querySelector(\"input[placeholder='Boarding Date']\").value='2022-02-02'"
		 * ); //span[text()='Boarding Date']
		 */


		
		//Thread.sleep(4000);
	}

}
