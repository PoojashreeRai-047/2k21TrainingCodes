package refresh;

public class ExcptHndlr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		System.out.println("one");
		int num=10/0;
		System.out.println("two");
		}
		catch(Exception ex) {
			System.out.println(ex);
		}
		finally{
			
		}
	}

}
