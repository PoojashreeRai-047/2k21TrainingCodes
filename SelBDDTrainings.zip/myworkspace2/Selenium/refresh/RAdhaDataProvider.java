package refresh;

public class RAdhaDataProvider 
{
//	@Test(dataProvider="GoogleData")
//	public void testcase(String source,String destin) 
//	{
//		
//	}
//	
//	
//	
//	
//	 @DataProvider(name="GoogleData")
//		public Object[][] getData() throws IOException
//		{
//			
//		String path="C:\\Users\\RALAMANI\\Desktop\\capgemini training\\selenium\\GoogleTravel.xlsx";
//		ReadExcel_googleTravel x=new ReadExcel_googleTravel(path);
//		int totalRows=x.getRowCount("Sheet1");
//		int totalCols=x.getCellCount("Sheet1", 1);
//		Object logindata[][]=new Object[totalRows][totalCols];
//		System.out.println(totalRows);
//		System.out.println(totalCols);
//		for(int i=1;i<=totalRows;i++)
//		{
//			for(int j=0;j<totalCols;j++)
//			{
//				logindata[i-1][j]=x.getCellData("Sheet1", i, j);
//		
//			}
//		}
//		
//		return logindata;
//
//	  }
}
