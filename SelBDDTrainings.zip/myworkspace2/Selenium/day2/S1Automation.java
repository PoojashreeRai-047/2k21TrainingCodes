package day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class S1Automation {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://itera-qa.azurewebsites.net/home/automation");
		driver.manage().window().maximize();
		
		//name   id="name"
		driver.findElement(By.id("name")).sendKeys("Poojashree");
		
		//female value="option1"   name="optionsRadios"
		driver.findElement(By.name("optionsRadios")).click();
		
		Thread.sleep(4000);
		driver.findElement(By.id("male")).click();
		//days MTW
		//monday  id="monday"
		driver.findElement(By.id("monday")).click();
		//tuesday id="tuesday"
		driver.findElement(By.id("tuesday")).click();
		//wednesday id="wednesday"
		driver.findElement(By.id("wednesday")).click();
		
		//Select class for options list
		
		//Class nameof list class="custom-select"
		WebElement selopt = driver.findElement(By.className("custom-select"));
		Select country = new Select(selopt);
		
		
		country.selectByVisibleText("Italy");
		Thread.sleep(3000);
		country.selectByIndex(4);
		Thread.sleep(3000);
		country.selectByValue("9");
		Thread.sleep(3000);
		
		
		
		
		
	}

}
