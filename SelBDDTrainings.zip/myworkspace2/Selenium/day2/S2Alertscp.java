package day2;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class S2Alertscp {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();

		driver.get("https://engineerdiaries.com/test");
		driver.manage().window().maximize();
		
		try {
			// //*[contains((text(),''Advance')]
			driver.findElement(By.xpath("//*[contains(text(),'Advanced')]")).click();
			
			// link text "Proceed to engineerdiaries.com (unsafe)"
			driver.findElement(By.linkText("Proceed to engineerdiaries.com (unsafe)")).click();
			
			
			
		}
		catch(Exception ex) {
			
		}
		finally {
			driver.findElement(By.id("alert")).click();
			Alert alertbox = driver.switchTo().alert();
			System.out.println(alertbox.getText());
			Thread.sleep(3000);
			alertbox.accept();
			
			driver.findElement(By.id("confirm")).click();
			Alert cnf = driver.switchTo().alert();
			System.out.println(cnf.getText());
			Thread.sleep(3000);
			cnf.accept();
			
			
			//id=prompt  xpath = //*[@id="prompt"]
			driver.findElement(By.xpath("//*[@id=\"prompt\"]")).click();
			Alert prmt = driver.switchTo().alert();
			System.out.println(prmt.getText());
			prmt.sendKeys("Hello");
			Thread.sleep(3000);
			prmt.accept();

//			System.out.println(prmt.getText());
			Thread.sleep(3000);
			Alert prmtAl = driver.switchTo().alert();
			prmtAl.accept();
			
			
		}
	}

}
