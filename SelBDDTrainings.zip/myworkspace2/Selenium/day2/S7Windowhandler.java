package day2;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class S7Windowhandler {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();

		driver.get("https://engineerdiaries.com/test");
		driver.manage().window().maximize();
		
		try {
			// //*[contains((text(),''Advance')]
			driver.findElement(By.xpath("//*[contains(text(),'Advanced')]")).click();
			
			// link text "Proceed to engineerdiaries.com (unsafe)"
			driver.findElement(By.linkText("Proceed to engineerdiaries.com (unsafe)")).click();
			
			
			
		}
		catch(Exception ex) {}
		finally {
			JavascriptExecutor js=(JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,800)");
			
			Thread.sleep(2000);
			driver.findElement(By.linkText("Visit W3Schools.com!")).click();
			Set<String> windows= driver.getWindowHandles();
			Iterator<String> it=windows.iterator();
			
			String parent=it.next();
			String child=it.next();
			driver.switchTo().window(child);
			
			Thread.sleep(2000);
			driver.switchTo().window(parent);
			
			Thread.sleep(2000);
			driver.switchTo().window(child);
			
			
//			driver.quit();
			
			Thread.sleep(2000);
			driver.close();
			
			Thread.sleep(2000);
            driver.switchTo().window(parent);
			driver.close();
			
	
}}}
