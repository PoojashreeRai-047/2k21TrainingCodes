package day2;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class S5Amazon {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		
		//id= nav-link-accountList
		WebElement button=driver.findElement(By.id("nav-link-accountList"));
		System.out.println(button.getText());
		
		//hover mouse pointer
		Thread.sleep(3000);
		Actions act=new Actions(driver);
		act.moveToElement(button).build().perform();
		
		WebElement inputBox = driver.findElement(By.id("twotabsearchtextbox"));
		act.keyDown(Keys.SHIFT).build().perform();
		inputBox.sendKeys("hello");
//		Thread.sleep(3000);
		act.keyUp(Keys.SHIFT).build().perform();
		inputBox.sendKeys("hello");
		
		
	}

}
