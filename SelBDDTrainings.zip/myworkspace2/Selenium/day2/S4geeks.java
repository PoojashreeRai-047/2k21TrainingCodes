package day2;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class S4geeks {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.geeksforgeeks.org/");
		driver.manage().window().maximize();
		
		//sign in= Sign In
		driver.findElement(By.linkText("Sign In")).click();
		
		driver.switchTo().activeElement();
		
		//username 
		driver.findElement(By.id("luser")).sendKeys("poojashree.1435@gmail.com");
		// password
		driver.findElement(By.id("password")).sendKeys("12343445");
		
		//signin button
		driver.findElement(By.className("signin-button")).click();
		
	}

}
