package day4;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class S6Edgewala {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.edge.driver", "C:\\Users\\poojasra\\Documents\\edgedriver\\msedgedriver.exe");
		WebDriver driver=new EdgeDriver();
		
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.geeksforgeeks.org/");  
		driver.manage().window().maximize();
		
		
		
		
		
		
		
		
		
		
		
		
		System.out.println("end");
		Thread.sleep(15000);
		driver.close(); 
	}

}
