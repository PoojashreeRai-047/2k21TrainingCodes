package day4;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class S4ExplicitWait {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.geeksforgeeks.org/");
		driver.manage().window().maximize();
		
		
		//Explicit Wait
				WebElement singin= driver.findElement(By.linkText("Sign In"));
				Wait<WebDriver> wait1= new WebDriverWait(driver,Duration.ofSeconds(10));
				wait1.until(ExpectedConditions.elementToBeClickable(singin)).click();
				
		//Fluent wait
				Wait<WebDriver> wait2= new FluentWait<WebDriver>(driver)
						.withTimeout(Duration.ofSeconds(30))
						.pollingEvery(Duration.ofSeconds(5))
						.ignoring(NoSuchElementException.class);
		
		//sign in= Sign In
		//driver.findElement(By.linkText("Sign In")).click();
		
		driver.switchTo().activeElement();
		
		
		
		//username 
		driver.findElement(By.id("luser")).sendKeys("poojashree.1435@gmail.com");
		// password
		driver.findElement(By.id("password")).sendKeys("12343445");
		
		//signin button
		driver.findElement(By.className("signin-button")).click();
		
		
		System.out.println("end");
		Thread.sleep(15000);
		driver.close(); 	
	}

}
