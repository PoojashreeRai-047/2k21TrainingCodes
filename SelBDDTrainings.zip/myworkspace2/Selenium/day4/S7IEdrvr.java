package day4;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.ie.*;

public class S7IEdrvr {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.ie.driver", "C:\\Users\\poojasra\\Documents\\IEDriverServer\\IEDriverServer.exe");
		WebDriver driver=new InternetExplorerDriver();
		
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.geeksforgeeks.org/");  
		driver.manage().window().maximize();
		
		
		
		
		
		
		
		
		
		
		
		
		System.out.println("end");
		Thread.sleep(15000);
		driver.close(); 
	}

}
