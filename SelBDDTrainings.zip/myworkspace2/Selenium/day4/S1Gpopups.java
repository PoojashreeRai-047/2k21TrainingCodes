package day4;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class S1Gpopups {

	public static void main(String[] args) throws InterruptedException, AWTException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		/*WebDriver driver=new ChromeDriver();
		
		//https://www.spicejet.com/
		driver.get("https://www.spicejet.com/");
			
			
			driver.manage().window().maximize();*/
		
		//CODE1
		Map<String, Object> prefs = new HashMap<String, Object>();
		//add key and value to map as follow to switch off browser notification
		//Pass the argument 1 to allow and 2 to block
		 prefs.put("profile.default_content_setting_values.notifications", 2);
		 //prefs.put("profile.default_content_setting_values.geolocation", 2);

		 //Create an instance of ChromeOptions
		 ChromeOptions options = new ChromeOptions();
		 options.addArguments("--disable-notifications");
		 // set ExperimentalOption - prefs
		 options.setExperimentalOption("prefs", prefs);
		 WebDriver driver=new ChromeDriver(options);
		 driver.get("https://www.spicejet.com/");

		 
		 //CODE2
		Thread.sleep(3000);
		Robot robot = new Robot();
		//robot.delay(5000);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_TAB);
		robot.keyPress(KeyEvent.VK_ENTER);
		
		
		
		Thread.sleep(5000);
		driver.close();
	}

}
