package day4;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class S3PageLoadTimeoutExcpt {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		// here it goes 
		//before the link , to be executed is declared
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(1));
		
		
		driver.get("https://www.tutorialspoint.com/index.htm");
		driver.manage().window().maximize();
		
		
		
		
		
		System.out.println("end");
		Thread.sleep(15000);
		driver.close(); 
	}

}
