package day4;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class S5Firefox {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\poojasra\\Documents\\geckodriver\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.geeksforgeeks.org/");  
		driver.manage().window().maximize();
		
		
		
		
		
		
		
		
		
		
		
		
		System.out.println("end");
		Thread.sleep(15000);
		driver.close(); 
	}

}
