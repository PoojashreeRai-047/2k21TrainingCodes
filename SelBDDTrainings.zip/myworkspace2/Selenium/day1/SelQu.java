package day1;

import java.util.ArrayList;
import java.util.List;

public class SelQu {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		List<String> l1 = new ArrayList<String>();
		l1.add("");
		//l2
		//
		List<String> result = new ArrayList<String>();
		

	}

}
