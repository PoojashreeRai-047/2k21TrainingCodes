package day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Sel7Class {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		//https://start.atlassian.com/
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://start.atlassian.com/");
		
		driver.findElement(By.id("username")).sendKeys("poojashree.1435@gmail.com");
		driver.findElement(By.id("login-submit")).click();
		Thread.sleep(2000);
		driver.findElement(By.name("password")).sendKeys("12345678");
		
		
		//for tagname:
		//driver.findElement(By.tagName(null));
	}

}
