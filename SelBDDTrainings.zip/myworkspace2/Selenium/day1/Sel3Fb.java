package day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Sel3Fb {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com/");
		
		driver.manage().window().maximize();
		// locator id
		// driver.findElement(By.id("email")).sendKeys("Poojarai");
		// driver.findElement(By.id("pass")).sendKeys("Poojarai");
		//locator: name
		// driver.findElement(By.name("login")).click();
		
		// class name   inputtext   _9npi only one can be used ,not compound stmnt
	//	driver.findElement(By.className("inputtext")).sendKeys("PoojaRai");
	//	driver.findElement(By.className("_9npi")).sendKeys("123467890-");
		
		// Copy full Xpath of email ABSOLUTE XPATH
		// /html/body/div[1]/div[2]/div[1]/div/div/div/div[2]/div/div[1]/form/div[1]/div[1]
		
		// Copy xpath RELATIVE XPATH - PREFFERED
		// //*[@id="email"]
		
		driver.findElement(By.xpath("//*[@id='email']")).sendKeys("PoojaRai");
		driver.findElement(By.xpath("//*[@id=\"pass\"]")).sendKeys("123467890-");
		
		
		Thread.sleep(10000);
		driver.manage().window().minimize();
	}

}
