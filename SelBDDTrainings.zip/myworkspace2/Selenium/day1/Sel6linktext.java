package day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Sel6linktext {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com/");
		
		
		//"Forgotten password?"
		
		//Link text locator
		driver.findElement(By.linkText("Forgotten password?")).click();
		// Partial link text locator
		driver.findElement(By.partialLinkText("Forgotten ")).click();
		
		//Thread.sleep(1000);
		//driver.findElement(By.id("identify_email")).sendKeys("Poojarai");
		
		
		//Thread.sleep(4000);
		//class locator from instagram v will c
		//driver.findElement(By.name("")).click();
		
		//ctrl+f for searching
		//Tagname locator executes first found tag
		driver.findElement(By.tagName("button")).click();
	}

}
