package day5;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Order;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class S4junit {
         WebDriver driver;
         @Before
         public void setup() 
         {
        	 System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
        	 System.out.println("Before");
        	 driver = new ChromeDriver();
         }
         @Test
         @Order(2) 
         public void testA()
         {
        	 System.out.println("TestCAse 1 A() order=2");
        	 driver.get("https://www.orangehrm.com/");
         }
         @Test
         @Order(1)
         public void testB()
         {
        	 System.out.println("TestCAse 2 B() order=1");
        	 driver.get("https://www.facebook.com/");
         }
        @After
        public void teardown()
        {
        	System.out.println("After");
       	 driver.close();;
        }
         
}
