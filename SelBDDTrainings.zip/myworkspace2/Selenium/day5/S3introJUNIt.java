package day5;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class S3introJUNIt {
	WebDriver driver;
    @Before
    public void setup() {
   	 System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
   	 System.out.println("Before");
   	 driver = new ChromeDriver();
    }
    @Test
    public void testA()
    {
   	 System.out.println("TestCAse 1");
   	 driver.get("https://www.orangehrm.com/");
    }
   @After
   public void teardown()
   {
   	System.out.println("After");
  	 driver.close();;
   }
}
