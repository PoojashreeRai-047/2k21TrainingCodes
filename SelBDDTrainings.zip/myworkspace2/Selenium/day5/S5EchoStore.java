package day5;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class S5EchoStore {
	
	 private WebDriver driver;
	  private Map<String, Object> vars;
	  JavascriptExecutor js;
	  @Before
	  public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		driver = new ChromeDriver();
	    js = (JavascriptExecutor) driver;
	    vars = new HashMap<String, Object>();
	  }
	  @After
	  public void tearDown() {
	    driver.quit();
	  }
	  @Test
	  public void t2psel() {
	    driver.get("http://www.seleniumframework.com/practiceform/");
	    driver.manage().window().setSize(new Dimension(1296, 696));
	    driver.findElement(By.id("alert")).click();
	    assertEquals(driver.switchTo().alert().getText(),("Please share this website with your friends and in your organization."));
	    vars.put("var2", "Please share this website with your friends and in your organization.");
	    System.out.println(vars.get("var2").toString());
//	    driver.close();
	  }

}
