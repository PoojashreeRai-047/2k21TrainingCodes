package day5;

import static org.junit.Assert.assertEquals;


import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class S1importidecode {

//	public static void main(String[] args)
//	{
		// TODO Auto-generated method stub
		
		
		private WebDriver driver;
		  private Map<String, Object> vars;
		  JavascriptExecutor js;
		  @Before
		  public void setUp()
		  {
			  System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
			driver = new ChromeDriver();
		    js = (JavascriptExecutor) driver;
		    vars = new HashMap<String, Object>();
		  }
		  @After
		  public void tearDown() 
		  {
		    driver.quit();
		  }
		  public String waitForWindow(int timeout) 
		  {
		    try
		    {
		      Thread.sleep(timeout);
		    } 
		    catch (InterruptedException e)
		    {
		      e.printStackTrace();
		    }
		    Set<String> whNow = driver.getWindowHandles();
		    Set<String> whThen = (Set<String>) vars.get("window_handles");
		    if (whNow.size() > whThen.size()) 
		    {
		      whNow.removeAll(whThen);
		    }
		    return whNow.iterator().next();
		  }
		  @Test
		  public void t1psel()
		  {
		    driver.get("http://www.seleniumframework.com/practiceform/");
		    driver.manage().window().setSize(new Dimension(1280, 680));
		    driver.findElement(By.id("page")).click();
		    vars.put("window_handles", driver.getWindowHandles());
		    driver.findElement(By.linkText("This is a link")).click();
		    vars.put("win8606", waitForWindow(2000));
		    vars.put("root", driver.getWindowHandle());
		    driver.switchTo().window(vars.get("win8606").toString());
		    {
		      WebElement element = driver.findElement(By.cssSelector(".menu-item-home span"));
		      Actions builder = new Actions(driver);
		      builder.moveToElement(element).perform();
		    }
		    driver.switchTo().window(vars.get("root").toString());
		    vars.put("window_handles", driver.getWindowHandles());
		    driver.findElement(By.id("button1")).click();
		    vars.put("win7765", waitForWindow(2000));
		    driver.switchTo().window(vars.get("win7765").toString());
		    driver.close();
		    driver.switchTo().window(vars.get("root").toString());
		    vars.put("window_handles", driver.getWindowHandles());
		    driver.findElement(By.cssSelector("p:nth-child(5) > button")).click();
		    vars.put("win5600", waitForWindow(2000));
		    driver.switchTo().window(vars.get("win5600").toString());
		    driver.close();
		    driver.switchTo().window(vars.get("root").toString());
		    {
		      WebElement element = driver.findElement(By.id("button1"));
		      Actions builder = new Actions(driver);
		      builder.moveToElement(element).perform();
		    }
		    {
		      WebElement element = driver.findElement(By.tagName("body"));
		      Actions builder = new Actions(driver);
		      builder.moveToElement(element, 0, 0).perform();
		    }
		    vars.put("window_handles", driver.getWindowHandles());
		    driver.findElement(By.cssSelector("p:nth-child(6) > button")).click();
		    vars.put("win4038", waitForWindow(2000));
		    driver.switchTo().window(vars.get("win4038").toString());
		    {
		      WebElement element = driver.findElement(By.linkText("PRACTICE"));
		      Actions builder = new Actions(driver);
		      builder.moveToElement(element).perform();
		    }
		    driver.switchTo().window(vars.get("root").toString());
		    driver.findElement(By.linkText("Find me I have nothing in me!!")).click();
		    driver.findElement(By.linkText("Find me I have nothing in me!!")).click();
		    driver.findElement(By.linkText("Find me I have nothing in me!!")).click();
		    {
		      WebElement element = driver.findElement(By.linkText("Find me I have nothing in me!!"));
		      Actions builder = new Actions(driver);
		      builder.doubleClick(element).perform();
		    }
		    driver.findElement(By.linkText("Find me I have nothing in me!!")).click();
		    js.executeScript("window.scrollTo(0,350)");
		    driver.findElement(By.id("alert")).click();
		    assertEquals(driver.switchTo().alert().getText(),("Please share this website with your friends and in your organization."));
		    driver.findElement(By.id("timingAlert")).click();
		    assertEquals(driver.switchTo().alert().getText(),("Please share this website with your friends and in your organization."));
		    driver.findElement(By.id("colorVar")).click();
		    driver.findElement(By.id("colorVar")).click();
		    driver.findElement(By.id("doubleClick")).click();
		    {
		      WebElement dragged = driver.findElement(By.id("draga"));
		      WebElement dropped = driver.findElement(By.id("dragb"));
		      Actions builder = new Actions(driver);
		      builder.dragAndDrop(dragged, dropped).perform();
		    }
		    driver.findElement(By.name("email")).click();
		    driver.findElement(By.name("email")).sendKeys("uuu");
		    driver.findElement(By.name("name")).click();
		    driver.findElement(By.name("name")).sendKeys("yyyy");
		    driver.findElement(By.cssSelector(".validate\\[required\\,custom\\[email\\]\\]")).click();
		    driver.findElement(By.cssSelector(".validate\\[required\\,custom\\[email\\]\\]")).sendKeys("eeeee");
		    driver.findElement(By.name("telephone")).click();
		    driver.findElement(By.name("telephone")).sendKeys("44444");
		    driver.findElement(By.name("country")).click();
		    driver.findElement(By.name("country")).sendKeys("33333");
		    driver.findElement(By.name("company")).click();
		    driver.findElement(By.name("company")).sendKeys("66666");
		    driver.findElement(By.name("message")).click();
		    driver.findElement(By.name("message")).sendKeys("44444");
		    driver.findElement(By.linkText("clear")).click();
		    driver.switchTo().window(vars.get("win8606").toString());
		    driver.close();
		    driver.switchTo().window(vars.get("root").toString());
		    driver.switchTo().window(vars.get("win4038").toString());
		    driver.close();
		    driver.switchTo().window(vars.get("root").toString());
		    driver.close();
		  }
	//}	  

}
