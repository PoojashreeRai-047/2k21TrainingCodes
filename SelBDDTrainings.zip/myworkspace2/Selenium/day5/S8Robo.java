package day5;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class S8Robo {
	private WebDriver driver;
	  private Map<String, Object> vars;
	  JavascriptExecutor js;
	  @Before
	  public void setUp() {
		  System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
	    driver = new ChromeDriver();
	    
	    
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	    js = (JavascriptExecutor) driver;
	    vars = new HashMap<String, Object>();
	  }
	  @After
	  public void tearDown() {
	    driver.quit();
	  }
	  @Test
	  public void t1psel() throws InterruptedException {
	    driver.get("https://www.orangehrm.com/contact-sales/");
	    driver.manage().window().setSize(new Dimension(1296, 696));
	    driver.findElement(By.id("Form_submitForm_CompanyName")).click();
	    driver.findElement(By.id("Form_submitForm_CompanyName")).sendKeys("sddsa");
	    driver.findElement(By.id("Form_submitForm_Contact")).click();
	    driver.findElement(By.id("Form_submitForm_Contact")).sendKeys("fdsf");
	    JavascriptExecutor js= (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,400)");
	    driver.switchTo().frame(0);
	    Thread.sleep(5000);
	    driver.findElement(By.cssSelector(".recaptcha-checkbox-border")).click();
	    Thread.sleep(5000);
	    driver.switchTo().defaultContent();
	    driver.findElement(By.id("Form_submitForm_Comment")).click();
	    driver.findElement(By.id("Form_submitForm_Comment")).sendKeys("fssdsdS");
	    Thread.sleep(10000);
}
}