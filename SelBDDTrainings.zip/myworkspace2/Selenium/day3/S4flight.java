package day3;

import java.util.List;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class S4flight {
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		//https://www.spicejet.com/
		driver.get("https://www.spicejet.com/");
		driver.manage().window().maximize();
		
		Scanner s=new Scanner(System.in);
//		int n=s.nextInt();
		Thread.sleep(3000);
		
		//classname =css-1cwyjr8 r-homxoj r-ubezar r-10paoce r-13qz1uu
		driver.findElement(By.className("css-1cwyjr8")).click();
		List<WebElement> dd1= driver.findElements(By.className("css-76zvg2"));
		try {
			for(WebElement dd:dd1)
			{
				if(dd.getText().equals("DEL")) 
				{
					dd.click();
				}
			}		
		}
		finally {
			List<WebElement> dd2= driver.findElements(By.className("css-76zvg2"));
			for(WebElement d:dd2)
			{
				if(d.getText().equals("UDR")) 
				{
					d.click();
				}
			}
	
		Thread.sleep(30000);
		driver.close(); 
	}
	}}
