package day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class S1driverLevel {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();

		//driver.get("https://www.geeksforgeeks.org/");
		//https://www.facebook.com/
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		
		//url and title of the web page.
		System.out.println(driver.getCurrentUrl());
		System.out.println(driver.getTitle());
		//for email textbox
		/*System.out.println(driver.findElement(By.id("email")));
		
		//get()s
		WebElement email= driver.findElement(By.id("email"));
		System.out.println(email.getAccessibleName());
		System.out.println(email.getAriaRole());
		System.out.println(email.getAttribute("class"));
		System.out.println(email.getCssValue("color"));
		System.out.println(email.getCssValue("font"));  */
		
		
		//for login button name="login"
		System.out.println(driver.findElement(By.name("login")));
		WebElement loginbtn=driver.findElement(By.name("login"));
		System.out.println(loginbtn.getAccessibleName());
		System.out.println(loginbtn.getAriaRole());
		System.out.println(loginbtn.getAttribute("id"));
		System.out.println(loginbtn.getCssValue("color"));
		System.out.println(loginbtn.getCssValue("font"));
		
		
		System.out.println("****************");
		System.out.println(loginbtn.getDomAttribute("value"));
		System.out.println(loginbtn.getDomProperty("innerHTML"));
		System.out.println(loginbtn.getDomAttribute("text"));
		System.out.println(loginbtn.getTagName());
		System.out.println(loginbtn.getText());
		System.out.println("****************");
		System.out.println(loginbtn.isDisplayed());
		System.out.println(loginbtn.isEnabled());
		System.out.println(loginbtn.isSelected());
		System.out.println(loginbtn.getLocation().getX());
		System.out.println(loginbtn.getRect().getHeight());
		System.out.println("****************");
		
		//System.out.println(email);
		
		Thread.sleep(5000);
		driver.close();
	}

}
