package day3;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.idealized.Javascript;
import org.openqa.selenium.interactions.Actions;

public class S5makemyt {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		//  https://www.makemytrip.com/
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		//https://www.spicejet.com/
		driver.get("https://www.makemytrip.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		/* // classname="autopop__wrap makeFlex column defaultCursor"
		WebElement ele = driver.findElement(By.className("autopop__wrap makeFlex column defaultCursor"));*/
		Thread.sleep(3000);
		
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("document.elementFromPoint(0,10).click()");
		
		//driver.findElement(By.className("fsw_inputBox")).click();
		driver.findElement(By.xpath("//span[text()='From']")).click();
		driver.findElement(By.className("react-autosuggest__input")).sendKeys("New Delhi");
		Thread.sleep(4000);
		driver.findElements(By.xpath("//li[@role='option']")).get(0).click();
		Thread.sleep(4000);
		
		driver.findElement(By.xpath("//input[@placeholder='To']")).click();
		driver.findElement(By.className("react-autosuggest__input")).sendKeys("Mumbai");
		Thread.sleep(4000);
		driver.findElements(By.xpath("//li[@role='option']")).get(0).click();
		Thread.sleep(4000);
		
		Thread.sleep(10000);
		driver.close(); 
	}

}
