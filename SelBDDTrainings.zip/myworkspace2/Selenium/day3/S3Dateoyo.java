package day3;

import java.util.List;
import java.util.Scanner;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class S3Dateoyo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		//https://www.oyorooms.com/
		driver.get("https://www.oyorooms.com/");
		driver.manage().window().maximize();
		
		
		/*
		//date selection 28/01/20222 to 02/02/2022
		//class="DateRangePicker__DateLabel
		driver.findElement(By.xpath("//*")).click();
		driver.findElement(By.xpath("//*")).click();
		*/
		
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		Thread.sleep(3000);
		
		driver.findElement(By.className("datePickerDesktop")).click();Thread.sleep(3000);
		driver.findElement(By.className("DateRangePicker__PaginationArrow--next")).click();Thread.sleep(3000);
		
		List <WebElement> dates= driver.findElements(By.className("DateRangePicker__DateLabel"));
		WebElement drag= null,drop=null;
		boolean isDragSelected= false;
		boolean isDropSelected= false;
		try {
			for(WebElement date : dates) {
				if(date.getText().equals("28") && isDragSelected==false)
				{
					drag=date;
					isDragSelected= true;
				}
				if(date.getText().equals("31") && isDropSelected==false)
				{
					drop=date;
					isDropSelected= true;
				}
			}
		}
		finally{
			
			Actions act =new Actions(driver);
			act.dragAndDrop(drag, drop).build().perform();	
			}
		
		Thread.sleep(30000);
		driver.close(); 
	}

}
