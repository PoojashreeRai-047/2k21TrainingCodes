package day3;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class S6Scrnshot {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.geeksforgeeks.org/");
		driver.manage().window().maximize();
		
		//screenshot image code
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("./image.png"));
		
		System.out.println("png done\n********************");
		// second screenshot
		/*//sign in= Sign In
				driver.findElement(By.linkText("Sign In")).click();
				
				driver.switchTo().activeElement();
				
				//username 
				driver.findElement(By.id("luser")).sendKeys("poojashree.1435@gmail.com");
				// password
				driver.findElement(By.id("password")).sendKeys("12343445");*/
		//in jpg format
		File src1=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src1, new File("./image.jpg"));
		System.out.println("jpg done\n********************");
		
		File src3=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src3, new File("./image.jpeg"));
		System.out.println("jpeg done\n********************");
		Thread.sleep(3000);
		driver.close();
	}

}
