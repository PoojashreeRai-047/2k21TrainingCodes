package testcases;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import objects.LoginPage;

public class LoginTestCases {

	WebDriver driver;
	@Before
	public void setup() 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		driver=new ChromeDriver();
	}
	@Test
	public void test_1() 
	{
		driver.get("https://opensource-demo.orangehrmlive.com/");
		driver.manage().window().maximize();
		
		LoginPage login = new LoginPage(driver);
		
		login.username1().sendKeys("Admin");
		login.password1().sendKeys("admin123");
		login.loginbtn1().click();
	}
	@After
	public void teardown()
	{
		driver.close();
	}
}
