package testcases;

import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import objects.FacebookLogin;
import utilities.ReadFile;

public class FbloginTC extends ReadFile
{

	WebDriver driver;
	@Before
	public void setup() 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		driver=new ChromeDriver();
	}
	@Test
	public void test_1() throws IOException
	{
	   //driver.get("https://www.facebook.com/");
		String url=this.getUrl();
		driver.get(url);
		driver.manage().window().maximize();
		
		FacebookLogin fblogin=new FacebookLogin(driver);
		
		fblogin.getEmail().sendKeys("xyz.789@gmail.com");
		fblogin.getPassword().sendKeys("qwertyuio");
		fblogin.getLogin().click();
		
	}
	@After
	public void teardown() throws InterruptedException
	{
		//Thread.sleep(8000);
		//driver.close();
	}
}
