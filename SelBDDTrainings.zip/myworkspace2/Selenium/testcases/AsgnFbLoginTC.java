package testcases;

import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import refresh.AsgnFblogin;
import utilities.ReadFile;

public class AsgnFbLoginTC extends ReadFile{
	WebDriver driver;
	@Before
	public void setup()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		driver=new ChromeDriver();
	}
	@Test
	public void test_1() throws InterruptedException, IOException 
	{
		//driver.get("https://www.facebook.com/");
		String url=this.getUrl();
		driver.get(url);
		driver.manage().window().maximize();
		
		AsgnFblogin FbLgn = new AsgnFblogin(driver);
		JavascriptExecutor js=(JavascriptExecutor) driver;
		
		FbLgn.getNewAcc().click();
		Thread.sleep(3000);
		FbLgn.getfname().sendKeys("Poojashree");
		FbLgn.getlname().sendKeys("Rai");
		FbLgn.getphn().sendKeys("8080808808");
		FbLgn.getpswd().sendKeys("Unity@123");
		
		FbLgn.getdate().click();
		
		
		FbLgn.getmonth().click();
		
		FbLgn.getyear().click();
		
		FbLgn.getgendr().click();
		
		FbLgn.getprfrd_pronoun();
		
		
		js.executeScript("window.scrollBy(0,200)");
		
		FbLgn.getGndrCstm().sendKeys("she");	
	}
	
	@After
	public void teardown() throws InterruptedException 
	{
		Thread.sleep(3000);
		driver.close();
	}
	
	/*
	//DOB
	driver.findElement(By.id("day")).click();
	driver.findElement(By.xpath("//option[@value=\"14\"]")).click();
	Thread.sleep(2000);//
	driver.findElement(By.id("month")).click();
	driver.findElement(By.xpath("//*[@id=\"month\"]/option[4]")).click();
	Thread.sleep(2000);
	driver.findElement(By.id("year")).click();
	driver.findElement(By.xpath("//option[@value=\"2000\"]")).click();
	Thread.sleep(2000);
	
	//Gender id u_2_6_AN
	driver.findElement(By.xpath("//label[text()=\"Custom\"]")).click();
	Thread.sleep(3000);
	driver.findElement(By.xpath("//select[@name=\"preferred_pronoun\"]")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//select[@name=\"preferred_pronoun\"]/option[4]")).click();
	
	
	//additional info name= custom_gender
	driver.findElement(By.xpath("//*[@name=\"custom_gender\"]")).sendKeys("She");
	
	*/
}
