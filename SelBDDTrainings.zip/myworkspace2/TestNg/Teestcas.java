import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

class Teestcas {

	@BeforeAll
	public static void preClass()  {
		System.out.println("@BeforeAll-the annotated mathod runs once before all other methods execute");
	}
	
	@BeforeEach
	public void setUp() {
		System.out.println("_________________________________________\n");
		System.out.println("@BeforeEach - the annoted method executes before each test ");
	}
	
	@Test @Order(1)
	public void test_JUnit1() {
		System.out.println("@Test - this is test case 1");
	}
	@Test @Order(2)
	public void test_JUnit2() {
		System.out.println("@Test - this is test case 2");
	}
	@Test @Order(3)
	public void test_JUnit3() {
		System.out.println("@Test - this is test case 3");
	}
	
	@AfterEach
	public void tearDown() {
		System.out.println("AfterEach - the annoted method executes after each test executes ");
		System.out.println("_________________________________________________________________\n");
	}
	
	@AfterAll
	public static void postClass() {
		System.out.println("@AfterAll - the annoted method runs once after all other methods execute");
	}

	

}
