package tstcs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class LoginTng 
{
	WebDriver driver;
	
	@BeforeTest
	void setup()
	{
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		driver=new ChromeDriver();

	}
	@Test(dataProvider="getData")
	void testcase1(String username,String pass) throws InterruptedException
	{
		
		
		
		driver.get("https://opensource-demo.orangehrmlive.com/");
		driver.manage().window().maximize();
		driver.findElement(By.id("txtUsername")).sendKeys(username);
		Thread.sleep(2000);
		driver.findElement(By.id("txtPassword")).sendKeys(pass);
		Thread.sleep(2000);
		driver.findElement(By.id("btnLogin")).click();
		//btnLogin
		//Thread.sleep(4000);*/
		
		/*
		Assert.assertTrue(true);
		Assert.assertTrue(false);
		Assert.assertFalse(false);
		Assert.assertFalse(true);
		Assert.assertEquals("abcd","ABCD");
		Assert.assertEquals("abcd","abcd");
		 */
	}
	
	@DataProvider
	Object[][] getData()
	{
		Object[][] data=new Object[3][2];
		data[0][0]="Admin";
		data[0][1]="admin123";
		data[1][0]="Admin2";
		data[1][1]="admin123";
		data[2][0]="Admin3";
		data[2][1]="admin123";
		return data;
				
	}
	
	@AfterTest
	void teardown()
	{
	//	driver.close();
	}
}
