package tstcs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class Muthread 
{
	WebDriver driver;
	@Test(priority=2)
	void testcas1() 
	{
		System.out.println("one");
		/*
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/");
		driver.findElement(By.id("tstUsername")).sendKeys("");
		driver.findElement(By.id("tstPassword")).sendKeys("");
		*/
	}
	@Test(priority=1)
	void testcas2() 
	{
		System.out.println("two");
		/*
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\poojasra\\Documents\\geckodriver\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		
		driver.get("https://opensource-demo.orangehrmlive.com/");
		driver.findElement(By.id("tstUsername")).sendKeys("");
		driver.findElement(By.id("tstPassword")).sendKeys("");
		*/
	}
	
}
