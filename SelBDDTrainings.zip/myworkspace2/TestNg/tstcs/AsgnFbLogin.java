package tstcs;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class AsgnFbLogin {
	
	    WebDriver driver;
	    
		@BeforeTest
		void setup() 
		{
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
			driver=new ChromeDriver();
			System.out.println("setup()");
		}
		@Test
		void testfb() throws InterruptedException 
		{
			driver.get("https://www.facebook.com/");
			driver.manage().window().maximize();
			Thread.sleep(3000);
			System.out.println("testfb() declaration");
			
			driver.findElement(By.partialLinkText("New Account")).click();
			Thread.sleep(3000);
			
			JavascriptExecutor js=(JavascriptExecutor) driver;
			
			
			//firstname //*[@id="u_26_b_Rp"]
			driver.findElement(By.xpath("//*[@name=\"firstname\"]")).sendKeys("Poojashree");
			//surname   //*[@id="u_26_d_G/"]
			driver.findElement(By.xpath("//*[@name=\"lastname\"]")).sendKeys("Rai");
			//mobilenum //*[@id="u_26_b_Rp"]
			driver.findElement(By.xpath("//*[@name=\"reg_email__\"]")).sendKeys("808080880808");
			//newpassword   //*[@id="password_step_input"]       reg_passwd__
			driver.findElement(By.xpath("//*[@name=\"reg_passwd__\"]")).sendKeys("Unity@123");
			//DOB
			driver.findElement(By.id("day")).click();
			driver.findElement(By.xpath("//option[@value=\"14\"]")).click();
			Thread.sleep(2000);//
			driver.findElement(By.id("month")).click();
			driver.findElement(By.xpath("//*[@id=\"month\"]/option[4]")).click();
			Thread.sleep(2000);
			driver.findElement(By.id("year")).click();
			driver.findElement(By.xpath("//option[@value=\"2000\"]")).click();
			Thread.sleep(2000);
			
			//Gender id u_2_6_AN
			driver.findElement(By.xpath("//label[text()=\"Custom\"]")).click();
			Thread.sleep(3000);
			driver.findElement(By.xpath("//select[@name=\"preferred_pronoun\"]")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//select[@name=\"preferred_pronoun\"]/option[4]")).click();
			
			js.executeScript("window.scrollBy(0,200)");
			//additional info name= custom_gender
			driver.findElement(By.xpath("//*[@name=\"custom_gender\"]")).sendKeys("She");
			
			
			Thread.sleep(3000);
			//driver.findElement(By.xpath("//input[@placeholder='Firstname']")).click();
			 //driver.findElement(By.xpath("//span[text()='First name']")).sendKeys("Poojashree");
			System.out.println("testfb() automating elements");
			Thread.sleep(3000);
		}
		@AfterTest
		void teardown() 
		{
			driver.close();
			System.out.println("teardown()");
		}

}
