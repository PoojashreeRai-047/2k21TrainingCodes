import java.util.Scanner;
public class Lar3nstif 
{

	public static void main(String[] args) 
	{
		int a,b,c;
		System.out.println("Largest of 3 numbers using Nested IF");
		Scanner sc= new Scanner(System.in);
		System.out.println("enter 1st number");
		a= sc.nextInt();
		System.out.println("enter 2nd number");
		b= sc.nextInt();
		System.out.println("enter 3rd number");
		c= sc.nextInt();
		if(a>b)
		{				
			if(a>c) 
			{
				System.out.println("A is Larger: "+a);
			}
			else 
			{ 
				System.out.println("C is Larger: "+c);
			}
		}
		else 
		{
			if(b>c) 
			{
				System.out.println("B is Larger: "+b);	
			}
			else 
			{
				System.out.println("C is Larger: "+c);
			}
			
		}
	}
}
