import java.util.Scanner;

public class Leapyr 
{
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int year;
		System.out.println("Check if given year is Leap year or not");
		Scanner sc= new Scanner(System.in);
		System.out.println("enter the year: ");
		year= sc.nextInt();
		
		if( (year%400 == 0)||( (year%4==0)&&(year%100!=0) ) ) 
		{
			System.out.println(year+" is a Leap year");
		}
		else 
		{
			System.out.println(year+" is Not a Leap year");
		}

	}

}
