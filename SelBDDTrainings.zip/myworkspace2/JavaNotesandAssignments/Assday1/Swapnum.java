import java.util.Scanner;

public class Swapnum 
{
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int a,b,temp;
		System.out.println("Swapping 2 numbers");
		Scanner sc= new Scanner(System.in);
		System.out.println("enter any 2 numbers");
		a= sc.nextInt();
		b=sc.nextInt();
		
		System.out.println("Before Swapping:\n A="+a +"\n B="+b);
		temp=a;
		a=b;
		b=temp;
		System.out.println("After Swapping:\n A="+a +"\n B="+b);
	}
}
