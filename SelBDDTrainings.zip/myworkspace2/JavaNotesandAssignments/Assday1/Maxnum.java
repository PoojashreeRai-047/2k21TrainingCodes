import java.util.Scanner;

class Lar{
	Lar(){
		int a,b,c;
		Scanner s= new Scanner(System.in);
		System.out.println("Enter the A value:");
		a=s.nextInt();
		System.out.println("Enter the B value:");
		b=s.nextInt();
		System.out.println("Enter the C value:");
		c=s.nextInt();
		if(a>b) {
			if(a>c) {
				System.out.println(a+" is larger");
			}
			else {
				System.out.println(c+" is larger");
			}
		}
		else {
			if(b>c) {
				System.out.println(b+" is larger");
			}
			else {
				System.out.println(c+" is larger");
			}
		}
	}
}
public class Maxnum {

	public static void main(String[] args) {
		Lar l = new Lar();
	}

}
