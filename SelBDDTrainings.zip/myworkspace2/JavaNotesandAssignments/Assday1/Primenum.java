 import java.util.Scanner;
public class Primenum 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int n  ;
		System.out.println("Check given number is Prime number or not ");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any number");
		n=sc.nextInt();
		
		boolean flag=false;
		for(int i=2; i<=n/2; ++i) 
		{
//			System.out.println(i+"#");
			if(n%i == 0) 
			{
				flag=true;
//				System.out.println(n +"*"+i+"*"+flag);
				break;
			}
		}
		
		if(!flag) 
		{
			System.out.println("The given number is a Prime Number");
		}
		else 
		{
			System.out.println("The given number is Not a Prime number");
		}
	}

}
