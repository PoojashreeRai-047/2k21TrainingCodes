import java.util.Scanner;
public class Evenodd 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Check given number is Even number or not");
		Scanner sc = new Scanner(System.in);
		int a;
		System.out.println("Enter any number");
		a=sc.nextInt();
		
		if(a%2==0) 
		{
			System.out.println("The number is an Even number");	
		}
		else
		{
			System.out.println("The number is Not an even number");
			
		}
		
	}

}
