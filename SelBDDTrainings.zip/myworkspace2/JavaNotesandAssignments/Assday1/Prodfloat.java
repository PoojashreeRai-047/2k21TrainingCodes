import java.util.Scanner;
public class Prodfloat
{
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Multiplication of 2 float numbers ");
		Scanner sc = new Scanner(System.in);
		float a,b;
		System.out.println("Enter any float value: ");
		a=sc.nextFloat();
		System.out.println("Enter any float value: ");
		b=sc.nextFloat();
		System.out.println("The Product of 2 float values is: "+ a*b );	
	}
}
