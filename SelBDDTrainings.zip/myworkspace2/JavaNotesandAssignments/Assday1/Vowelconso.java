import java.util.Scanner;

public class Vowelconso 
{
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		String c;
		System.out.println("To check if given char is Vowel or Consonent");
		Scanner sc= new Scanner(System.in);
		System.out.println("enter any character");
		c= sc.next();
		
		switch(c) {
		case "a" :
			System.out.println(c+" is a vowel");
			break;
		case "e" :
			System.out.println(c+" is a vowel");
			break;
		case "i" :
			System.out.println(c+" is a vowel");
			break;
		case "o" :
			System.out.println(c+" is a vowel");
			break;
		case "u" :
			System.out.println(c+" is a vowel");
			break;
		default:
			System.out.println(c+" is not a vowel \n its a consonent");
		}
	}
}
