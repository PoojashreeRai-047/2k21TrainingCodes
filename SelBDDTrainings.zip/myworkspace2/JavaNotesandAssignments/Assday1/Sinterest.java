import java.util.Scanner;
public class Sinterest 
{
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Calculation of Simple interest ");
		Scanner sc = new Scanner(System.in);
		float p,r,t;
		System.out.println("Enter the Principal Amount:");
		p=sc.nextFloat();
		System.out.println("Enter the Rate of Interest per Annum:");
		r=sc.nextFloat();
		System.out.println("Enter the Tenure Time:");
		t=sc.nextFloat();
		
		float simp=(p*r*t)/100;
		System.out.println("The Simple Interest:"+simp);
		float tot=simp+p;
		System.out.println("Total:"+ tot );
	}
}
