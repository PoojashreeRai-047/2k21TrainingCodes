import java.util.Scanner;

public class Disprime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		
		System.out.println("Display Prime numbers");
		Scanner sc= new Scanner(System.in);
		System.out.println("enter number");
		n= sc.nextInt();
		System.out.println("Prime Numbers From 1 to "+n+" are:");
		for(int i=2; i<=n; i++)
		{
//			
//			System.out.println(i);
		   int check = 0;
		   
		   for(int j=2; j<i; j++)
		   {
//			   
//     		   System.out.println(j +":"+ i);
		      if(i%j==0)
		      {
//		    	 
//				   System.out.println(j +"&"+ i);

		         check++;
		         break;
		      }
		   }
		   
		   if(check==0)
		      System.out.println(i);
//		   
//		   System.out.println("----------------------------");

		}
	}
}



