import java.util.Scanner;
public class Factorial 
{
	public static void main(String[] args) 
	{
		int n,i,fact=1;
		System.out.println("Factorial of a given number");
		Scanner sc= new Scanner(System.in);
		System.out.println("enter any number to calculate the factorial:");
		n= sc.nextInt();
		
		if(n<0) 
		{
			System.out.println("The number should be non negative value");
		}
		else 
		{
			for(i=1;i<=n;i++)
			{
//				System.out.println(i+"\n"+fact );
				fact=fact*i;
			}
			System.out.println("Factorial of "+n+" is "+fact);			
		}
		
	}

}
