import java.util.Scanner;
public class As_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 int a , b;
Scanner sc = new Scanner(System.in);

System.out.println("enter a number: ");
a=sc.nextInt();
System.out.println("enter a number: ");
b=sc.nextInt();
System.out.println("value of a: " + a);
System.out.println("value of b: " + b);
System.out.println("The sum of given numbers is " + (a+b));
	}

}
