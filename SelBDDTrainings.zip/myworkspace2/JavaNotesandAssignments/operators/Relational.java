
public class Relational {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=2, b=8;
		System.out.println("value of a: " + a);
		System.out.println("value of b: " + b);
	System.out.println("a==b  " + (a==b));
	System.out.println("a!=b  " + (a!=b));
	System.out.println("a>=b  " + (a>=b));
	System.out.println("a<=b  " + (a<=b));
	System.out.println("a<b  " + (a<b));
	System.out.println("a>b  " + (a>b));
	}}
