
public class Bitwise {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a = 5 , b = 3;
System.out.println("value of a: " + a);
System.out.println("value of b: " + b);
System.out.println("Bitwise AND " + (a&b));
System.out.println("Bitwise OR " + (a|b));
System.out.println("Bitwise NOT " + (a^b));
System.out.println("Bitwise XOR " + (~2));
// SHIFT OPERATOR
a=9; 
System.out.println("Left shift : " + (a<<2));
System.out.println("Right shift : " + (a>>2));
	}

}
