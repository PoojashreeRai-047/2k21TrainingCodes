
public class Instanceof {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Instanceof io = new Instanceof();
		// io is the obj ,
		// Instanceof is the class name
		// instanceof is the operator
		System.out.println(io instanceof Instanceof );
	}

}
