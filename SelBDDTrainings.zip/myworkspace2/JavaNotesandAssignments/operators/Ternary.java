
public class Ternary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a = 234 , b = 654;
System.out.println("value of a: " + a);
System.out.println("value of b: " + b);
String res;
res = (a==b) ? "a and b are equal" :"a and b are not equal";
System.out.println(res);
	}

}
