
public class Arithmetic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a = 50, b = 3;
System.out.println("value of a: " + a);
System.out.println("value of b: " + b);
System.out.println("A + B = "+(a+b));
System.out.println("A - B = "+(a-b));
System.out.println("A * B = "+(a*b));
System.out.println("A / B = "+(a/b));
System.out.println("A % B = "+(a%b));
System.out.println("The Value of A is :" +a);
System.out.println("The Value of B is :"+b);
	}

}
