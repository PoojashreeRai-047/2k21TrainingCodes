
public class Assigment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a , b;
a = 10;
b = 34;
System.out.println("value of a: " + a);
System.out.println("value of b: " + b);
System.out.println("a=a+1= " + (a+=1));
System.out.println("a=a-2= " + (a-=2));
System.out.println("a=a*3= " + (a*=3));
System.out.println("b=b/3= " + (b/=3));
System.out.println("b=b%2= " + (b%=2));
	}
}
