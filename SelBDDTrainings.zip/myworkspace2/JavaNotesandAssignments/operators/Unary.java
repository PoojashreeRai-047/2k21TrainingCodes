
public class Unary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a = 45, b = 23;
System.out.println("value of a: " + a);
System.out.println("value of b: " + b);
int inc,dec;
inc = ++a;
int inc1 =a++;
System.out.println("Postfix a "+ inc1 );
System.out.println("prefix a "+ inc );
dec= --b;
int dec1= b--;
System.out.println("Postfix b "+ dec1 );
System.out.println("prefix b "+ dec );
}

}
