
public class Logical {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=23, b=89, c=23;
System.out.println("value of a: " + a);
System.out.println("value of b: " + b);
// AND operator
System.out.println((a<b)&&(b>c));
System.out.println((a>b)&&(b>c));
System.out.println((9<b)&&(b>90));
System.out.println((32>2)&&(40<60));
// OR operator
System.out.println((a<b)||(b>c));
System.out.println((a>b)||(b>c));
System.out.println((9<b)||(b>90));
System.out.println((32>2)||(40<60));
// NOT operator
System.out.println(!(a==c));
System.out.println(!(!(a==c)));
	}

}
