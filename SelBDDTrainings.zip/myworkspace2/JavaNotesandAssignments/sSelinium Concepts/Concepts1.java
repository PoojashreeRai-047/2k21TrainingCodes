package sSelinium;

import static org.junit.Assert.assertEquals;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.junit.*;
import org.junit.jupiter.api.Order;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;
import org.testng.annotations.Test;

class ExeS
{
//	WebDriver driver=new ChromeDriver();  if error rises, cs()
	WebDriver driver ; ChromeOptions co;
	
	public void chromeSetter() 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\POOJASRA\\OneDrive - Capgemini\\Documents\\ChromeDriver\\chromedriver.exe");
		co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(co);	
		System.out.println("normal webdriver didn't work");
		System.out.println("used chromeOptions to execute");
	}
	public void PageloadTimeOut() 
	{
		// here it goes 
		//before the link to be executed, pgload is declared
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(1));
	}
	public void ImpliWait() 
	{
//		Code will wait for 30secs b4 throwing element not found exception
//		Applied to every element of the code , As its at driver level
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	public void ExpliWait() 
	{    
		//Explicit Wait :prefered than impli : to only selected elements
		WebElement singin= driver.findElement(By.linkText("Sign In"));
		Wait<WebDriver> wait1= new WebDriverWait(driver,Duration.ofSeconds(10));
		wait1.until(ExpectedConditions.elementToBeClickable(singin)).click();
		
        //Fluent wait: type of explicit wait
		Wait<WebDriver> wait2= new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(30))
				.pollingEvery(Duration.ofSeconds(5))
				.ignoring(NoSuchElementException.class);

	}

	public void geturlTutpoint() 
	{
		driver.get("https://www.tutorialspoint.com/index.htm");
	}	
	public void ScreenView() 
	{
		driver.manage().window().maximize();
		driver.manage().window().minimize();
		driver.manage().window().fullscreen();
		driver.manage().window().setSize(new Dimension(320,313));
		
		
		driver.manage().window().maximize();
	}
	public void navigateWindow() 
	{
		driver.navigate().to("https://www.facebook.com/");
		driver.navigate().back();
		driver.navigate().forward();
		driver.navigate().refresh();
	}
	public void locator() 
	{
		//findElement: finds 1st matching element
		driver.findElement(By.id("")).click();
		driver.findElement(By.name("")).click();
		driver.findElement(By.className("")).click();  
		// Compound Classes (Names) are not allowed 
		driver.findElement(By.linkText("")).click();
		driver.findElement(By.partialLinkText("")).click();
		driver.findElement(By.tagName("")).click();
		//Tagname locator executes first found tag	
		
//		CSS Selector faster than xpath
		driver.findElement(By.cssSelector("")).sendKeys("");
//		cssSelector = "tagname[attribute='value']" 
//		ex:           "input[id='txtUsername']"
//		cssSelector = tagname#id
//		ex:   "input#txtPassword"
		
//		Xpath has property to reverse an axes, ex: child to parent
		driver.findElement(By.xpath("")).sendKeys("");
//		 xpath= "// input_tagname [@attribute='value']"
//		 ex: "//*[@id='email']"
		
		//=========================
		
		//findElementS: finds list of matching elementS BY DEFAULT
		List<WebElement> ELEMENTS = driver.findElements(By.id(""));
		for(WebElement i :ELEMENTS ) 
		{
			
		}
	}
	public void diffXpaths() 
	{
		//Absolute X-path: complex and temporary
//		X-path 
		driver.findElement(By.xpath("//*[@id=\"side\"]/div[1]/div/label/div/div[2]"));
//		full X-path
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div[3]/div/div[1]/div/label/div/div[2]"));
		
		//Relative X-path: Understandable and permanent
		driver.findElement(By.xpath("//div[@role='textbox']"));
//		                             tagname[@attribute='value']
	}
	public void XpathValidation() 
	{
/*		
      @ Browser Console
		$x//div[@role='textbox']
		� $x() { [native code] }
		
		
		$x("//tagname[@attribute='value']")
ex   :  $x("//input[@id='email']")
        $x("//*[@name='username']")
        
		
		$$//div[@role='textbox']
		� $$() { [native code] }
  */		
	}
	public void XpathValidationMethods()
	{
//		whatsappp
		
//    $x("//tagname[@role or attribute='value']")

//     $x("//*[@id='pane-side']/button/div/div[2]/following-sibling::*")
//     [div._3OvU8._1BgCC]
     
//     $x("//*[@id='pane-side']/button/div/div[2]/following-sibling::*/preceding-sibling::*")"
//     (2)�[div._3OvU8, div._2EU3r]
		
//		$x("//*[@id='pane-side']/button/div/div[2]/following-sibling::*/preceding-sibling::*/parent::*")
//		[div._2nY6U._1frFQ]
		
//		$x("//*[@id='pane-side']/button/div/div[2]/following-sibling::*/preceding-sibling::*/parent::*/child::*")
//		(3)�[div._2EU3r, div._3OvU8, div._3OvU8._1BgCC]
     
//     contains()
//		        $x("//*[contains(@id,'pane-side')]")
//		        [div#pane-side._3Bc7H._20c87]
		
		
		
		
				
//	   starts with()
//				$x("//*[starts-with(@id,'pane-side')]")
//				[div#pane-side._3Bc7H._20c87]
				
//		text()
//				$x("//*[text()='Missed video call at 11:08 pm']")
//				[span.i0jNr]
				
//	    and() 
//				$x("//*[text()='Missed video call at 11:08 pm' and @class='i0jNr']")
//				[span.i0jNr]
				
//		or() 
//		        $x("//*[text()='Missed video call at 11:08 pm' or @class='i0jNr']")
//		        (4)�[span.i0jNr, span.i0jNr, span.i0jNr, span.i0jNr]

		
  		
	}
	public void CssSelectorValidation() 
	{
//		$x("//div[@class='YtmXM']")
//		  [div.YtmXM]
		
//		$$("div[class='YtmXM']")
//		[div.YtmXM]
	}
	
	public void waitForExecution(int TimeGap) throws InterruptedException 
	{
		Thread.sleep(TimeGap);
	}
	

	public void jscriptCode() 
	{
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,400)");
		js.executeScript("document.elementFromPoint(0,10).click()");
	}
	public void getMethodsDriverLevel() 
	{
		driver.get("https://www.facebook.com/");
		//url and title of the web page.
		System.out.println(driver.getCurrentUrl());
		System.out.println(driver.getTitle());
		
		//for login button name="login"
		System.out.println(driver.findElement(By.name("login")));
		WebElement loginbtn=driver.findElement(By.name("login"));
		System.out.println(loginbtn.getAccessibleName());
		System.out.println(loginbtn.getAriaRole());
		System.out.println(loginbtn.getAttribute("id"));
		System.out.println(loginbtn.getCssValue("color"));
		System.out.println(loginbtn.getCssValue("font"));
		
		
		System.out.println("****************");
		System.out.println(loginbtn.getDomAttribute("value"));
		System.out.println(loginbtn.getDomProperty("innerHTML"));
		System.out.println(loginbtn.getDomAttribute("text"));
		System.out.println(loginbtn.getTagName());
		System.out.println(loginbtn.getText());
		System.out.println("****************");
		System.out.println(loginbtn.isDisplayed());
		System.out.println(loginbtn.isEnabled());
		System.out.println(loginbtn.isSelected());
		System.out.println(loginbtn.getLocation().getX());
		System.out.println(loginbtn.getRect().getHeight());
		System.out.println("****************");
	}
	
	
	public void dateSelection() 
	{
//		Selecting dates using Drag and Drop Actions
		List <WebElement> dates= driver.findElements(By.className("DateRangePicker__DateLabel"));
		WebElement drag= null,drop=null;
		boolean isDragSelected= false;
		boolean isDropSelected= false;
		
		for(WebElement date : dates) 
		{
			if(date.getText().equals("28"))
			{
				//drag=date;
				date.click();
				//isDragSelected= true;
			}
			if(date.getText().equals("31"))
			{
				//drop=date;
				date.click();
				//isDropSelected= true;
			}
		}
		Actions act =new Actions(driver);
		act.dragAndDrop(drag, drop).build().perform();	
	}
	
//=========================
	public void dif_WE_declarations() 
	{
//		@FindBy() and By.
	}
	
	@FindBy(name="email")
	WebElement email;
	public ExeS(WebDriver driver)
	{
		AjaxElementLocatorFactory factory=new AjaxElementLocatorFactory(driver,10);
		PageFactory.initElements(driver, this);
	}
	public WebElement getEmail()
	{
		return email;
	}
//	__________________________
	By username = By.id("txtUsername");
	public WebElement username1() 
	{
		return driver.findElement(username);
	}
//	==================
	
	public void formHandlin() 
	{
//		input 
		driver.findElement(By.id("")).sendKeys("");
//		radio
		driver.findElement(By.name("")).click();
//		date using drag&drop() and select{}
		
//		check box  
		driver.findElement(By.name("")).click();
//		list
		driver.findElements(By.xpath("//li[@role='option']")).get(0).click();

//		drop down 
		WebElement selectDropDownOption= driver.findElement(By.name(""));
		Select country = new Select(selectDropDownOption);
		
		
		country.selectByVisibleText("Italy");
		country.selectByIndex(4);
		country.selectByValue("9");
	}
	public void switching() 
	{
		driver.switchTo().activeElement();
		driver.switchTo().alert();
		driver.switchTo().frame(0);
		driver.switchTo().newWindow(null);
		driver.switchTo().parentFrame();
	}
	public void alerts_POPUPS() 
	{
		driver.findElement(By.id("alert")).click();
		
		Alert alertbox= driver.switchTo().alert();
		System.out.println(alertbox.getText());
		alertbox.sendKeys("");
		alertbox.accept();
		alertbox.dismiss();
		
	}
	public void frames() 
	{
		WebElement frmName= driver.findElement(By.tagName("AnyFrame"));
		driver.switchTo().frame(frmName);
		
		WebElement drag= driver.findElement(By.id("draggable element"));
		WebElement drop= driver.findElement(By.id("droppable element"));
		
		Actions act=new Actions(driver);
		act.dragAndDrop(drag, drop).build().perform();

	}
	public void mouseHovering() 
	{
		WebElement pointer = driver.findElement(By.id(""));
		Actions act=new Actions(driver);
		act.moveToElement(pointer).build().perform();
	}
	public void keyboardINTERACTIONS() 
	{
		WebElement keypresser=driver.findElement(By.id(""));
		Actions act=new Actions(driver);
		act.keyDown(Keys.SHIFT).build().perform();
		keypresser.sendKeys("hello");
		act.keyUp(Keys.SHIFT).build().perform();
		keypresser.sendKeys("hello");
	}
	public void windowHandling() 
	{
//		get 1st url
//		then open 2nd url from first
		Set<String> windows = driver.getWindowHandles();
		Iterator<String> it = windows.iterator();
		
		String parentWindow= it.next();
		String childWindow = it.next();
		
		driver.switchTo().window(childWindow);
		driver.switchTo().window(parentWindow);
		driver.switchTo().window(childWindow);

//		driver.quit();
//		if driver.quit exists
//		then the browser completely closed not the single window
		
		// control at child window
		driver.close();
		
		driver.switchTo().window(parentWindow);
		// control at parent window
		driver.close();	
	}
	public void screenshot() throws IOException
	{
		File src1=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src1, new File("./image.png"));
		System.out.println("png done\n********************");

		File src2=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src2, new File("./image.jpg"));
		System.out.println("jpg done\n********************");
		
		File src3=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src3, new File("./image.jpeg"));
		System.out.println("jpeg done\n********************");
	}
	
	public void BrokenLinkConcept() throws MalformedURLException, IOException 
	{
		//Footer list class="footer-nav"
				driver.findElement(By.className("footer-nav"));
				WebElement ftr = driver.findElement(By.className("footer-nav"));
		//morethan one element
				List<WebElement> list = ftr.findElements(By.tagName("a"));
		  
				for(WebElement links:list) 
				{
					HttpURLConnection con= (HttpURLConnection) new URL(links.getAttribute("href")).openConnection();
					con.setRequestMethod("GET");
					con.connect();
					
					if(con.getResponseCode()==401||con.getResponseCode()==402||con.getResponseCode()==403) 
					{
						System.out.println(links.getText()+": Not Working");
					}
					else 
					{
						System.out.println(links.getText()+": Working");
					}
				}
	}
	public void Gridcapabilities() throws MalformedURLException 
	{
		String baseURL = "https://www.geeksforgeeks.org/";
		String nodeURL = "http://localhost:4444/wd/hub";
		DesiredCapabilities capability =new DesiredCapabilities();
		capability.setBrowserName("chrome");
		capability.setPlatform(Platform.WINDOWS);
		WebDriver driver = new RemoteWebDriver(new URL(nodeURL),capability);
		driver.get(baseURL);
	}	
	public void ChromeOptions() throws AWTException 
	{
		//CODE1
				Map<String, Object> prefs = new HashMap<String, Object>();
				//add key and value to map as follow to switch off browser notification
				//Pass the argument 1 to allow and 2 to block
				 prefs.put("profile.default_content_setting_values.notifications", 2);
				 //prefs.put("profile.default_content_setting_values.geolocation", 2);

				 //Create an instance of ChromeOptions
				 ChromeOptions options = new ChromeOptions();
				 options.addArguments("--disable-notifications");
				 // set ExperimentalOption - prefs
				 options.setExperimentalOption("prefs", prefs);
				 WebDriver driver=new ChromeDriver(options);
				 driver.get("https://www.spicejet.com/");

				 
		 //CODE2
//				Thread.sleep(3000);
				Robot robot = new Robot();
				//robot.delay(5000);
				robot.keyPress(KeyEvent.VK_TAB);
				robot.keyPress(KeyEvent.VK_ENTER);
				robot.keyRelease(KeyEvent.VK_TAB);
				robot.keyPress(KeyEvent.VK_ENTER);
				
	}
	
	
	public void closeWindow() 
	{
		driver.close();
//		closes single window of the browser
	}
	public void quitChrome() 
	{
		driver.quit();
//		closes the browser
	}
	

	public void firefoxSetter() 
	{
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\poojasra\\Documents\\geckodriver\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
	}
	public void edgeSetter() 
	{
		System.setProperty("webdriver.edge.driver", "C:\\Users\\poojasra\\Documents\\edgedriver\\msedgedriver.exe");
		WebDriver driver=new EdgeDriver();
	}
	public void explorerSetter() 
	{
		System.setProperty("webdriver.ie.driver", "C:\\Users\\poojasra\\Documents\\IEDriverServer\\IEDriverServer.exe");
		WebDriver driver=new InternetExplorerDriver();
	}
	
	public String ReadExcelFileURL() throws IOException 
	{
		Properties prop=new Properties();
		FileInputStream file=new FileInputStream("C:\\Users\\poojasra\\eclipse-workspace\\Selenium\\data.properties");
		prop.load(file);
		return prop.getProperty("url");
		//url=https://www.facebook.com/
	}
}
class JunitInfo
{
	WebDriver driver;
	
	@Before
	public void setup() {}
	@Test
	@Order(2)
	public void testA() {}
	@Test
	@Order(1)
	public void testB() {}
	@After
	public void teardown() {}
	
	public void assertMethods() 
	{
		assertEquals(driver.switchTo().alert().getText(),("Please share this website with your friends and in your organization."));
	}
	
}
class selGrid
{
	public void GridImplementation() throws MalformedURLException 
	{
		String baseURL = "https://www.geeksforgeeks.org/";
		String nodeURL = "http://localhost:4444/wd/hub";
		DesiredCapabilities capability =new DesiredCapabilities();
		capability.setBrowserName("chrome");
		capability.setPlatform(Platform.WINDOWS);
		WebDriver driver = new RemoteWebDriver(new URL(nodeURL),capability);
		driver.get(baseURL);
	}
}
class TestngMultiThreading
{
	@BeforeTest
	public void setup() {}
//	Multi Threading using priority And Assert()
	@Test(priority=2)
	void tst1() {}
	@Test(priority=1)
	void tst2() 
	{
		Assert.assertTrue(true);
		Assert.assertTrue(false);
		Assert.assertFalse(false);
		Assert.assertFalse(true);
		Assert.assertEquals("abcd","ABCD");
		Assert.assertEquals("abcd","abcd");
	}
}
class TestngDataProvider
{
	WebDriver driver;
	@BeforeTest
	public void setup() {}
//	Data Provider - 3 testCases are executed
	@Test(dataProvider="getData")
	void testcase1(String username,String pass) throws InterruptedException
	{
		driver.get("https://opensource-demo.orangehrmlive.com/");
		
		driver.findElement(By.id("txtUsername")).sendKeys(username);
		driver.findElement(By.id("txtPassword")).sendKeys(pass);
		driver.findElement(By.id("btnLogin")).click();
	}
	@DataProvider
	Object[][] getData()
	{
		Object[][] data=new Object[3][2];
		data[0][0]="Admin";
		data[0][1]="admin123";
		data[1][0]="Admin2";
		data[1][1]="admin123";
		data[2][0]="Admin3";
		data[2][1]="admin123";
		return data;		
	}
	
}
public class Concepts1 
{	
	public static void main(String[] args) throws InterruptedException 
	{
		ExeS e=new ExeS(null);

		e.chromeSetter();
		e.geturlTutpoint();
		e.ScreenView();
		e.navigateWindow();
		e.waitForExecution(3000);
//		e.closeWindow();
		e.quitChrome();
		
	}
	
	
	/*
	 *     public void abc(){}
	 *     driver.findElement(By("")).click();
	 *     
	       System.out.println("ddone");
	       Thread.sleep(4000);  driver.close();
	 *     
	 *            
//                 ********

			System.out.println("Print Statements");
			
//			       ******
	 */
	
}
