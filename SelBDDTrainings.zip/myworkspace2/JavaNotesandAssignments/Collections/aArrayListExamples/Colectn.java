package aArrayListExamples;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

class De
{
	public De()
	{
		System.out.println("df-constructor");
	}	
	public  ArrayList<String> arrlist() 
	{
	ArrayList<String> moblilist = new ArrayList();
	System.out.println("ArrayList is created: "+moblilist);
	
	moblilist.add("Samsung");
	moblilist.add("LG");
	moblilist.add("Oppo");
	moblilist.add(null);
	moblilist.add("MI");
	System.out.println("Elements added: "+moblilist);
	
	moblilist.add(2, "xiomi");
	System.out.println("Element added @ index 2: "+moblilist);
	
	ArrayList<String> moblilist2 =(ArrayList<String>) moblilist.clone();
	System.out.println("cloned Arraylist: "+moblilist2);
	
	moblilist2.clear();
	System.out.println("cleared Arraylist: "+moblilist2);
	
	System.out.println("Checking Arlist1 contains \"MI\" : "+moblilist.contains("MI"));
	System.out.println("Get element 3 index : "+moblilist.get(3)+ "\n"+ moblilist);
	System.out.println("Set element : "+moblilist.set(3, "ONIDA") + "\n"+moblilist);
	System.out.println("HashCode of Arlst : "+ "\n"+moblilist.hashCode());
	System.out.println("Index of LG : "+ "\n"+moblilist.indexOf("LG"));
	System.out.println("LastIndex of ArLst : "+moblilist.lastIndexOf(moblilist));
	System.out.println("Remove Element @ 1 : " +moblilist.remove(1)+"\n"+moblilist);
	System.out.println( "Remove Element ONIDA : "+moblilist.remove("ONIDA")+ "\n"+moblilist);

	System.out.println("Size of Arlst : "+moblilist.size()+ "\n"+moblilist);
	
//	System.out.println(" : "+moblilist);
	return moblilist;
	}	
}


class Lstintfc
{
	public Lstintfc() { System.out.println(" Def: Constructor ");}
	public List<String> lt() 
	{
		List<String> L1= new ArrayList<String>();
		System.out.println("List Created: "+L1);
		
		//list allows null and duplicate values, maintains insertion order
		L1.add(null);
		L1.add("elmnt 4");
		L1.add("elmnt 1");
		L1.add(null);
		L1.add("elmnt 4");
		L1.add("elmnt 1");
		L1.add("elmt 3");
		System.out.println("Added Null&Duplicate Values: \n"+L1);
		
		System.out.println(" Accessing element @ 4: "+L1.get(4));
		System.out.println(" Accessing element @ 6: "+L1.get(6));

//		System.out.println(" : "+L1);		
		return L1;
	}
	
}
class ArList
{
	private List<Integer> subarlst;
	public ArList() { System.out.println(" Def: Constructor ");}
	public  List<Integer> Alt() 
	{
		List<Integer> Arlst=new ArrayList<>(); 
		System.out.println("ArrayList is created: "+Arlst+"  Size="+Arlst.size());
		
		System.out.println("Is the Array Empty? : "+Arlst.isEmpty());
		
		
		Arlst.add(3);
		Arlst.add(35);
		Arlst.add(3);
		Arlst.add(null);
		Arlst.add(56);
		Arlst.add(null);
		Arlst.add(78);
		System.out.println("\nAdded elements: "+Arlst+"\nSize="+Arlst.size());
		System.out.println("Get element @ 2 : "+Arlst.get(2));
		System.out.println("Is the Array Empty? : "+Arlst.isEmpty());
	    System.out.println("Does Contains 56 elmnt :"+Arlst.contains(56));
		System.out.println("\nModification:\n"+Arlst+"\nSet element @ 2 : "+Arlst.set(2, 3879)+"\n"+Arlst);
		System.out.println("Remove element @ 3 : "+Arlst.remove(3)+"\n"+Arlst+"\nSize="+Arlst.size());
		System.out.println("Remove(object) : true \n if the element specified is removed ");
		
		
		subarlst = new ArrayList<>();
		subarlst.add(3);
		subarlst.add(3879);
		System.out.println("\n\nArrayList is created: "+subarlst+"\nSize="+subarlst.size());
	    System.out.println("Does Arlst Contains Subarlst :"+Arlst.contains(subarlst));

		System.out.println("RemoveAll() : "+Arlst.removeAll(subarlst));
		System.out.println("The clear() clears the Array:\n"+Arlst+"\nClear() : ");
		Arlst.clear();
	    System.out.println(Arlst);
	    
		return Arlst;
	}
	public  List<Integer> Alt2() 
	{
		List<Integer> PrimenumS1st5=new ArrayList<>();
		System.out.println("First 5 Prime num Array is created: \n"+PrimenumS1st5+"  Size="+PrimenumS1st5.size());
		PrimenumS1st5.add(2);
		PrimenumS1st5.add(3);
		PrimenumS1st5.add(5);
		PrimenumS1st5.add(7);
		PrimenumS1st5.add(11);
		System.out.println("Adding First 5 Prime nums to Array: \n"+PrimenumS1st5+"  Size="+PrimenumS1st5.size());

		List<Integer> PrimenumS1st10=new ArrayList<>(PrimenumS1st5);
		System.out.println("First 10 Prime num Array is created: \n"+PrimenumS1st10+"  Size="+PrimenumS1st10.size());
		

		List<Integer> Nxt5PrimenumS=new ArrayList<>();
		System.out.println("Next 5 Prime num Array is created: \n"+Nxt5PrimenumS+"  Size="+Nxt5PrimenumS.size());
		Nxt5PrimenumS.add(13);
		Nxt5PrimenumS.add(17);
		Nxt5PrimenumS.add(19);
		Nxt5PrimenumS.add(23);
		Nxt5PrimenumS.add(29);
		System.out.println("Adding Next 5 Prime nums to Array: \n"+Nxt5PrimenumS+"  Size="+Nxt5PrimenumS.size());
		
		PrimenumS1st10.addAll(Nxt5PrimenumS);
		System.out.println("Adding 2 existing Arrays to this array: \n"+PrimenumS1st10+"  Size="+PrimenumS1st10.size());

		return PrimenumS1st10; 
	}
}
class Loopsss
{
	public Loopsss() {System.out.println(" Def: Constructor ");}
	
	public List<String> BasicLooping() 
	{
		
		List<String> vehicles = new ArrayList();
		vehicles.add("yamaha");
		vehicles.add("bajaj");
		vehicles.add("maruthi");
		vehicles.add("suzuki");
		vehicles.add("honda");
		vehicles.add("wolksVagen");
		vehicles.add("renault");
		vehicles.add("ford");
		System.out.println("Arraylist:\n"+vehicles+"\n"+vehicles.size());
		
	 
//	 For loop	
		System.out.println("\nForLoop:\n");
		for(int i=0;i<vehicles.size();i++) 
		{
			System.out.println(vehicles.get(i));
		}
		
		
//		Enhanced ForEach loop
		System.out.println("\nEnhanced ForEach Loop:\n");
		for(String elnam:vehicles) 
		{
			System.out.println(elnam);
		}
		
		
//		  While loop using iterator
		System.out.println("\nWhile Loop with Iterator:\n");
		 Iterator<String> itr = vehicles.iterator();
		 while(itr.hasNext()) 
		 {
			 String elname=itr.next();
			 System.out.println(elname);
		 }
		
		
		
		return vehicles;
	}
	public List<String> StreamswithLambda() 
	{
		
		List<String> vehicles = new ArrayList();
		vehicles.add("yamaha");
		vehicles.add("bajaj");
		vehicles.add("maruthi");
		vehicles.add("suzuki");
		vehicles.add("honda");
		vehicles.add("wolksVagen");
		vehicles.add("renault");
		vehicles.add("ford");
		System.out.println("Arraylist:\n"+vehicles+"\n"+vehicles.size());
		
//		ForEach Lambda
		System.out.println("\nEnhanced ForEach Loop Using Lambda  :\n");
		vehicles.forEach(elnmae -> System.out.println(elnmae));
//		ForEach : Streams and Lambda
		System.out.println("\nEnhanced ForEach Loop Using: Streams and Lambda\n");
		vehicles.stream().forEach(elnmae -> System.out.println(elnmae));
		
		return vehicles;
	}
}
class Sortinglist
{
	public Sortinglist() { System.out.println(" Def: Constructor ");}
	public  List<Integer> list1Ordering() 
	{
		List<Integer> odrer=new ArrayList();
		odrer.add(10);
		odrer.add(100);
		odrer.add(40);
		odrer.add(80);
		odrer.add(60);
		System.out.println(odrer);
		
		//Ascending Order : By Default using sort()
		Collections.sort(odrer);
		System.out.println("Ascending Order  :"+odrer);
		//Reverse() to get Descending Order
		Collections.reverse(odrer);
		System.out.println("Descending Order :"+odrer);
		
		return odrer;
	}
}



public class Colectn 
{
	public static void main(String[] args) 
	{
		De list=new De();
		list.arrlist();
		System.out.println("********************************");	
		
		Lstintfc l2=new Lstintfc();
		l2.lt();
		System.out.println("********************************");	
		
		ArList l3=new ArList();
		l3.Alt();
		l3.Alt2();
		System.out.println("********************************");	
		
		Loopsss lp=new Loopsss();
		lp.BasicLooping();
		lp.StreamswithLambda();
		System.out.println("********************************");	
		
		Sortinglist ordering=new Sortinglist();
		ordering.list1Ordering();	
	}
}
