package lLinkedListExamples;

import java.util.Iterator;
import java.util.LinkedList;

class L1
{
	public L1() {System.out.println("def cons");}
	public LinkedList<String> add_Rtrv_Ele() 
	{
		System.out.println("\n\n**********************Add and Get**********************");

		LinkedList<String> Snacks=new LinkedList();
		
		//Add elements
		Snacks.add("Samosa");
		Snacks.add("Kachori");
		Snacks.add("Pakoda");
		Snacks.add("Murkulu");
		System.out.println(Snacks);
		
		//Add @ Index
		Snacks.add(2, "MishtiDhoi");
		
		//Add @ First
		Snacks.addFirst("Rasgoolla"); 
		
		//Add @ Last
		Snacks.addLast("Gulab_Jamun");  
		System.out.println(Snacks);
		
		
		//Get @ Index	
		System.out.println("\n\nRetrieving Elements:\n@ 2"+Snacks.get(2));
		
		//Get @ First
		System.out.println("First element"+Snacks.getFirst());

		//Get @ Last
		System.out.println("Last element"+Snacks.getLast());
		
		// Get All
		System.out.println("\n\nAll elements of linked list:  Size="+Snacks.size());
		for(String Elmts: Snacks ) 
		{
			System.out.println(Elmts);
		}
		
		return Snacks;
	}
	public LinkedList<String> Remove_clear() 
	{
		System.out.println("\n\n**********************Removing and Clear**********************");

		LinkedList<String> Snacks=new LinkedList();
		
		//Add elements
		Snacks.add("Samosa");
		Snacks.add("Kachori");
		Snacks.add("Pakoda");
		Snacks.add("Murkulu");
		Snacks.add(2, "MishtiDhoi");
		Snacks.addFirst("Rasgoolla"); 
		System.out.println(Snacks);

		System.out.println("\nRemoval of Elements:   Size="+Snacks.size());
		
		//Remove @ First
		System.out.println("First Ele: "+Snacks.removeFirst()+"   Size="+Snacks.size());
		//Remove @ last
		System.out.println("Lsst Ele: "+Snacks.removeLast()+"   Size="+Snacks.size());
		//Remove @ Index
		System.out.println("3 Ele: "+Snacks.remove(3)+"   Size="+Snacks.size());
		//Remove object
		System.out.println("Kachori Ele: "+Snacks.remove("Kachori")+"   Size="+Snacks.size());
		//Clear list
		System.out.println("\n\nLinkedList:"+Snacks+"   Size="+Snacks.size());
		System.out.println("Is LinkedList Empty:"+Snacks.isEmpty());

		Snacks.clear();
		System.out.println("Cleared list Ele: "+Snacks+"   Size="+Snacks.size());
		System.out.println("Is LinkedList Empty:"+Snacks.isEmpty());


		
		
		return Snacks;
	}
	public LinkedList<String> ItrtnLst() 
	{
		System.out.println("\n\n**********************Iteration**********************");

		LinkedList<String> Snacks=new LinkedList();
		
		//Add elements
		Snacks.add("Samosa");
		Snacks.add("Kachori");
		Snacks.add("Pakoda");
		Snacks.add("Pakoda");
		Snacks.add("Pakoda");
		Snacks.add("Pakoda");
		Snacks.add("Murkulu");
		Snacks.add(2, "MishtiDhoi");
		Snacks.addFirst("Rasgoolla"); 
		System.out.println(Snacks + "\nSize="+Snacks.size()+"\n");
		
		//contains obj
		System.out.println("Does Contains obj:Pakod:"+Snacks.contains("Pakoda"));
		//indexof
		System.out.println("The Index of Pakoda:"+Snacks.indexOf("Pakoda"));
		//lastIndex of
		System.out.println("The last_Index of Pakoda:"+Snacks.lastIndexOf("Pakoda"));
		
		//Iterator
		System.out.println("\n-----------------\nIteration using while loop:");
		Iterator<String> itr=Snacks.iterator();
		while(itr.hasNext()) 
		{
			String elemt=itr.next();
			System.out.println(elemt);
		}
		
		//Simple For 
		System.out.println("\n-----------------\nSimple For loop:");
		for(int i=0;i<Snacks.size();i++) 
		{
			System.out.println(Snacks.get(i));
		}	
		
		//Advance for loop -each
		System.out.println("\n-----------------\nFor each loop:");
		for(String elmt: Snacks) 
		{
			System.out.println(elmt);
		}
		
		//ForEach()- lambda
		System.out.println("\n-----------------\nForEach loop:");
		Snacks.forEach(elemts -> {System.out.println(elemts);});
		
		
		return Snacks;
	}

}
public class LLLL 
{
	public static void main(String[] args) 
	{
	L1 l1 = new L1();
	l1.add_Rtrv_Ele();
	l1.Remove_clear();
	l1.ItrtnLst();
	}
}
