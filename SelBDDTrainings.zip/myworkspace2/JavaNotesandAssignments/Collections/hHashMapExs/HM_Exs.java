package hHashMapExs;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class HM_Exs {
	public static Map<Integer,String> Cretn_AdElmtHM() 
	{		
		System.out.println("\n\n*************Creation,Adding Elements***********************");

		Map<Integer,String> nums1 = new HashMap();
		
		System.out.println("Is Map emtpy: "+nums1.isEmpty());
		
		//adding elements=(key,value) using put(Integer,"String")
		nums1.put(1, "Elmntput"+"1");
		nums1.put(1, "Elmntput"+"1");
		System.out.println(nums1+"\n");

		nums1.put(null, null);
		nums1.put(null, null);
		System.out.println(nums1);
		System.out.println("null key&value Accepted\n");

		nums1.put(7, "Elmntput"+"1");
		System.out.print(nums1+" But duplicate keys are NOT!!\nkeys are unique\nvalues can be duplicate\n\n");
		
		nums1.put(2, null);
		System.out.println(nums1);
		nums1.put(null, "two");
		System.out.println(nums1);
		nums1.put(null, "tw0o");
		System.out.println(nums1);


		
		System.out.println(">1 key =null, then key with value added at last is considered or overriden\nOnly one null key is supported\n");
//		for(int i=2;i<=10;i++) {nums1.put(i, "Elmntput"+i);}
		nums1.put(3, "Elmntput"+"1");
		nums1.put(4, "Elmntput"+"1");
		nums1.put(15, "Elmntput"+"1");
		nums1.put(16, "Elmntput"+"1");
		System.out.println(nums1+"\n");
		System.out.println("!!!!UNORDERED!!!!\n");
		
		System.out.println("Is Map emtpy: "+nums1.isEmpty()+ "   Size="+ nums1.size());
		
		System.out.print("\nIs Map Exists :key=16: ");
		if(nums1.containsKey(16)) {System.out.print("yes");}
		else {System.out.print("no");}
		
		System.out.print("\nIs Map Exists :value = Elmntput1 : ");
		if(nums1.containsValue("Elmntput"+"1")) {System.out.print("yes");}
		else {System.out.print("no");}
		
		
		return nums1;
	}
	public static Map<Integer,String> Accs_RtrvHM()
	{
		System.out.println("\n\n*************Access,Retrieve,Get,Remove***********************");

		Map<Integer,String> nums2 = new HashMap();
		for(int i=1;i<=10;i++) {nums2.put(i, "Elmntput"+i);}
		System.out.println(nums2);
		
		//get() by key and value
		System.out.println("\nGet @ key=9: "+nums2.get(9));
//		System.out.println("Get @ value=Elmntput5: "+nums2.get("Elmnt"));
//		           ------------- didnt work------------
		
		//get All Keys/- of hash Map
		System.out.println("\n\n************************************\n\n");
		System.out.println("\nGet All keys: "+nums2.keySet());
		//get All Values/- of hash Map
		
		Collection<String> w=nums2.values();
		System.out.println("Get All values: "+w);
//		System.out.println("Get All values: "+nums2.values());
		System.out.println("\n\n************************************\n\n");
		
		//remove()  by key and value
		System.out.println("\nRemove @ key=3: "+nums2.remove(3)+"\n"+nums2);
		System.out.println("Remove @ key=7: "+nums2.remove(7, "Elmntput7")+"\n"+nums2);
		
		
		
		return nums2;	
	}
	public static Map<Integer,String> ItrHM()
	{
		System.out.println("\n\n*************Iterations***********************");
		Map<Integer,String> nums3=new HashMap();
		for(int i=1;i<=10;i++) {nums3.put(i, "HmS"+i);}
		System.out.println(nums3);
		
		//Iterations
		//for each loop
		System.out.println("\nEnhanced For Loop____________");
		for(Map.Entry<Integer, String> elmnt:nums3.entrySet()) 
		{
			System.out.println("key= "+elmnt.getKey()+" value= "+elmnt.getValue());
		}
		
		//using set iterator with while loop
		System.out.println("\nIterator with While Loop____________");
//		Iterator itr=nums3.entrySet().iterator();
		Set<Map.Entry<Integer, String>> Elmset=nums3.entrySet();
		Iterator<Map.Entry<Integer, String>> itr=Elmset.iterator();
		while(itr.hasNext()) 
		{
			Map.Entry<Integer, String> elmnts=itr.next();
			System.out.println("key="+elmnts.getKey()+" values= "+elmnts.getValue());
		}
		
		//ForEach()
		System.out.println("ForEach()---------------");
		nums3.forEach((K,V)->{System.out.println("K:"+K+" V:"+V);});
		
		return nums3;	
	}
	public static void main(String[] args) 
	{
		Cretn_AdElmtHM();
		Accs_RtrvHM();
		ItrHM();
	}
}
