package hHashMapExs;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class Country
{
	String str;
	HashMap<String,String> placeList= new HashMap();
	Set<String> keyset=placeList.keySet();
	Collection<String> w=placeList.values();
	public ArrayList<String> startWith(char startChar) 
	{
		String word=Character.toString(startChar);
		ArrayList<String> a= new ArrayList(keyset);
		char search=startChar;
		for(String ele: a) {
			if(a.contains(word)) 
			{
				System.out.println(ele);
			}
		}
		return a;	
	}
	public String maximumPlaceVisit() {
		int count=0;
//		String str;
		ArrayList<String> a= new ArrayList<String>(keyset);
		for(String str1:a) 
		{
			System.out.println(w+":"+Collections.frequency(a, w));
		}
		return str;
	}
	
/*	 public T maximumPlaceVisit2() 
	 {
	   Map<T, Integer> map = new HashMap<>();

    for (T t : placeList) {
        Integer val = map.get(t);
        map.put(t, val == null ? 1 : val + 1);
    }

    Entry<T, Integer> max = null;

    for (Entry<T, Integer> e : map.entrySet()) {
        if (max == null || e.getValue() > max.getValue())
            max = e;
    }

    return max.getKey();
	 }
*/	 
	
}
public class L1doselect 
{

	public static void main(String[] args) 
	{
		Country obj=new Country();
		obj.placeList.put("India", "Amit");
		obj.placeList.put("USA", "Bob");
		obj.placeList.put("Nepal", "Amit");
		obj.placeList.put("uk", "Steve");
		obj.startWith('U');
		obj.maximumPlaceVisit();


	}

}
