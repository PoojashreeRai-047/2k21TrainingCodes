package sSets;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class Hashssset 
{
	public Hashssset() {System.out.print("Default Constructor");}
	public static  Set<String> CheckNullvAls()
	{
		System.out.println("\n\n**********************Check for null values**********************");
		Set<String> hs1=new HashSet<>();
		
		hs1.add(null);
		hs1.add(null);
		System.out.println(hs1);
		
		hs1.add("first");
		hs1.add("first");
		System.out.println(hs1+"\nSize:"+hs1.size()+"\n Accepts null values but not duplicate values \t");
		
		return hs1;
	}
	public static  Set<String> CheckOrdered()
	{		
		System.out.println("\n\n**********************Check Order**********************");

		Set<String> hs2=new HashSet<>();
		hs2.add("Element1");
		hs2.add("Element3");
		hs2.add("Element4");
		hs2.add("Element10");
		hs2.add("Element2");
		hs2.add("Element5");
		System.out.println(hs2+"\nits ordered and in descending\nwhen it has integer values \n");
		
		Set<String> hs3=new HashSet<>();
		hs3.add("A");
		hs3.add("V");
		hs3.add("O");
		hs3.add("I");
		hs3.add("D");
		hs3.add("S");
		System.out.println(hs3+"\nits UNordered and elmnts are jumbled \t");
		
		return hs2;
	}
	public static Set<Integer> HSFrmOtherC() 
	{
		System.out.println("\n\n**********************Creating Hash map from existing**********************");

//		Set<Integer> Evn5=new HashSet();
		List<Integer> Evn5=new ArrayList();
		Evn5.add(2);
		Evn5.add(4);
		Evn5.add(6);
		Evn5.add(8);
		Evn5.add(10);
		System.out.println(Evn5);
		
		Set<Integer> Evn10=new HashSet(Evn5);
		System.out.println(Evn10);
		
		Set<Integer> Next5=new HashSet();
		Next5.add(12);
		Next5.add(14);
		Next5.add(16);
		Next5.add(18);
		Next5.add(20);
		System.out.println(Next5);
		
		System.out.println(Evn10);
		Evn10.addAll(Next5);
		
//		System.out.println(Evn10.addAll(Next5)); returns true after adding the collection
		System.out.println(Evn10);

		
		return Evn10;
	}
	public static Set<Integer> RmvElmnts()
	{
		System.out.println("\n\n**********************Removing Elements**********************");

		Set<Integer> n1=new HashSet();
		for(int i=1;i<=10;i++) {n1.add(i);}
		System.out.println("n1 list:"+n1);
		
		Set<Integer> n2=new HashSet();
		for(int i=2;i<=10;i++) {if(i%2==0) {n2.add(i);}}
		System.out.println("n2 list:"+n2);
		
		//remove obj
		System.out.println(n1.remove(9) +"\n n1 list:"+ n1);
		//remove all ie collection from other collection
		System.out.println(n1.removeAll(n2) +"\n n1 list:"+ n1);
		//clear()
		n1.clear();
		System.out.println("\n n1 list:"+ n1);

		return n2;	
	}
	public static Set<Integer> IterationElmnts()
	{
		System.out.println("\n\n**********************Iteration of elements**********************");

		Set<Integer> s1=new HashSet<>();
		for(int i=0;i<=10;i++) {s1.add(i);}
		System.out.println(s1);
		
		//Basic Loop with Iterator
		System.out.println("Basic Loop with Iterator---------");
		for(Iterator<Integer> itr=s1.iterator();itr.hasNext();) 
		{
			int i= itr.next();
			System.out.println(i);
		}
		
		//While Loop with Iterator
		System.out.println("While Loop with Iterator---------");
		Iterator<Integer>itr=s1.iterator();
		while(itr.hasNext()) 
		{
			int i= itr.next();
			System.out.println(i);
		}
		
		//Enhanced For Loop
		System.out.println("Enhanced For Loop---------");
		for(Integer elmnt: s1) {System.out.println(":: "+elmnt+" ::");}
		
		//ForEach() with LambdaExpression
		System.out.println("ForEach() with LambdaExpression---------");
		s1.forEach(i ->{System.out.println(i);});
		
		//Streams With ForEach() and LambdaExpression
		System.out.println("Streams With ForEach() and LambdaExpression---------");
		s1.stream().filter(i-> !(i%2==0)).forEach(i->{System.out.println(i);});
//		                       !"Java".equals(i)  
//		                if  object is of string type
		
		return s1;	
	}
	public static void main(String[] args) 
	{
		CheckNullvAls();
		CheckOrdered();
		HSFrmOtherC();
		RmvElmnts();
		IterationElmnts();
	}
}
