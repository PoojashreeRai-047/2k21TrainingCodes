package Day4;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class filenm
{
	filenm()
	{
	String str="^.*.(jpg|java|class|JPG|gif|GIF|doc|DOC|pdf|PDF)$";
	Pattern extnPtrn = Pattern.compile(str);
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter your Filename with extension:");
	String t=sc.next();
	
	Matcher u = extnPtrn.matcher(t);
	System.out.println("Does the Filename Extension  matches:"+u.matches());
	}
}
public class FilExt 
{
	public static void main(String[] args) 
	{
		filenm f = new filenm();
	}
}
