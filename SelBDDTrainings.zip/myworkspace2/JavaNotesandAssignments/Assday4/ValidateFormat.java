package Day4;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class Valf
{
	Valf()
	{
		
			//String e ="^[0-3]+[0-9]"	+ "/[0-1]+[0-2]/"+ "[0-2]+[0-9]+[0-9]+[0-9]$";   20[0-1][0-9]|202[0-1] 
			
			String e="^(0[1-9]|1[0-9]|2[0-9]|3[0-1])-(0[1-9]|1[0-2])-(19[0-9][0-9][0-9]|202[0-2])$";
	    	Pattern q = Pattern.compile(e);
	    	
	    	Scanner s=new Scanner(System.in);
	    	System.out.println("Enter date:");
	    	String t=s.next();
	    	
			Matcher u = q.matcher(t);
			System.out.println("Does the string matches:"+u.matches());		
	}
}
public class ValidateFormat 
{
	public static void main(String[] args) 
	{
		Valf v = new Valf();
	}
}
