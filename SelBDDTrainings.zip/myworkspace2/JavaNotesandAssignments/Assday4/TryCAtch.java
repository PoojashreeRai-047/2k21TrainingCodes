package Day4;

import java.util.Scanner;

public class TryCAtch {

	public static void main(String[] args) {
		
			// TODO Auto-generated method stub
			try {System.out.println("Check given number is Even number or not");
			Scanner sc = new Scanner(System.in);
			int a;
			String q=null;
			System.out.println("Enter any number");
			a=sc.nextInt();
			
			if(a%2==0) {
				System.out.println("The number is an Even number:--"+q);	
			}
			else
			{
				System.out.println("The number is Not an even number:--"+q);
				
			}}
			catch(NullPointerException e) {
				System.out.println("Can not access an undefined variable value!!!!");
			}
		}

	}


