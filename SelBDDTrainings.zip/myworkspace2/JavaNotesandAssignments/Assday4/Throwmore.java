package Day4;

public class Throwmore 
{
	public static void myMethod() throws ArithmeticException, NullPointerException
	{
	  // Statements that might throw an exception 
		
		int a;
		Object b=null;
		System.out.println(b);
		a=10/0;
		
	}

	public static void main(String args[]) 
	{ 
	  try 
	  {
	    myMethod();
	  }
	  catch (ArithmeticException e) 
	  {
		  System.out.println("artE");
	    // Exception handling statements
	  }
	  catch (NullPointerException e) 
	  {
		  System.out.println("npe");
	    // Exception handling statements
	  }
	}
}
