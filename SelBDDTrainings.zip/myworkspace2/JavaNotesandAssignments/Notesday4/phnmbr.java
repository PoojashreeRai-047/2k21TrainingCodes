import java.util.regex.Matcher;
import java.util.regex.Pattern;

class phn{
	void ph() {
		String n = "([0][4][0]|[+][9][1])[6-9]([0-9]{9})";
		Pattern q = Pattern.compile(n);
    	String t="+918019301925";
		Matcher u = q.matcher(t);
		System.out.println("Does the string matches:"+u.matches());
	}
}
public class phnmbr {

	public static void main(String[] args) {
		
		phn p=new phn();
		p.ph();

	}

}
