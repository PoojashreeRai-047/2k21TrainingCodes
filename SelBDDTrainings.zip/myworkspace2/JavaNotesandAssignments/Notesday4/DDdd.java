import java.util.regex.Pattern;

public class DDdd 
{
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("metacharacters d..."); 
		System.out.println(Pattern.matches("\\d","a"));// false: a is non digit
		System.out.println(Pattern.matches("\\d","1"));// true : digit 0-9
		System.out.println(Pattern.matches("\\d","443"));// false: 443 is more than one digit
		System.out.println(Pattern.matches("\\d","44gfd"));//false
		System.out.println("metacharacters D...");
		System.out.println(Pattern.matches("\\D","a"));// true : only one non digit
		System.out.println(Pattern.matches("\\D","agf"));//false:
		System.out.println(Pattern.matches("\\D","1"));//false:
		System.out.println(Pattern.matches("\\D","443"));//false:
		System.out.println(Pattern.matches("\\D","44gfd"));//false:
		System.out.println("metacharacters D with quatifiers");
		System.out.println(Pattern.matches("\\D*"," "));//true: alphabets more than one or 0
		System.out.println(Pattern.matches("\\D*","adghjkl"));
		System.out.println(Pattern.matches("\\D*","s"));
		System.out.println(Pattern.matches("\\D*","AFDS"));
		System.out.println(Pattern.matches("\\D*","A"));
	}
}
