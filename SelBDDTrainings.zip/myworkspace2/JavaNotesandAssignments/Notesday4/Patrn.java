import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Patrn {

	public static void main(String[] args) {
		Pattern p=  Pattern.compile(".karan...");
		Matcher m = p.matcher("kkarano00");
		System.out.println("Does the string matches:"+m.matches());

		// false (not m or n or o)
		System.out.println(Pattern.matches("[mno]","a"));
		// true (among x or y or z)
		System.out.println(Pattern.matches("[xyz]","x"));
		//false (x and y comes more than once)
		System.out.println(Pattern.matches("[xyz]","yxz"));
		// either it contains d or e or f
		System.out.println(Pattern.matches("[a-z&&[def]]","d"));
		
		
		
		
		
	}

}
