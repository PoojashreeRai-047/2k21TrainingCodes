import java.util.regex.Matcher;
import java.util.regex.Pattern;

class Pas{
	void val() {
		String t = "^[a-zA-Z0-9_.-]+[*\\W]+$";
		//"^[a-zA-Z0-9+_.-]+*\\W+$";
		Pattern p=  Pattern.compile(t);
		
		Matcher m = p.matcher("1234ateerSD@");
		System.out.println("Does the string matches:"+m.matches());

	}
}
public class Paswd {

	public static void main(String[] args) {
		
		Pas u = new Pas();
		u.val();
	}

}
