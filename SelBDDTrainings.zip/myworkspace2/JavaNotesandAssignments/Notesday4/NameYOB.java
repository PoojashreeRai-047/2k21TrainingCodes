import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

 class Nmyb
 {
	void patD() 
	{
		Pattern p=  Pattern.compile("\\D{0,20} \\d{4}");
		Matcher m = p.matcher("Rai Poojashree 1999");
		System.out.println("Does the string matches:"+m.matches());
	}
	void reg() 
	{
		String z ="(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9]).{5,20}$"; 
    	Pattern q = Pattern.compile(z);
		
		
		//Scanner s= new Scanner(System.in);
		//System.out.println("\nEnter your Name and Year Of Birth:");
		//String t= s.next();
		
		String t="Rai Poojashree 1999";
		Matcher u = q.matcher(t);
		System.out.println("Does the string matches:"+u.matches());
	}
}

public class NameYOB 
{
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Nmyb n = new Nmyb();
		n.patD();
		n.reg();	
	}
}
