package Exception;

public class MulCatch {

	public static void main(String[] args) {
		try {
			try {
				int a[]=new int[5];
				a[10]=76;
			}
			catch(ArithmeticException e) {
				System.out.println("Arithmetic Exception");
			}
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("ArrayIndexOutOfBoundsException");
		}
		catch(Exception e) {
			System.out.println("Parent Exception");
		}
		finally {
			System.out.println("This code is executed independent of exceptions");
		}
	}

}
