package Exception;

import java.util.Scanner;

class Usr extends Exception{
	Usr(int x){
		System.out.println(Math.abs(15-x)+" kg: ");
	}
}
public class Usrdfnd {
	void udrd(int w) throws Usr{
		if(w>15) 
			throw new Usr(w);
		else 
			System.out.println("You are ready to fly:");
	}
	public static void main(String[] args) {
		Usrdfnd ob = new Usrdfnd();
		Scanner in= new Scanner(System.in);
		for(int i=0; i<2; i++) {
			try{
				System.out.println("Enter weight of luggage:");
				ob.udrd(in.nextInt());
			}
			catch(Usr u) {
				System.out.println(u);
			}
		}
	}

}
