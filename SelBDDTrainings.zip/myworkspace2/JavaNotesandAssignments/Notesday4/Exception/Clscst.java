package Exception;
class Cls{
	String p;
	Cls(String n1) {
		p=n1;
	}
	public void disp() {
		System.out.println(p);
	}
}
class Child extends Cls{
	String p1;
	Child(String n2){
		super(n2);
		p1=n2;
	}
	public void disp() {
		System.out.println(p1);
}
}
public class Clscst {

	public static void main(String[] args) {
		System.out.println("Class Casting Exception");
		Child c1 = new Child("jai");
		Cls c2 = new Cls("Adi");
		c2=c1;
		c2.disp();
		Cls c3= new Cls("Sai");
		Child c4 = (Child)c3;
	}
}

