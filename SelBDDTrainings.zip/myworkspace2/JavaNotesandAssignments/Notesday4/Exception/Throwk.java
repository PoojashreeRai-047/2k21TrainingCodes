package Exception;
	public class Throwk {
	public static void thrw(int age) {
	if (age<18) { 
		throw  new ArithmeticException("Person is not eligible to vote");
	}
	else {
		System.out.println("Person is eligible to vote!");
	}
	}
	public static void main(String[] args) {
		thrw(13);
		thrw(23);
		System.out.println("End ");
	}

}
