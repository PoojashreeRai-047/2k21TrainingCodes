import java.util.regex.Matcher;
import java.util.regex.Pattern;

class User{
	void Use() {
		String z ="^[A-Za-z]\\w{5,29}$"; 
    	Pattern q = Pattern.compile(z);
    	String t="RaiPooja09876";
		Matcher u = q.matcher(t);
		System.out.println("Does the string matches:"+u.matches());
	}
}
public class Usernm {

	public static void main(String[] args) {
		
		User n = new User();
		n.Use();
	}

}
