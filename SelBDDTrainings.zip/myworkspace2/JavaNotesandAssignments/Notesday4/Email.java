import java.util.regex.Matcher;
import java.util.regex.Pattern;

class Eml
{
	void emll() 
	{
		String e ="^[a-zA-Z0-9+_.-]+@[a-z.-]+$"; 
    	Pattern q = Pattern.compile(e);
    	String t="poojashree.1435@gmail.com";
		Matcher u = q.matcher(t);
		System.out.println("Does the string matches:"+u.matches());
		
		
//		checking compiled pattern "q" and text "t" are matching using 
//		Matcher object "u" 
//		results true if matches
		
	}
}
public class Email 
{
	public static void main(String[] args) 
	{
		Eml e = new Eml();
		e.emll();
	}
}
