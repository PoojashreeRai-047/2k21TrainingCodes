package Day2Ass;
class Specif
{
	protected int a=9,b=8;
	protected void disp() 
	{
		int c=a*b;
		System.out.println(c);
		System.out.println("The variables and methods declared "
				+ "\n as Protected can be accessed inside their own"
				+ "\n packages and outside is with the child class");
	}
}
public class ProAcc {

	public static void main(String[] args) {
		System.out.println("Java Program to Exercise on Protected Access Specifier\n\n");
		int a=10;
		char c='y';
		boolean b= true;
		System.out.println(a+":n:"+b+":n:"+c);
		
		Specif s = new Specif();
		s.disp();	
	}}


