package Day2Ass;
class Speci extends PriAcc
{
	private int a=9,b=8;
	private void disp() 
	{
		int c=a+b;
		System.out.println(c);
		System.out.println("The variables and methods declared "
				+ "\n as Private can be accessed inside their own"
				+ "\n class only not outside class!!!");
	}
}
public class PriAcc 
{
	public static void main(String[] args) 
	{
		System.out.println("Java Program to Exercise on Private Access Specifier\n \n");
		Speci s = new Speci();
//		s.disp();
		System.out.println("the private variables and methods can't be "
				+ "\n accessed even from the parent class");
	}
}
