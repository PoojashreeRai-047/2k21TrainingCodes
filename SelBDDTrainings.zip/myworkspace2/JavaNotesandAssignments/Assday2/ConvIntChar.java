package Day2Ass;

public class ConvIntChar 
{
	public static void main(String[] args) 
	{
		System.out.println("Java Program to Convert value from Int to char\n \n ");
		int a=5,b=66,c=34567;
		char x= (char)a;
		char y= (char)b;
		char z= (char)c;
		System.out.println("A="+a+" Convert Int value to Char "+x);
		System.out.println("B="+b+" Convert Int value to Char "+y);
		System.out.println("C="+c+" Convert Int value to Char "+z);
	}

}
