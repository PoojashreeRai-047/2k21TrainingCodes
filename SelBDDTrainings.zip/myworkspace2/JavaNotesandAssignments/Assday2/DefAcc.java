package Day2Ass;
import java.util.*;
class Specify
{
	void disp() 
	{
		System.out.println("The  execution starts after allocation"
				+ "\nof memory by default for constructor object");
	}
}
public class DefAcc 
{
	public static void main(String[] args) 
	{
		System.out.println("Java Program to Exercise on Default Access Specifier\n\n ");
		Specify s = new Specify();
		s.disp();
	}
}
