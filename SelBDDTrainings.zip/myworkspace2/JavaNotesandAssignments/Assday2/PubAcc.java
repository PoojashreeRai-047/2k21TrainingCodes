package Day2Ass;
class Specifyy
{
	public int a=9,b=8;
	public void disp() 
	{
		int c=a*b;
		System.out.println(c);
		System.out.println("The variables,class and methods "
				+ "\ndeclared as public can be accesed everywhere inside package");
	}
}
public class PubAcc 
{
	public static void main(String[] args) 
	{
		System.out.println("Java Program to Exercise on Public Access Specifier\n\n");
		
		Specifyy s=new Specifyy();
		s.disp();
		
	}

}
