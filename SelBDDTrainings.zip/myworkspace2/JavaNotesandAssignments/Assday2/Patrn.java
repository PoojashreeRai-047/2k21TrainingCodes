package Day2Ass;

import java.util.Scanner;

public class Patrn 
{
	public static void main(String[] args) 
	{
		System.out.println("Java Program to Print pattern"
				+ "\n  of Right angled triangle with *\n \n");
		int i,j, row=6;
		for(i=0;i<row;i++)
		{
			for(j=0;j<=i;j++)
			{
			System.out.print("*");
			}
			System.out.println(" ");
		}
	}
}
