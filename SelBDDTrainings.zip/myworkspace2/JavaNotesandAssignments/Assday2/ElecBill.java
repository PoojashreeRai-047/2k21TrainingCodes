package Day2Ass;
import java.util.*;
public class ElecBill
{
	public static void main(String[] args) 
	{
		System.out.println("Java Program to Calculate the Electricity bill\n\n");
		int cnum, curunit, prevunit, thismonth,price;
		String cname;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter your CustomerID number:");
		cnum=sc.nextInt();
		System.out.println("Enter your Name:");
		cname=sc.next();
		System.out.println("Enter Previous Month Meter Reading :");
		prevunit=sc.nextInt();
		System.out.println("Enter Current Month Meter Reading : ");
		curunit=sc.nextInt();
		thismonth= curunit - prevunit;
		
		
		if(prevunit<=curunit) 
		{
		price= thismonth*15;
		System.out.println("Your current month consumption is: "+thismonth);
		
		if(thismonth>100) 
		{
			System.out.println("You have to pay extra amout of 500"
					+ "\n Your Bill amount is "+price);
			price+=500;
		
		}
		else if(thismonth>80) 
		{
			System.out.println("You have to pay extra amout of: 400"
					+ "\n Your Bill amount is "+price);
			price+=400;
			}
		else if(thismonth>60) 
		{
			System.out.println("You have to pay extra amout of: 300"
					+ "\nYour Bill amount is "+price);
			price+=300;
			}
		else if(thismonth>40) 
		{
			System.out.println("You have to pay extra amout of: 200"
					+ "\nYour Bill amount is "+price);
			price+=200;
			}
		else if(thismonth>20) 
		{
			System.out.println("You have to pay extra amout of :100"
					+ "\nYour Bill amount is "+price);
			price+=100;
			}
		else if(thismonth>10) 
		{
			System.out.println("You have to pay extra amout of :50"
				+ "\nYour Bill amount is "+price);
			price+=50;
			}
		else 
		{
			System.out.println("Congratulation you don't have to pay any extra amount!!!");
		}
		
		System.out.println("Your Total Electricity bill amount is: "+price);
		}
		else
		{
			System.out.println("Current Month Meter Reading Should be equal or \nmore than Previous Month Meter Reading");
		}
	}
}
