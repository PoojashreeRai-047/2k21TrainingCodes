package Day2Ass;
import java.util.*;
public class Squarestar 
{
	public static void main(String[] args) 
	{
		System.out.println("Java Program to print a square pattern of stars*\n\n");
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the length of square to print: ");
		int s=sc.nextInt();
	
		for(int i=0;i<s;++i) 
		{
			for(int j=1;j<s;++j) 
			{
				System.out.print("*");
			}
			System.out.println("*");
		}
		
		
/*		for(int i=0; i<=s;i++) 
		{
			for(int j=0; j<=s;j++) 
			{
			System.out.print("*");
			}
			System.out.println("*");
		}	
*/
	}

}
