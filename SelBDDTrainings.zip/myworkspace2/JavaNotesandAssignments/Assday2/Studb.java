package Day2Ass;
import java.util.*;
import java.lang.*;

public class Studb 
{
	public static void main(String[] args) 
	{
		System.out.println("Java Program to Create and print "
				+ " the Student Database\n\n");
		int i,n;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter number of Student Records you wish to include:\n");
		i=sc.nextInt();
		n=0;
		
		do 
		{ 
			String name;
			System.out.println("Enter Name of Student: ");
			name =sc.next();
			
			int id, mrx1,mrx2,mrx3,avg,total,percentage;
			float q;
			char grade;
			
			System.out.println("Enter the Student ID: ");
			id=sc.nextInt();
			System.out.println("Enter the Student marks in Subj1: " );
			mrx1=sc.nextInt();
			System.out.println("Enter the Student marks in Subj2: ");
			mrx2=sc.nextInt();
			System.out.println("Enter the Student marks in Subj3: ");
			mrx3=sc.nextInt();
			
			total= mrx1+mrx2+mrx3;
			avg= (total)/3;
			q=avg/10;
			
			System.out.println("The details of student saved are:\n" );
			System.out.println(
					"Student Name :"+name+"\n"+
			        "Student  ID  :"+id+"\n"+
					"Subj1  marks :"+mrx1+"\n"+
					"Subj2  marks :"+mrx2+"\n"+
					"Subj3  marks :"+mrx3+"\n"+
					"Total  marks :"+total+"\n"+
					"Average marks:"+avg
					);
			percentage=Math.round(q);
			
			switch (percentage) 
			{
			case 9:
				System.out.println("Grade: O\n");
				break;
			case 8:
				System.out.println("Grade: A\n");
				break;
			case 7:
				System.out.println("Grade: B\n");
				break;
			case 6:
				System.out.println("Grade: C\n");
				break;
			case 5:
				System.out.println("Grade: D\n");
				break;
			case 4:
				System.out.println("Grade: E\n");
				break;
				default :
		          System.out.println("Grade: FAIL\n");
			}
			
			
			n++;
		}while(n!=i);
		
		System.out.println("\n"+i+" number of Student Records are saved.");
		
	}
}
