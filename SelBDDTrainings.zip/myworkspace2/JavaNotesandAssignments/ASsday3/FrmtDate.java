package Day3Assgn;

import java.time.*;
import java.time.format.DateTimeFormatter;
public class FrmtDate 
{
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Java program to Format Date: ");
		LocalDate date = LocalDate.now();
		System.out.println(date+"\n");
		
		ZonedDateTime zoneDateTime = ZonedDateTime.now();
//		System.out.println(zoneDateTime);
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MM yyyy");
		System.out.println(formatter.format(zoneDateTime));
		
		DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		System.out.println(formatter2.format(zoneDateTime));
		
		DateTimeFormatter formatter3 = DateTimeFormatter.ofPattern("MMM dd yyyy");
		System.out.println(formatter3.format(zoneDateTime));
	}

}

