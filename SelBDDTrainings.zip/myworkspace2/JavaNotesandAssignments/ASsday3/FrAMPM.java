package Day3Assgn;
import java.util.Date;
import java.text.SimpleDateFormat;
public class FrAMPM 
{
	public static void main(String[] args)
    {
		System.out.println("Java program to Convert time to Am Pm format");
		Date date = new Date();
	    System.out.println("Current Time is : " + date);
	    
	    SimpleDateFormat formatTime = new SimpleDateFormat("hh.mm aa");
	    String time = formatTime.format(date);
	    System.out.println("Current Time in AM/PM Format is : " + time);
	}
}