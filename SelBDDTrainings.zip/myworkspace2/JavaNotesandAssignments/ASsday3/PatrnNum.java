package Day3Assgn;

import java.util.Scanner;

public class PatrnNum 
{
	public static void main(String[] args) 
	{
		System.out.println("Java Program to Print pattern"
				+ "\n  of Right angled triangle with numbers\n \n");
		int i,j,n;
		System.out.print("Enter number of rows : ");
		Scanner in = new Scanner(System.in);
	    n = in.nextInt();
        for(i=1;i<=n;i++)
		   {
			for(j=1;j<=i;j++) 
			 {
			  System.out.print(j+" ");
			  }
		    System.out.println("");
		   }
}
}