package Day3Assgn;

public class TrimWsp 
{
	public static void main(String[] args) 
	{
		System.out.println("Java program to Trim the whitespaces in the String:\n");
		String s1="   abc def ghi jkl mno    pq r st    u";
		System.out.println(s1);
		System.out.println(s1.stripLeading());
		System.out.println(s1.replaceAll("\\s", ""));
		System.out.println(s1.replaceAll(" ", ""));
	}
}