package Day3Assgn;
class Root
{
    int a=1;
}
class P1 extends Root
{ 
    int b= 2;
}
class P2 extends Root
{ 
    int c=3; 
}
class C1 extends P1
{
    int d=4; 
    void s1() 
    {
  	  System.out.println(a+"\n"+b+"\n"+d );
  	 }
}
class C2 extends P2
{
    int e=5; 
    void s2() 
    {
    	System.out.println(a+"\n"+c+"\n"+e );
    	}
}
public class HierarInh 
{
	public static void main(String[] args) 
	{
		System.out.println("Java program for Hierarchial Inheritance concept:");
		C1 r = new C1();
		r.s1();
		C2 p = new C2();
		p.s2();
		}
}
