package Day3Assgn;

import java.util.Scanner;

public class Fibonacci
{
	public static void main(String[] args) 
	{
		int n1=0,n2=1,n3,i,count; 
		System.out.println("Java program for Fibonacci series:");
		Scanner s = new Scanner(System.in);
		System.out.println("Enter any number:");
		count=s.nextInt();
		   
		 System.out.print(n1+"\n"+n2+"\n");//printing 0 and 1    
		    
		 for(i=2;i<count;++i)//loop starts from 2 because 0 and 1 are already printed    
		 {    
		  n3=n1+n2;    
		  System.out.print(n3+"\n");    
		  n1=n2;    
		  n2=n3;    
		 }    
		 s.close();
	}
}
