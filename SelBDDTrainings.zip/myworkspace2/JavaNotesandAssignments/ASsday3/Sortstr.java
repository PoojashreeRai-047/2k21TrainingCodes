package Day3Assgn;

import java.util.Arrays;

public class Sortstr 
{
	public static void main(String[] args) 
	{
		System.out.println("Java program to Sort the Array of Strings");
		String[] str={
				        "Zebra", "Yak", "Goat", "Cheetha", 
				        "Elephant", "Lion", "Dog",  "Lamb"
				        };
	    System.out.println(Arrays.toString(str));
	    
		Arrays.sort(str);
		String s=Arrays.toString(str);
		System.out.println("\nAfter sort ="+s);
	}
}