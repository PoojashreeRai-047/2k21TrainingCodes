package Day3Assgn;

public class Revstr
{
	public static void main(String[] args) 
	{
		System.out.println("Java program to Reverse a String ");
		String str="abcdefghijklmnopqrstu", nstr="";
		System.out.println(str);
		
		for (int i=0; i<str.length(); i++)
	      {
	        char ch= str.charAt(i); //extracts each character
	         nstr= ch+nstr; //adds each character in front of the existing string
	      }
	
	      System.out.println("\nReversed word: \n"+nstr);

	}
}
