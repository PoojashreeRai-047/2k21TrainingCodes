package Day3Assgn;

import java.util.Scanner;

public class Palind 
{
	static boolean isPalindrome(String str)
    {
        int i = 0, j = str.length() - 1;
        while (i < j) 
        {
        	// comparing the characters
            if (str.charAt(i) != str.charAt(j))
                return false;
                 i++;     // Increment first pointer
                 j--;     // decrement the other
        }
        return true;
    }

	public static void main(String[] args) 
	{
		System.out.println("Java program for String Palindrome:");
		Scanner s = new Scanner(System.in);
		System.out.print("Enter any String:");
		String str =s.next();
	        
	 
	        if (isPalindrome(str))
	            System.out.print("It is a palindrome");
	        else
	            System.out.print("It is not a palindrome");
	
	        
	    }  
	}
