package pMatrix;

public class Sub {
public static void main(String args[])
{
int rows,cols;
int a[][]= {{4,5,6},{1,2,3},{7,8,9}};
int b[][]= {{0,1,2},{5,6,7},{3,8,9}};
rows=a.length;
cols=a[0].length;
int diff[][]=new int [rows][cols];
for(int i=0;i<rows;i++) {
	for(int j=0;j<cols;j++) {
		diff [i][j]=a[i][j]-b[i][j];
	}
}
System.out.println("Subtraction of two matrixes is");
for(int i=0;i<rows;i++) {
	for(int j=0;j<cols;j++) {
		System.out.print(diff[i][j]+ "");
	}
	System.out.println();
}
}
}
