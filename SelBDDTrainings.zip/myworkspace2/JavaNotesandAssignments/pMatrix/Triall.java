package pMatrix;

public class Triall 
{
	static int a=6;
	static void add(int q)
	{
		System.out.println("alsqla" + a);
		System.out.println("qjlqjkbbb" + q);
	}
	public static void main(String[] args) 
	{
		int b=4;
		add(b);
	}
}
