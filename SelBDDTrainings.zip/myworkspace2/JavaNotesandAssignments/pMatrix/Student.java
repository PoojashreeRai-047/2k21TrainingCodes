package pMatrix;

public class Student {
		int id;
		String name;
		Student(){
			System.out.println("this is the defaukt constructor");
		}
		Student(int i,String n){
			id =i;
			name =n;
		}
		public static void main(String args[]) {
			Student s= new Student();
			System.out.println("/n default constructor values:\n");
			System.out.println("Student id:"+s.id+"\nStudentn Name :"+s.name);
			System.out.println("\nParameterized constructor values:\n");
			Student student=new Student(55,"geetha");
			System.out.println("Student Id: "+student.id+"\nStudent Name"
			+student.name);
		}
	}

