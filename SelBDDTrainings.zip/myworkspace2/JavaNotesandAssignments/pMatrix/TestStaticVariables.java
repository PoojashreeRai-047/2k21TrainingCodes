package pMatrix;
class Students {
	int rollno;
	String name;
	static String college="mahaveer";
	Students(int r,String n){
		rollno=r;
		name=n;
	}
	void display() {
		System.out.println(rollno+" "+name+college);
	}
}
public class TestStaticVariables {

	public static void main(String[] args) {
		Students s1=new Students(255,"GEETHA");
		Students s2=new Students(233,"prabhas");
        s1.display();
        s2.display();
	}

}
