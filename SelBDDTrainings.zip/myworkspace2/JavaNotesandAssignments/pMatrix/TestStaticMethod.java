package pMatrix;
class Studentss{
	int rollno;
	String name;
	static String college="mist";
	static void change() {
		college="aar";
	}
	Studentss(int r,String n){
		rollno=r;
		name=n;
	}
	void display() {
		System.out.println(rollno+" "+name+college);
	}
}
public class TestStaticMethod {

	public static void main(String[] args) {
		Studentss.change();
		Studentss s1 = new Studentss(111,"geetha");
		Studentss s2= new Studentss(222,"pooja");
		Studentss s3=new Studentss(333,"shisha");
		s1.display();
		s2.display();
		s3.display();

	}

}
