package pMatrix;

public class StringExample {

	public static void main(String[] args) {
		String first="java";
		String second="python";
		String third="javascript";
		System.out.println(first);
		System.out.println(second);
		System.out.println(third);// TODO Auto-generated method stub

	}

}
