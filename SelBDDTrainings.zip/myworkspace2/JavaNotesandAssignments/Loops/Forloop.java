
public class Forloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
int i;
for (i=5; i<15; i++) {
	System.out.println(i);
}
++i;
System.out.println(i);
	}

}
