class Student{
	int rollno;
	String name;
	static String clg="srm";
	static String dept="it";
	static void change() {
		clg="snsct";
	}
	Student(int r, String n){
		rollno=r;
		name=n;
	}
	void display() {
		System.out.println(rollno +" "+name+" "+clg+" "+dept);
	}
}
public class Staticcc {

	public static void main(String[] args) {
		Student.change();//calling a static method
		Student s1 = new Student(111,"Karan");
		Student s2 = new Student(112,"Arjun");
		Student s3 = new Student(113,"Karthik");
		
		s1.display();
		s2.display();
		s3.display();
	}

}
