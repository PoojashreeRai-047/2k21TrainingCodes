
public class Whileloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i=9;
while(i<14) {
	
	System.out.println(i);
	++i;
}
++i;
System.out.println(i);
	}

}
