
public class Dowhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i=10;
do {
	System.out.println("the value of i is: "+i);
	i++;
}while(i<15);

	}

}
