
public class Strhndl {

	public static void main(String[] args) {
		String str = "It is a string literal";// string literal
		char ch[]= {'s','u','n','d','a','y'};//using char data type
		String s = new String("String using new keyword");
		String str1= new String(ch);//converting char to String type
		System.out.println(str);
		System.out.println(s);
		System.out.println(str1);
		// String class function
		int length = str.length();// to find the length of the string
		String concat= str1.concat(str);// to concatenate 2 strings
		boolean b= str1.equals(str);// to check if both strings are equal
		String lower = str.toLowerCase();// to convert to lower case 
		String upper = str.toUpperCase();// to convert to upper case
		boolean b1 = str.contains("string");// to check given string contains "string"
		System.out.println(str.substring(4,9));
		System.out.println(s.trim());
		System.out.println(s.startsWith("String"));
		System.out.println(s.hashCode());// converts to hash code value
		System.out.println(str1.isBlank());// true if contains only whitespace or blank
		System.out.println(str.isEmpty());// true if length is 0
		System.out.println(s.charAt(9));
		System.out.println(s);
		System.out.println(str);
		System.out.println(str1);
	}

}
