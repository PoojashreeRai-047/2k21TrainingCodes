package Day6;

import java.util.TreeSet;

class Terer{
	Terer(){
		TreeSet ts = new TreeSet();
		ts.add("one");
		ts.add("two");
		ts.add("three");
		ts.add("four");
		ts.add("five");
		ts.add("six");
		ts.add("seven");
		ts.add("eight");
		System.out.println("TreeSet:"+ts+"\n");
		System.out.println("No.of elements in TreeSet:\nSize of Treeset="+ts.size()+"\n");

	}
}
public class TreeSt {

	public static void main(String[] args) {
		System.out.println("Java Program to get size of TreeSet:\n");
		Terer t =new Terer();
	}

}
