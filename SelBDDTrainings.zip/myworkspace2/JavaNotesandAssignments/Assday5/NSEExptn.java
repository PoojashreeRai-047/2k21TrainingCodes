package Day6;

import java.util.ArrayList;
import java.util.*;
import java.util.Iterator;

class Nse{
	void Nse()throws NoSuchElementException
	{
		ArrayList<String> s= new ArrayList<String>();
		s.add("Reliable");
		s.add("Security");
		s.add("Polymorphism");
		s.add("Abstraction");
		s.add("Reusabillity");
		s.add("Objects");
		
		Iterator itr = s.iterator();
		System.out.println(itr.next());
		System.out.println(itr.next());
		System.out.println(itr.next());
		System.out.println(itr.next());
		System.out.println(itr.next());
		System.out.println(itr.next());
		itr.next();
		throw new  NoSuchElementException();
		
	}
}
public class NSEExptn {

	public static void main(String[] args) {
		System.out.println("Java Program for NoSuchElementException\n\n");
		Nse n=new Nse();
		try {
			n.Nse();
		}
		catch( NoSuchElementException e)
		{
			System.out.println("\nThe catch block has caught the NoSuchElementException .");
		}
	}

}
