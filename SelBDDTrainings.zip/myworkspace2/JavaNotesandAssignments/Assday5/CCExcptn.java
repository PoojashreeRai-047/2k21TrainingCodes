package Day6;
class A{
	int a = 3;
	A(int r){
		r=a;
	}
	public void dis() {
		System.out.println("From Parent Class A\n"+a);
	}
}
class B extends A{
	int b=5;
	B(int r2){
		super(r2);
		b=r2;
		System.out.println("From Parameterized  Constructor of Child Class B:\n");
	}
	public void dis() {
		System.out.println("From dis method of Child Class B:\n"+b);
	}
	void casst() throws ClassCastException {
		A d2 = new A(9);
		B c2 = (B)d2;
		System.out.println("From casst method of B class:\n");
		throw new ClassCastException();
	}
}
public class CCExcptn {

	public static void main(String[] args) {
		System.out.println("Java Program for ClassCastException\n\n");
		B c =new B(4);
		A d= new A(5);
		
		d=c;
		d.dis();
		try {
			System.out.println("From TRY block  of CCExcptn Class :\n");
		c.casst();
		}
		catch(ClassCastException e) {
			System.out.println("The catch block has caught the ClassCastException .");
		}
	
	}

}
