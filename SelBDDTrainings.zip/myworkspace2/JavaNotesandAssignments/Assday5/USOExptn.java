package Day6;

import java.awt.List;
import java.util.ArrayList;
import java.util.Collections;

class Uso{
	void uso() throws UnsupportedOperationException {
		
		ArrayList al=new ArrayList();
		al.add('a');
	     al.add('b');
	     List newList = (List) Collections.unmodifiableList(al);
	     
		
	throw new UnsupportedOperationException();}
}
public class USOExptn {

	public static void main(String[] args) {
		System.out.println("Java Program for UnsupportedOperationException\n\n");
		Uso u =new Uso();
		try {
			u.uso();
		}
		catch(UnsupportedOperationException e) {
			System.out.println("The catch block has caught the UnsupportedOperationException .");
		}
	}

}
