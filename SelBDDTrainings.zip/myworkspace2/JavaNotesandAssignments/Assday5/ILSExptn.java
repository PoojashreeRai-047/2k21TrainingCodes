package Day6;

import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

class Ecpt {
	Ecpt(){
		System.out.println("From Default Constructor of Ecpt class:\n");
	}
	void Exc() throws  IllegalStateException{
		System.out.println("From Exc method of Ecpt class:\n");
		List list = new LinkedList();
		list.add("A");
		list.add("B");
		list.add("C");
		list.add("D");
		list.add("E");
		
		ListIterator lit=list.listIterator();
		lit.next(); System.out.println(list);
		lit.remove();System.out.println(list);
		lit.set("F");System.out.println(list);
		System.out.println(list);
		
		
		throw new IllegalStateException();}
}
public class ILSExptn {

	public static void main(String[] args) {
		System.out.println("Java Program for IllegalStateException\n\n");
		Ecpt x = new Ecpt();
		
		try {
			x.Exc();
		}
		catch(IllegalStateException e) {
			System.out.println("The catch block has caught the IllegalStateException .");
		} 

	}

}
