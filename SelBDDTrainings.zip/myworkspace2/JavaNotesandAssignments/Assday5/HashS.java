package Day6;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

class Hash{
	Hash(){
		//Creating an Array
		String S[]= {"Aa","Bb","Cc","Dd","Ee"};
		
		//Converting Array to HashSet
		Set Hs= new HashSet(Arrays.asList(S));
		
		S= new String[] {"Zz","Yy","Xx","Ww","Tt"};
		
		Hs.addAll(Arrays.asList(S));
		
		System.out.println("Elements of HashSet = \n"+Hs);
		Hs.clear();
		System.out.println("HashSet after removing all elements: \n"+Hs);
	}
}
public class HashS {

	public static void main(String[] args) {
		System.out.println(" Java Program to remove all elements from hashset\n");
		Hash h=new Hash();

	}

}
