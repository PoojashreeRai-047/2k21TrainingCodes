package Day6;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

class Dat{
	Dat(){
		String timeZone1 = "Asia/Kolkata";
		String timeZone2 = "America/New_York";
		
		LocalDateTime dt = LocalDateTime.now();
		ZonedDateTime fromZonedDateTime = dt.atZone(ZoneId.of(timeZone1));
		ZonedDateTime toZonedDateTime = dt.atZone(ZoneId.of(timeZone2));
		long diff = Duration.between(fromZonedDateTime, toZonedDateTime).toMillis();
		
		System.out.println("difference between timezones is " + diff + " milliseconds");

	}
}
public class Datime {

	public static void main(String[] args) {
		System.out.println("Java program On DATE & TIME");
		Dat d= new Dat();
	}

}
