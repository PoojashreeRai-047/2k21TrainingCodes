package Day6;
import java.util.*;
class Al{
	Al(){
		System.out.println("From Default Constructor of Al class:\n");
		
		// creating Arraylist
		ArrayList<String> arr=new ArrayList();
		// ArrayList<String> arr=new ArrayList<String>();
		ArrayList<String> arr1=new ArrayList<>();
		
		//ADDING THE ELEMENTS
		arr.add("A");
		arr.add("BCD");
		arr.add("EFGHI");
		arr.add("J");
		arr.add("KLM");
		arr.add("NOP");
		arr.add("QRST");
		
		
		// To retrieve  an element at a specified index
		System.out.println("To retrieve  an element at a specified index:\n Arr[0]= "+arr.get(4)+"\n");
		
		//To search an element in Java List
		System.out.println("To search an element in Java ArrayList:\n ABCD= "+arr.contains("ABCD")+"\n");
		System.out.println("To search an element in Java ArrayList:\n BCD= "+arr.contains("BCD")+"\n");
		
		//To Copy one Arraylist into Another
		System.out.println("To Copy one Arraylist into Another :\n = ");
		Collections.copy(arr, arr1);
		System.out.println("Array1"+arr +"\nArray2"+ arr1);
		
		//To Reverse an Arraylist 
		System.out.println("To Reverse an Arraylist :\n = Array1"+arr);
		Collections.reverse(arr);
		System.out.println("\nReversed Array"+arr);
		
		//To Clone Array list to Another ArrayList
		System.out.println("\nTo Clone Array list to Another ArrayList:\n = "+arr.clone()+"\n");
		
		//To Print all element of ArrayList using the position with Forloop()
		System.out.println("To Print all element of ArrayList using\n the position with Forloop:\n  "+"\n");
		for(int i=0;i<arr.size();i++) {
			System.out.println("Array ["+i+"] = "+arr.get(i));
		}
	}
}
public class ALcls {

	public static void main(String[] args) {
		System.out.println("Java Program For ArrayList:\n\n");
		Al s=new Al();

	}

}
