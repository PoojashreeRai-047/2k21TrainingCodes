package Day6;

import java.util.LinkedList;

class Lisst{
	Lisst(){
		LinkedList<String> lnk =new LinkedList<String>();
		lnk.add("Sankranthi");
		lnk.add("Holi");
		lnk.add("Navami");
		lnk.add("MahashivaRathri");
		lnk.add("Dasara");
		lnk.add("Diwali");
		System.out.println("Linked list: \n"+lnk+"\n");
		
		lnk.add(3, "Republic day");
		System.out.println("Linked list after inserting the element: \n"+lnk+"\n");
		
	}
}
public class LLst {

	public static void main(String[] args) {
		System.out.println("Java Program to Insert an element at specified position\n");
		
		Lisst l =new Lisst();

	}

}
