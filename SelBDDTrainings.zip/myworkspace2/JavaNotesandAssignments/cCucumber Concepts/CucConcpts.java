package cCucumber;

class Cucy
{
	public Cucy() 
	{
		System.out.println("Creation POM in maven prjct: TestNG or JUnit5\r\n"
				+ "with pkgs  & classes\r\n"
		   +"main/java pkg"
				+ "\r\n"
				+ "       pageObjs\r\n"
				+ "            Elements.java\r\n"
				+ "       utilities\r\n"
				+ "            DriverInitializer.java\r\n"
				+ "            ExcelReader.java\r\n"
				+ "            data.properties\r\n"
			+"test/java pkg\n"
				+ "       cucOptions\r\n"
				+ "            TestRunner.java\r\n"
				+ "       feature file\r\n"
				+ "            gerkhin.feature\r\n"
				+ "       stepdefinitions\r\n"
				+ "            StepDefiner.java");
	}
	public void TestRunner() 
	{
		System.out.println("\nTestRunner: \nin TestRunner add (featurefile & stepdefinition) pkgs");
		gerkhin_feature();
		StepDefiner();
	}
	public void gerkhin_feature() 
	{
		System.out.println("\ngerkhin_feature:\nin feature file add gerkhin content --> run TR\r\n"
				+ "");
	}
	public void StepDefiner() 
	{
		System.out.println("\nStepDefiner:\ncopy the ()s from console output & \r\n"
				+ "paste @ StepDefiner by replacing @Test()"+"");
		Elements();
		DriverInitializer();
		ExcelReader();
	}
	public void Elements() 
	{
		System.out.println("\nElements:\nAll the WebElements and their Methods");		
	}
	public void DriverInitializer() 
	{
		System.out.println("\nDriverInitializer:\nbrowser and url are set from  data properties");
		Inputdata_properties();
	}
	public void ExcelReader() 
	{
		System.out.println("\nExcelReader:\nThe Excel file is read for data");
	}
	public void Inputdata_properties() 
	{
		System.out.println("\nInputdata_properties:\nBrowser name and url are given");
	}	
}


public class CucConcpts 
{
	public static void main(String[] args) 
	{
		Cucy u = new Cucy();
		u.TestRunner();	
	}
}
