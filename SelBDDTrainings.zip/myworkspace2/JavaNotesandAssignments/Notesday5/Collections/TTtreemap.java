package Collections;
import java.util.*;
class Ttone{
	Ttone(){
	
	}
	//Method1
	//To show TreeMap Constructor
	static void ExConst(){
		//Creating an empty TreeMap
		TreeMap<Integer,String> tm = new TreeMap<Integer,String>();
		
		//Mapping string values to int keys
		//using put() method
		
		tm.put(10, "This");
		tm.put(15, "is");
		tm.put(20, "a");
		tm.put(25, "TreeMAp");
		tm.put(300, "Example");
		
		//printing the elements of treemap
		System.out.println("TreeMap: "+tm);
		
	}
}
public class TTtreemap {
	//methd 2
	//main driver method
	public static void main(String[] args) {
		System.out.println("TreeMap using: "+"Treemap() constructor:\n");
		Ttone t = new Ttone();
		t.ExConst();

	}

}
