package Collections;
import java.util.*;
class setEx{
	void setExa() {
		// Creating an object of Set Class
		//Declaring object of Integer type
		Set<Integer> a = new HashSet<Integer>();
		
		// Adding all elements to list
		a.addAll(Arrays.asList(new Integer[] {1,3,2,4,8,9,0}));
		
		//again declaring object of Set class
		// with reference to HashSet 
		Set<Integer> b = new HashSet<Integer>();
		b.addAll(Arrays.asList(new Integer[] {1,3,7,5,4,0,7,5}));
		
		//to find union
		Set<Integer> union = new HashSet<Integer>();
		union.addAll(b);
		System.out.println("Union of the two set:");
		System.out.println(union);
		
		//to find  intersection 
		Set<Integer> intersection = new HashSet<Integer>();
		intersection.retainAll(b);
		System.out.println("Intersection of the two set:");
		System.out.println(intersection);
		
		//to find the Symmetric difference
		Set<Integer> symDiff = new HashSet<Integer>();
		symDiff.removeAll(b);
		System.out.println("Symmetric difference of the two set:");
		System.out.println(symDiff);
	}
}
public class SsetDup {
	//Main driver method
	public static void main(String[] args) {
		setEx s = new setEx();
		s.setExa();

	}

}
