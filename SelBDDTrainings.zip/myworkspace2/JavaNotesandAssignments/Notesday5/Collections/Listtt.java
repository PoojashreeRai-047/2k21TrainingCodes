package Collections;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
 class RegExList {
	 RegExList(){
		 List<String> list = new ArrayList<String>();
		 list.add("preethichandpattapagalu@gmail.com");
		 list.add("preethichandpattapagalu012@gmail.com");
		 list.add("preethichandpattapagalu.369@gmail.com");
		 list.add("preethichandpattapagalu@yahoo.com");
		 list.add("@gmail.com");
		 list.add("preethichand.ug@gmail.com");
		 list.add("preethichandpattapagalu#gmail.com");
		 String regex = "^[A-Za-z0-9._-]+@(.+)$";
		 Pattern pattern = Pattern.compile(regex);
		 for(String lists : list)
		 {
		 	Matcher matcher = pattern.matcher(lists);
		 	System.out.println(matcher.matches());
		 }
	 }
 }
 
public class Listtt {

	public static void main(String[] args) {
		RegExList re = new RegExList();

	}

}
