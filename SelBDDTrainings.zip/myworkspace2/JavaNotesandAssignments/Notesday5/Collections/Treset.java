package Collections;

import java.util.TreeSet;
import java.util.*;
class Tset{
	void settt() {
		TreeSet<String> ts = new TreeSet<String>();
		TreeSet<String> ts1 = new TreeSet();
		ts.add("Orange");
		ts.add("Apple");
		ts.add("12345");
		ts.add("Mango");
		ts.add("Pear");
		ts.add("Amla");
		Iterator itr= ts.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println(ts.lower("Mango"));
		System.out.println(ts.higher("Aplle"));
		System.out.println(ts.ceiling("A"));
		System.out.println(ts.ceiling("Ap"));
		System.out.println(ts.pollFirst());
		System.out.println(ts.pollLast());
		System.out.println(ts.descendingSet());
		
	}
}
public class Treset {

	public static void main(String[] args) {
		// TreeSet class
		System.out.println("Treeset Class");
	    Tset t= new Tset();
	    t.settt();

	}

}
