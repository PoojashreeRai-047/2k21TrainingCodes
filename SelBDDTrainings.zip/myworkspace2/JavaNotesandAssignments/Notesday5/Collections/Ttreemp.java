package Collections;
import java.util.*;

class Tmp{
	void tmap() {
	TreeSet<Integer> set = new TreeSet<>();
	set.add(3);
	set.add(4);
	set.add(3);
	set.add(5);
	
	TreeMap<Integer, Integer> tm =new TreeMap<>();
	tm.put(2, 4);
	tm.put(3, 5);
	tm.put(4, 5);
	tm.put(2, 3);
	System.out.println(set);
	System.out.println(tm);
	}}

public class Ttreemp {

	public static void main(String[] args) {
		Tmp t = new Tmp();
		t.tmap();

	}

}
