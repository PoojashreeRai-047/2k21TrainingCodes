package Collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.*;
public class ArraLst {

	public static void main(String[] args) {
		ArrayList<String> list=new ArrayList<String>();
		list.add("hello");
		list.add("welcome");
		list.add("Regex");
		list.add("good morn");
		list.add("good day");
		System.out.println(list);
		
		int size= list.size();
		System.out.println(size);
		
		Object element= list.get(list.size()-1);
		element = list.get(0);
		System.out.println("Element: "+element);
		
		Collections.sort(list);
		System.out.println("List after Sorting: "+list);
		
		Iterator itr = list.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		element=list.remove(4);
		System.out.println("list after removing 5th element:"+element);
		
		List<String> sub_List= list.subList(0, 3);
		System.out.println("List of first 3 elements"+sub_List);
		
		list.set(2, "all");
		System.out.println(list);
	}

}
