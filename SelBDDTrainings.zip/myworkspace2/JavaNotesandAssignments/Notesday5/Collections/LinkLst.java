package Collections;
import java.util.*;
class LLL{
	LLL(){
		LinkedList<String> list=new LinkedList<String>();
		list.add("hello");
		list.add("Welcome");
		list.add("to java");
		Iterator<String> itr=list.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}

public class LinkLst {

	public static void main(String[] args) {
		LLL l = new LLL();

	}

}
