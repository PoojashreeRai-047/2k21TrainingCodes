package Arrays;
class Fl {
	Fl(){
	int[][] a= {
			{23,65,98,12},
			{67},
			{54,32,87,98,9}
	};
	int[] b= {3,5,7,8,2};
	
	for(int w=0; w<a.length;w++) {
		
			System.out.println("Array a: "+a[w]);}
	
	System.out.println("Array a[0][2]: "+a[0][2]);
	System.out.println("Array a[2][1]: "+a[2][1]);
	for(int q=0; q<a.length;q++) {
		System.out.println("Array B: "+b[q]);
	}
}
	
public class ForLp {

	public static void main(String[] args) {
		Fl f =new Fl();
		}

	}

}
