package Arrays;
class Var{
	Var(String n , int ...b){
		System.out.println(n);
		System.out.println(b);
	}
	Var(int ...a){
		System.out.println(a);
	}
	void m(int ...q){
		System.out.println(q);
	}
}
public class Varrrgs {

	public static void main(String[] args) {
		Var v = new Var("hello",7,5,3,4);
		Var v1 = new Var(5,5,7,8,9,8);
		v.m(44,54);
		v1.m(4,6,2,6,9,4,2,8,1);
	}

}
