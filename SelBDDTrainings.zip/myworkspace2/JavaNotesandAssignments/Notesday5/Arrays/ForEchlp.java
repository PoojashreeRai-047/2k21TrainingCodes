package Arrays;
class Arr{
	Arr(){
		int[] t= {2,7,34,99,2,66,11};
		int[][] s= {
				{43,65,7},
				{23,65,9},
				{3},
				{87,6,3,8,9}};
		System.out.println("Array s[][]:");
		for(int[] T: s) {
			System.out.println("inner Array:");
			for(int ele: T) {
				System.out.println(ele);
				
	}}
		
		System.out.println("Array t[][]:");
		for(int T: t) {
			System.out.println("T Array:");
			
				System.out.println(T);
				}	
	}
}
public class ForEchlp {

	public static void main(String[] args) {
		Arr a =new Arr();
	}}
