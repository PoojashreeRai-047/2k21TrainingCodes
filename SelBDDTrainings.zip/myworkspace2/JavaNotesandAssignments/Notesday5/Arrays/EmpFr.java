package Arrays;

import java.util.Scanner;

class Employee{
	Employee(){
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the no.of Records \n you wish enter:");
		int n=s.nextInt();
		for(int i=0;i<n;i++) {
		System.out.println("\nEnter the Employee ID number:");
		int idno=s.nextInt();
		System.out.println("Enter the Employee Name:");
		String ename=s.next();
		System.out.println("Enter the Department Name of Employee :");
		String deptname=s.next();
		System.out.println("Enter the Employee MONTHLY Salary:");
		int salary=s.nextInt();
		//30 days - [4 sundays+ 2 saturdays (2nd and 4th saturdays)]=24
		int wrkday=24;
		System.out.println("\nTotal Working days :"+wrkday);
		System.out.println("30 days - [4 sundays+ \n2 saturdays (2nd and 4th saturdays)]= 24");
		System.out.println("\nEnter the no.of days you worked in a month:");
		int present=s.nextInt();
		if(present<=wrkday) {
			System.out.println("\nEnter the no.of days you worked OVERTIME in a month:");	
		}
		else {
			System.out.println("Please enter CORRECTLY no.of days you worked in a month :");
		}
		int ovt=s.nextInt();
		int esal=(present+ovt)*(salary/wrkday);
		System.out.println("The Amount of salary to be Credited :Rs."+esal);
		System.out.println("==================================");
		System.out.println("Employee ID number        :"+idno);
		System.out.println("Employee Name             :"+ename);
		System.out.println("Employee Dept Name        :"+deptname);
		System.out.println("Employee Monthly Salary   :"+salary);
		System.out.println("Employee This Month Salary:"+esal);
		System.out.println("==================================");
		}
		System.out.println("-------------\n"+n+" are saved.|"+"\n-------------");
		
	}
}
public class EmpFr {

	public static void main(String[] args) {
		Employee e=new Employee();
	}

}
