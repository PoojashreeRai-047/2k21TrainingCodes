package Arrays;

import java.util.Scanner;

class Sum{
	Sum(){
		Scanner g=new Scanner(System.in);
		System.out.println("enter the size of array:");
		int r=g.nextInt();
		int[] q= new int[r];
		System.out.println("Enter the "+r+" Elements of the array: ");
		for(int i=0;i<r;i++) {
			q[i]=g.nextInt();
		}
		System.out.println("The entered "+r+" Elements of the array are : ");
		for(int i=0;i<r;i++) {
			System.out.println("Q["+i+"] = "+q[i]);
		}
		int Sum=0;
		float Avg=0;
		for(int i=0;i<r;i++) {
			Sum= Sum+q[i];
		}
		Avg=Sum/r;
		System.out.println("\nSum = "+Sum+"\n"+"Average = "+Avg);
	}
}
public class SumAv {

	public static void main(String[] args) {
		Sum s=new Sum();

	}

}
