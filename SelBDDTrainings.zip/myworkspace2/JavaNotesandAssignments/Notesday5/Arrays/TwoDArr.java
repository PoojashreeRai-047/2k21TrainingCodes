package Arrays;
class Td{
	Td(){
		int[][]a= {
				{11,66,98},
				{-7,-56,-585,56},
				{45},
		};
		System.out.println("Array a[][]:");
		for(int[] innerArray: a) {
			System.out.println("inner Array:");
			for(int data: innerArray) {
				System.out.println(data);
			}
		}
	}
}
public class TwoDArr {

	public static void main(String[] args) {
		Td t = new Td();
	}

}
