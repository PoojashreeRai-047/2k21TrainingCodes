package Arrays;
import java.util.Arrays;
class ArrayClass {
ArrayClass()
{ // Get the Array
	int Arr1[] = { 10, 20, 15, 22, 35 };
	int Arr2[] = { 21, 30, 150, 252, 345,1,95 };
	int Arr3[];
	// To print the elements in one line
	System.out.println("Integer Array: "
	+ Arrays.toString(Arr1));

	System.out.println("\nNew Arrays by copyOf:\n");

	System.out.println("Integer Array Copy: "
	+ Arrays.toString(
	Arrays.copyOf(Arr1, 10)));
	System.out.println("Integer Array Range: "
	+ Arrays.toString(
	Arrays.copyOfRange(Arr1, 1, 3)));
	System.out.println("Integer Arrays on comparison: "
	+ Arrays.compare(Arr1, Arr2));
	System.out.println("Integer Arrays on comparison: "
	+ Arrays.equals(Arr1, Arr2));

	Arrays.parallelSort(Arr2);
	System.out.println("Integer Array: "
	+ Arrays.toString(Arr2));

	Arrays.sort(Arr2);
	System.out.println("Integer Array: "
	+ Arrays.toString(Arr2));



}



public class ManpArr {

	public static void main(String[] args) {
		ArrayClass Arc = new ArrayClass();

	}

}}
