package Arrays;

import java.util.Scanner;

class Acc{
	Acc(){
		int[] A = {45,3,4,98};
		int[][] B= {{1,2},{22},{2,3},{4,5}};
		System.out.println("A[0]:"+A[0]);
		System.out.println("A[1]:"+A[1]);
		System.out.println("A[2]:"+A[2]);
		System.out.println("A[3]:"+A[3]);
		System.out.println("B[0][0]:"+B[0][0]);
		System.out.println("B[0][1]:"+B[0][1]);
		System.out.println("B[1][0]:"+B[1][0]);
		System.out.println("B[2][0]:"+B[2][0]);
		System.out.println("B[2][1]:"+B[2][1]);
		System.out.println("B[3][0]:"+B[3][0]);
		System.out.println("B[3][1]:"+B[3][1]);
	}
}
class Acc1{
	Acc1(){
		Scanner sc= new Scanner(System.in);
    	System.out.println("\nEnter the size of array");
    	int n=sc.nextInt();
    	int [] arr = new int [n]; //{5, 2, 8, 7, 1};  
    	System.out.println("Enter the "+n+" Elements of array: ");
    	for(int i=0;i<n;i++) {
    		arr[i]=sc.nextInt();
    	}
    	System.out.print("Array C contains:\n ");
        //Displaying elements of original array  
    	 System.out.println(n+" Elements of array are: ");    
    	   for (int i = 0; i < arr.length; i++) {     
    	       System.out.print(" C["+i+"]="+arr[i] + " \n");    
    	   }    
    	       
	}
}
public class Arac {

	public static void main(String[] args) {
		Acc c= new Acc();
		Acc1 c1= new Acc1();
		
	}

}
