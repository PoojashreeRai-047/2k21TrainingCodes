package Arrays;

import java.util.Scanner;

class Ar1{
	Ar1(){
		Scanner c= new Scanner(System.in);
		System.out.println("Enter the table number to be printed:");
		int n=c.nextInt();
		System.out.println("Enter the number at which table shoul end :\n 10 or 20");
		int t=c.nextInt();
		if(t==10) {
			for(int i=1;i<t;i++) {
				System.out.println(n+" * "+i+" = "+n*i);
			}}
		else if(t==20) {
			for(int i=1;i<t;i++) {
				System.out.println(n+" * "+i+" = "+n*i);
			}}
	}
}
public class Tablemul {

	public static void main(String[] args) {
		Ar1 a= new Ar1();
	}

}
