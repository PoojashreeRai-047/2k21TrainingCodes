package Arrays;

import java.util.Arrays;

class ArrayClas {
ArrayClas()
{ // Get the Array
	int Arr1[] = { 10, 20, 15, 22, 35 };
	int Arr2[] = { 21, 30, 150, 252, 345,1,95 };
	int Arr3[]= {};
	int Arr4[] = {};
	int Arr5[][]= {{789076,1234567},{456,987},{123,124,125}};
	
	// To print the elements in one line
	System.out.println("Integer Array: "
	+ Arrays.toString(Arr1));

	System.out.println("\nNew Arrays by copyOf:\n");

	System.out.println("Integer Array Copy: "+ Arrays.toString( Arrays.copyOf(Arr1, 10)));
	
	System.out.println("Integer Array Range: "+ Arrays.toString( Arrays.copyOfRange(Arr1, 1, 3)));
	System.out.println("Integer Arrays on comparison: "+ Arrays.compare(Arr1, Arr2));
	
	System.out.println("Integer Arrays on comparison: "+ Arrays.equals(Arr1, Arr2));

	Arrays.parallelSort(Arr2);
	System.out.println("Integer Array: "+ Arrays.toString(Arr2));

	Arrays.sort(Arr2);
	System.out.println("Integer Array: "+ Arrays.toString(Arr2));
	// two null arrays are equal = true
	System.out.println(Arrays.compare(Arr3, Arr4));
	
	//hash code of Array5 is printed
	System.out.println(Arrays.hashCode(Arr5));
	
	//sorts the Array
	//System.out.println(Arrays.sort(Arr2));
	//System.out.println(Arrays.fill(Arr4, 0);
	
	
}
}
public class ArrCls {

	public static void main(String[] args) {
		ArrayClas ar=new ArrayClas();

	}

}
