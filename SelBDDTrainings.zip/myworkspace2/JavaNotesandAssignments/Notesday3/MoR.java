class Multi{
	 int mul(int t , int f ) {
		return t*f;
	}
	 int mul(int t , int f, int x ) {
		return t*f*x;
	}
	 double mul(int t , double f ) {
		return t*f;
	}
}
class Mul extends Multi{
	 int mul(int t , int f ) {
		return t*f;
	}
	 int mul(int t , int f, int x ) {
		return t*f*x;
	}
	 double mul(int t , double f ) {
		return t*f;
	}
}

public class MoR {

	public static void main(String[] args) {
		Mul m = new Mul();
		System.out.println(m.mul(3, 5));
		System.out.println(m.mul(5,8,9));
		System.out.println(m.mul(3, 9.5));

	}

}
