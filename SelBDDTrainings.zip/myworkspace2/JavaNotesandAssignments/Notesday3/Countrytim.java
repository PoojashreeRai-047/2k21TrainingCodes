import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class Countrytim {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ZonedDateTime zoneDateTime = ZonedDateTime.now();
		
		ZoneId losAngelsTimeZone = ZoneId.of("America/Los_Angeles");
		ZonedDateTime losAngelsDateTimeZone = zoneDateTime.withZoneSameInstant(losAngelsTimeZone);

		ZoneId dubaiTimeZone = ZoneId.of("Asia/Dubai");
		ZonedDateTime dubaiDateTimeZone = zoneDateTime.withZoneSameInstant(dubaiTimeZone);

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(" HH:mm z yyyy-MM-dd");

		System.out.println("India Time : "+formatter.format(zoneDateTime));

		System.out.println("America Time : "+formatter.format(losAngelsDateTimeZone));
		System.out.println("Dubai Time : "+formatter.format(dubaiDateTimeZone));

		ZoneId zone = ZoneId.systemDefault();
		System.out.println("This system belongs to "+zone+" zone.");
		System.out.println();
		
		System.out.println(zone.getAvailableZoneIds());
		
		System.out.println();
		ZoneId zone1 = ZoneId.of("America/Chicago");
		System.out.println(LocalDateTime.now(zone1));
		System.out.println();
		
		
		ZoneId zone2 = ZoneId.of("Asia/Aden");
		System.out.println(LocalDateTime.now(zone2));
		System.out.println();
		
		ZoneId zone3 = ZoneId.of("America/Cuiaba");
		System.out.println(LocalDateTime.now(zone3));
		System.out.println();
		
		ZoneId zone4 = ZoneId.of("Etc/GMT+9");
		System.out.println(LocalDateTime.now(zone4));
		System.out.println();
		
		ZoneId zone5 = ZoneId.of("Etc/GMT+8");
		System.out.println(LocalDateTime.now(zone5));
		System.out.println();
		
		ZoneId zone6 = ZoneId.of("Africa/Nairobi");
		System.out.println(LocalDateTime.now(zone6));
		System.out.println();
	}

}
