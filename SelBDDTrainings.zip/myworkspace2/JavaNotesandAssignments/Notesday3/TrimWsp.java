
public class TrimWsp {

	public static void main(String[] args) {
		String s1="   abc def ghi jkl mno pq r st u";
		System.out.println(s1);
		System.out.println(s1.stripLeading());
		System.out.println(s1.replaceAll("\\s", ""));
		System.out.println(s1.replaceAll(" ", ""));

	}

}
