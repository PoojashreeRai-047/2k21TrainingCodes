class Parent{
	final void dis() {
		
		System.out.println("Parent class contains final That "
			+ "\ncan not be overriden by child class");}
	
}
 class Childcls extends Parent {
	void disp() {
	
		System.out.println("Child class:"
			+ "\n its parent class can't be declared as final");
	System.out.println("\nA class, declard as final can't be a parent class");}
	

}
 class Chinsof{
	void disp() {
		final int a;
		a=34;
	    //a=42;
		System.out.println("Chkinsof class\n"+a);
		System.out.println("\nA variable, declard as final can't be a changed , stays constant");}
	
}

public class Finalk {

	public static void main(String[] args) {
		Childcls c1 = new Childcls();
		c1.dis();
		c1.disp();
		Chinsof c2= new Chinsof();
		c2.disp();

	}

}
