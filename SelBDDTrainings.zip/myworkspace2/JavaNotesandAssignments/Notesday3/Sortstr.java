import java.util.Arrays;

public class Sortstr {
	public static void main(String[] args) {
String[] str={"Zebra", "Yak", "Goat", "Chittha", 
		"Elephant", "Lion", "Dog",  "Lamb"};
		
		Arrays.sort(str);
		String s=Arrays.toString(str);
		System.out.println();
		System.out.println("After sort ="+s);
	}

}
