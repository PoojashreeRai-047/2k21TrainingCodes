
public class Sta {

 public static void main(String[] args) {
		int a=9;
		int c=a*a;
	System.out.println(c);
	System.out.println("If there is no Public keywords \nError: Main method not found in class Sta, please define the main method as:\r\n"
			+ "   public static void main(String[] args)\r\n"
			+ "or a JavaFX application class must extend javafx.application.Application\r\n"
			+ "");
	System.out.println("If there is no Static keyword\nError: Main method is not static in class Sta, please define the main method as:\r\n"
			+ "   public static void main(String[] args)\r\n"
			+ "");
	System.out.println("If there is no void \n Error : Return type of method is missing");

	System.out.println("If there is no main\n Error: Main method not found in class Sta, please define the main method as:\r\n"
			+ "   public static void main(String[] args)\r\n"
			+ "or a JavaFX application class must extend javafx.application.Application\r\n"
			+ "");
	System.out.println("If there is no String[] args\n Error: Main method not found in class Sta, please define the main method as:\r\n"
			+ "   public static void main(String[] args)\r\n"
			+ "or a JavaFX application class must extend javafx.application.Application\r\n"
			+ "");
	System.out.println("If there is no String[]\n Error: Main method not found in class Sta, please define the main method as:\r\n"
			+ "   public static void main(String[] args)\r\n"
			+ "or a JavaFX application class must extend javafx.application.Application\r\n"
			+ "");
	System.out.println("If there is no args\n Error: Main method not found in class Sta, please define the main method as:\r\n"
			+ "   public static void main(String[] args)\r\n"
			+ "or a JavaFX application class must extend javafx.application.Application\r\n"
			+ "");
	}

}
