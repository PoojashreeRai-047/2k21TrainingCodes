class Mult{
	static int mul(int t , int f ) {
		return t*f;
	}
	static int mul(int t , int f, int x ) {
		return t*f*x;
	}
	static double mul(int t , double f ) {
		return t*f;
	}
}
public class MoL {

	public static void main(String[] args) {
		System.out.println(Mult.mul(3, 5));
		System.out.println(Mult.mul(5,8,9));
		System.out.println(Mult.mul(3, 9.5));

	}

}
