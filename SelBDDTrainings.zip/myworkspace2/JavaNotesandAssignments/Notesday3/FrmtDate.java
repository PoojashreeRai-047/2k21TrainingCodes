import java.time.*;
import java.time.format.DateTimeFormatter;
public class FrmtDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate date = LocalDate.now();
		System.out.println(date);
		ZonedDateTime zoneDateTime = ZonedDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MM yyyy");
		System.out.println(formatter.format(zoneDateTime));
		DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		System.out.println(formatter2.format(zoneDateTime));
		DateTimeFormatter formatter3 = DateTimeFormatter.ofPattern("MMM dd yyyy");
		System.out.println(formatter3.format(zoneDateTime));
	}

}
