 class Par{
	void dis() {System.out.println("Parent class");}
	
}
 class Child extends Par {
	void disp() {System.out.println("Child class");}
	

}
class Chkinsof{
	void disp() {System.out.println("Chkinsof class");}
	
}

public class Insof {

	public static void main(String[] args) {
		Child c1 = new Child();
		c1.dis();
		c1.disp();
		Chkinsof c2= new Chkinsof();
		c2.disp();
		System.out.println(c1 instanceof Child);
		System.out.println(c2 instanceof Chkinsof);
		}

}
