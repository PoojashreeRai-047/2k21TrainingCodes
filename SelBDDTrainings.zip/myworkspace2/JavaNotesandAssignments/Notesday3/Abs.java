abstract class A{
	A(){
		System.out.println("From Abstract class constructor:A ");
	}
	abstract void c();
	void d() {
		System.out.println("From d:method of Abstract class");
	}
}
class B extends A{
	void c() {
		System.out.println("From  class B but declared at \n..abstract class as abstract method:c");
		
	}
}
public class Abs {

	public static void main(String[] args) {
		A obj = new B();
		obj.c();
		obj.d();

	}

}
