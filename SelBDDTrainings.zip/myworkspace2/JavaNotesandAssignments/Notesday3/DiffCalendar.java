import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DiffCalendar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate date=LocalDate.now();
		System.out.println(date);
		 DateTimeFormatter myDateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		 
		 String format = date.format(myDateFormat);
		 System.out.println(format);

	}

}
