class S1{
	int q=33;
	int a=43;
	S1(){
		System.out.println(a+" S1 constructor"); 
	}
	void displ() {
		System.out.println(q+" S1 displ method");
	}
}
class S2 extends S1{
	int q=54;
	int b=65;
	S2(){
		super();
		System.out.println(b+" S2 constructor");
	}
	void disp() {
		super.displ();
		System.out.println(q+" S2 disp method");
		System.out.println(super.a +" S2 disp method");
	}
}

public class Super {

	public static void main(String[] args) {
		S2 s = new S2();
		s.displ();
		s.disp();
	}

}
