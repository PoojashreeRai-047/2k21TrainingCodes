interface Z{
	void d();
}
interface Y{
	default void d() {
		System.out.println("From interface Y def method d: ");
	}
}
class C implements Z,Y{
	public void d() {
		System.out.println("From class C public method d");
	}
}
public class IntrfcMultiple {

	public static void main(String[] args) {
	C c=new C();
	c.d();
	}}
