class Pcon{
	int id;
	String name;
	String dept;
	Pcon(int i, String name1){
		id=i;
		name=name1;
	}
	Pcon(int i, String name1, String d){
		id =i;
		name= name1;
		dept=d;
	}
	void display() {
		System.out.println(name);
	}
}

public class Paracon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pcon pc = new Pcon(11,"Akshay");
		Pcon pc1 = new Pcon(11,"Rajesh","IT");
		pc.display();
		pc1.display();
	}

}
