package org.dateTime.zone;
import java.lang.*;
import java.sql.Date;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.TimeZone;
import java.util.*;

public class DateTime {


public static void main(String[] args) {

LocalDate date = LocalDate.now();
System.out.println(date);



LocalTime time = LocalTime.now();
System.out.println(time);

System.out.println(date.atTime(12, 45, 56, 5432));
System.out.println(date.isLeapYear());



System.out.println(date.getEra());

System.out.println("******************************************");
System.out.println(date.plusDays(3));
System.out.println(date.plusMonths(2));
System.out.println(date.plusYears(1));
System.out.println("******************************************");

//To know to which zone this system displaying date and time
ZoneId zone = ZoneId.systemDefault();
System.out.println(zone);

//to display current date and time of this system
LocalDateTime dateTime = LocalDateTime.now();
System.out.println(dateTime);

//To get all the available zones getAvailableZoneIds()
System.out.println(zone.getAvailableZoneIds());

//To get day, date and year
System.out.println(dateTime.getDayOfMonth());
System.out.println(dateTime.getDayOfWeek());
System.out.println(dateTime.getDayOfYear());
dateTime.atZone(zone);

//To get a particular zone time and date
ZoneId zone1 = ZoneId.of("America/Chicago");
System.out.println(LocalDateTime.now(zone1));
System.out.println(ZonedDateTime.now(zone1));

//System.out.println(date.);

Instant instant1 = Instant.now();
Instant instant2 = Instant.now();
Instant instant3 = Instant.parse("2017-02-03T11:25:30.00Z");
System.out.println(instant3);
System.out.println("After adding 90 days : "+instant3.plus(Duration.ofDays(90)));

System.out.println("After minus 90 days : "+instant3.minus(Duration.ofDays(90)));

System.out.println(instant1);
System.out.println(instant2);

Duration dura = Duration.between(instant1, instant3);
System.out.println("__________________________");

System.out.println(dura);

System.out.println("__________________________");


//Distance = Math.sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1));

System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
//Date to convert one zone to another eg, from IST to US time

//getting current date and time of this system ASIA/CALCUTTA
ZonedDateTime zoneDateTime = ZonedDateTime.now();

//getting America/los_angels time
ZoneId losAngelsTimeZone = ZoneId.of("America/Los_Angeles");
ZonedDateTime losAngelsDateTimeZone = zoneDateTime.withZoneSameInstant(losAngelsTimeZone);

//getting ASIA/DUBAI time
ZoneId dubaiTimeZone = ZoneId.of("Asia/Dubai");
ZonedDateTime dubaiDateTimeZone = zoneDateTime.withZoneSameInstant(dubaiTimeZone);



//printing the date and time in a given format
DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm z");




System.out.println("India Time : "+formatter.format(zoneDateTime));
System.out.println("America Time : "+formatter.format(losAngelsDateTimeZone));
System.out.println("Dubai Time : "+formatter.format(dubaiDateTimeZone));
System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

//To fid the duration between two different zones
Duration duration = Duration.between(losAngelsDateTimeZone, dubaiDateTimeZone);
System.out.println("Duration between America and Dubai : "+duration);


Duration duration1 = Duration.between(losAngelsDateTimeZone, zoneDateTime);
System.out.println("Duration between America and Dubai : "+duration1);

}

}

