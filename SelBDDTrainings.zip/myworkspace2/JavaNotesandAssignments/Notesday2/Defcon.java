class constructEx{
	String str;
	constructEx(String s){
		str=s;
	}
	constructEx(){}
	public void display() {
		System.out.println("The parameterized constructor::"+str);
	}
}
class chi
{
public static void Met(int n) 
{
	for(int i=1;i<=n;++i) 
	{
		int j=1, counter=1;
		while(j<=i) 
		{
			if(i!=counter)
			{
				int p=i-1;
				System.out.print(p+""); ++counter;++j;
			}
			else 
			{System.out.print(j+"");++j; }	
		}	
		System.out.println("");
	}
//	for(int j=1;j<=i;++j) 
//	{
//		if(j>=3) {System.out.print(j+"");--j;}
//		else {System.out.print(j+" ");}
//	}
		
		
		/*
		 * int j=1;int q; 
		 * do { 
		 * for(q=1;q<=j;++q) 
		 * { System.out.print(j+" "); 
		 * j=q;
		 * 
		 * } }while(q<j-1); if(i==1) 
		 * System.out.println(""); 
		 * else System.out.println(j);
		 */
		
	}
}

public class Defcon 
{
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		/*
		 * constructEx ex2 = new constructEx(); constructEx ex = new
		 * constructEx("This is string 1"); constructEx ex1 = new
		 * constructEx("This is string 2"); ex.display(); ex1.display(); ex2.display();
		 */
		chi c=new chi();
		c.Met(5);
	}
}
