class Rectangle{
	int l= 7, b=5;
	 
	void perimeter() {
		int p=2*(l+b);
		System.out.println("The perimeter of  rectangle= " +p);
	}
	void area() {
		int a= l*b;
		System.out.println("The area of  rectangle= " +a);
	}
}


public class Area {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//Rectangle ar= new Rectangle();

//ar.perimeter();
//ar.area();
}

}

