import java.util.Scanner;

public class Switchcase {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a;
		Scanner sc= new Scanner(System.in);
		System.out.println("enter any number");
		a= sc.nextInt();
		switch(a) {
		case 10: 
			System.out.println("The value of a is: "+a);
			break;
		case 20: 
			System.out.println("The value of a is: "+a);
		break;
		case 30: 
			System.out.println("The value of a is: "+a);
		break;
		case 40:
			System.out.println("The value of a is: "+a);
		break;
		default :
          System.out.println("The value of a is: "+a);
		}
	}
}
