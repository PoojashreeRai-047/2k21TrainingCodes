import java.util.Scanner;

public class Nestedif {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b,c;
		Scanner sc= new Scanner(System.in);
		System.out.println("enter any number");
		a= sc.nextInt();
		System.out.println("enter any number");
		b= sc.nextInt();
		System.out.println("enter any number");
		c= sc.nextInt();
		if(a>b){
				
			if(a>c) {
				System.out.println("A is greater: "+a);
			}
			else { 
				System.out.println("C is greater: "+c);
			}
		}
		else {
			if(b>c) {
				System.out.println("B is greater: "+b);	
			}
			else {
				System.out.println("C is greater: "+c);
			}
			
		}
	}

}
