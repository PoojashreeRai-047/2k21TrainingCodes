import java.util.Scanner;
public class If {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b;
Scanner sc= new Scanner(System.in);
System.out.println("enter any number");
a= sc.nextInt();
System.out.println("enter any number");
b= sc.nextInt();
if(a>b) {
	System.out.println("A is greater");	
}
	}

}
