package stepDefinitions;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjects.SpiceJetObjs;
import utilities.DriverInitializer;
import utilities.ExcelReader;

public class StepDefinition extends DriverInitializer
{
	String parent,child;
	SpiceJetObjs EGcard;
	List<String> data;
	
	JavascriptExecutor js = (JavascriptExecutor) driver;
	
	@Before
	public void setup() throws IOException 
	{
		//invoking the getBrowser() from superclass
				this.getBrowser();
				driver.manage().window().maximize();
				driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
				System.out.print("got browser()");
				
				System.out.println("opened the browser");		
				ExcelReader rdEx = new ExcelReader();
				data= rdEx.readExcel() ;
				System.out.println("Reading Excel file");
				System.out.println(data);
				
				EGcard=new SpiceJetObjs(driver);
		System.out.print("Before()");
	}

    @Given("User is on website")
    public void user_is_on_website() throws IOException 
    {
    	//invoking the getUrl() from superclass
    			String url=this.getUrl();
    			driver.get(url);
    			System.out.println("got url");
    	
    }

    @Given("Goto Giftcard page")
    public void goto_Giftcard_page() throws InterruptedException 
    {
    	Thread.sleep(3000);
    	EGcard.getGiftcard().click();
		
		
		//Window Handling using Set of string
				Set<String> windows=driver.getWindowHandles();
				Iterator<String>it=windows.iterator();
				 parent=it.next();
				 child=it.next();
				driver.switchTo().window(child);
				Thread.sleep(3000);
    }

    @When("Goto Congoratulations Card page")
    public void goto_Congoratulations_Card_page() throws InterruptedException
    {
    	Thread.sleep(1000);
    	EGcard.getCongocard().click();
		Thread.sleep(2000);
    }

    @When("select New Job card")
    public void select_New_Job_card() throws InterruptedException 
    {
    	Thread.sleep(3000);
    	JavascriptExecutor js2 = (JavascriptExecutor) driver;

		js2.executeScript("window.scrollBy(0,150)");
		
		EGcard.getNewjob().click();
    }

    @When("fill details")
    public void fill_details() throws InterruptedException, IOException 
    {
    	EGcard.getAmount().sendKeys(data.get(0));
		EGcard.getMsg().sendKeys(data.get(1));
		
		
		EGcard.getQuantity().selectByVisibleText(data.get(2));
		
		
		EGcard.getSendLater().click();
		EGcard.getDateofMonth().click();
		EGcard.getPreviewEGC().click();
		Thread.sleep(3000);
		
		JavascriptExecutor js3 = (JavascriptExecutor) driver;

		js3.executeScript("window.scrollBy(0,240)");
		//Screenshot1
 		File scrnsht1=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
 		FileUtils.copyFile(scrnsht1, new File("./EgiftOutPut.jpg"));
 		System.out.println("jpg done\n********************");
		Thread.sleep(2000);
		EGcard.getClosePrvw().click();
		
		EGcard.getSname().sendKeys(data.get(3));
		EGcard.getSEmail().sendKeys(data.get(4));
		EGcard.getSAdrs1().sendKeys(data.get(5));
		EGcard.getSAdrs2().sendKeys(data.get(6));
		EGcard.getSPinCode().sendKeys(data.get(7));
		
		Thread.sleep(2000);
		
		EGcard.getSCity().sendKeys(data.get(8));
		EGcard.getSstate().sendKeys(data.get(9));
		EGcard.getSMobile().sendKeys(data.get(10));
		
		
		
		EGcard.getRsameAsSender().click();
		
		Thread.sleep(2000);
		
		JavascriptExecutor js4 = (JavascriptExecutor) driver;
		js4.executeScript("window.scrollBy(0,300)");
		EGcard.getAgree().click();
		
		
		EGcard.getPaynow().click();
    }
    


        
        
   
         @Then("Take ScreenShot")
         public void take_ScreenShot() throws IOException, InterruptedException 
         {
        	//Screenshot2
        	 Thread.sleep(6000);
    		File scrnsht2=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
     		FileUtils.copyFile(scrnsht2, new File("./EgiftOutPut.png"));
     		System.out.println("png done\n********************");
     		
         }

	
	
	@After
	public void teardown() throws InterruptedException 
	{
		
		driver.close();
		Thread.sleep(2000);
		driver.switchTo().window(parent);
		driver.close();
		
		
		System.out.print("After()");
	}
}
