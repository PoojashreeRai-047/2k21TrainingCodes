package testCase;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageObjects.SpiceJet;
import utilities.DriverInitializer;
import utilities.ExcelReader;



public class SpicjetEGC_TesTcase extends DriverInitializer
{

	String parent,child;
	SpiceJet EGcard;
	List<String> data;
	
	@BeforeTest
	public void setup() throws IOException
	{
		System.out.println("before()");
		
		
		//invoking the getBrowser() from superclass
		this.getBrowser();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		System.out.println("got browser()");
		
		
		System.out.println("opened the browser");	
		
			
		ExcelReader rdEx = new ExcelReader();
		data= rdEx.readExcel() ;
		System.out.println("Reading Excel file");
		System.out.println(data);
		
		EGcard=new SpiceJet(driver);
		
	}
	
	
	@DataProvider
	Object[][] getData()
	{
		Object[][] daata= new  Object[1][11];
		daata[0][0]=data.get(0) ;
		daata[0][1]=data.get(1) ;
		daata[0][2]=data.get(2) ;
		daata[0][3]=data.get(3) ;
		daata[0][4]=data.get(4) ;
		daata[0][5]=data.get(5) ;
		daata[0][6]=data.get(6) ;
		daata[0][7]=data.get(7) ;
		daata[0][8]=data.get(8) ;
		daata[0][9]=data.get(9) ;
		daata[0][10]=data.get(10) ;
		return daata;	
	}
	
	
	
	
	
	@Test(dataProvider="getData")
	public void test1(
			String rupees, String msg, String quantT,
			String senderName,String senderEmail,String adrs,
			String adrs2,String pincode,String city,
			String state,String phnmbr
			) throws IOException, InterruptedException 
	{
		//invoking the getUrl() from superclass
		String url=this.getUrl();
		driver.get(url);
		System.out.print("got url");
		
		
		EGcard.getGiftcard().click();
		
		//Window Handling using Set of string
		Set<String> windows=driver.getWindowHandles();
		Iterator<String>it=windows.iterator();
		 parent=it.next();
		 child=it.next();
		driver.switchTo().window(child);
		Thread.sleep(2000);

		
		EGcard.getCongocard().click();
		Thread.sleep(2000);
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,150)");
		
		EGcard.getNewjob().click();
		
		EGcard.getAmount().sendKeys(rupees);
		EGcard.getMsg().sendKeys(msg);
		
		
		EGcard.getQuantity().selectByVisibleText(quantT);
		
		
		EGcard.getSendLater().click();
		EGcard.getDateofMonth().click();
		EGcard.getPreviewEGC().click();
		Thread.sleep(3000);
		
		js.executeScript("window.scrollBy(0,240)");
		Thread.sleep(2000);
		//Screenshot1
				File scrnsht1=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrnsht1, new File("./EgiftOutPut.jpg"));
				System.out.println("jpg done\n********************");
		EGcard.getClosePrvw().click();
		
		EGcard.getSname().sendKeys(senderName);
		EGcard.getSEmail().sendKeys(senderEmail);
		EGcard.getSAdrs1().sendKeys(adrs);
		EGcard.getSAdrs2().sendKeys(adrs2);
		EGcard.getSPinCode().sendKeys(pincode);
		
		Thread.sleep(2000);
		
		EGcard.getSCity().sendKeys(city);
		EGcard.getSstate().sendKeys(state);
		EGcard.getSMobile().sendKeys(phnmbr);
		
		
		
		EGcard.getRsameAsSender().click();
		
		Thread.sleep(2000);
		
		EGcard.getAgree().click();
		System.out.println("clickedAgree()");
		
		js.executeScript("window.scrollBy(0,300)");
		EGcard.getPaynow().click();
		Thread.sleep(2000);
		
		//Screenshot2
		Thread.sleep(6000);
		File scrnsht2=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrnsht2, new File("./EgiftOutPut.png"));
		System.out.println("png done\n********************");
		
		
	}
	
	@AfterTest
	public void teardown() throws InterruptedException 
	{
		System.out.print("teardown()");
		
		
		
		driver.close();
		Thread.sleep(2000);
		driver.switchTo().window(parent);
		driver.close();
		
	}

}
