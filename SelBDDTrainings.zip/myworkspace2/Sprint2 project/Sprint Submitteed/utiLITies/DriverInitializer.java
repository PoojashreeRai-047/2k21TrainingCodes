package utiLITies;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DriverInitializer 
{
public WebDriver driver;
	
	public String readDataFile(String data) throws IOException 
	{
		Properties prop=new Properties();
		FileInputStream fis = new FileInputStream("C:\\Users\\poojasra\\eclipse-workspace\\ZZZZ\\data.properties");
		prop.load(fis);
		return prop.getProperty(data);
	}
	
	public String getUrl() throws IOException 
	{
		return this.readDataFile("url");
	}
	
	public void getBrowser() throws IOException 
	{
		String browserName=this.readDataFile("browser");
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojasra\\Documents\\ChromeDriver\\chromedriver.exe");
			driver=new ChromeDriver();
		
	}
}
