package utiLITies;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReadFile
{
	public List<String>readExcel() throws IOException
	{
		FileInputStream file=new FileInputStream("C:\\Users\\poojasra\\eclipse-workspace\\ZZZZ\\ExcelFile\\Rexcel.xlsx");
		Workbook book=new XSSFWorkbook(file);
		int sheets=book.getNumberOfSheets();
		
		List<String>getData=new ArrayList<String>();
		
		//System.out.println("sheet"+sheets);
		Sheet sheet = book.getSheetAt(0);
		Iterator<Row>rows=sheet.iterator();
		
		while(rows.hasNext())
		{
			Row row=rows.next();
			Iterator<Cell>cols=row.cellIterator();
			while(cols.hasNext())
			{
				String data;
				
				Cell value=cols.next();
			
			if(value.getCellType()==CellType.NUMERIC)
			{
				String result =(long)value.getNumericCellValue()+"";
				getData.add(result);
				}
				else
				{
					getData.add(value+"");
				}
			}
		}
	return getData;
	}
}
