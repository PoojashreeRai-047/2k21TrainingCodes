package pageOBJ;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.Select;

public class SjEgc 
{
public WebDriver driver;
	
	
	@FindBy(xpath="//div[contains(text(),'Gift Card')]")
	WebElement  Giftcard;
	
	@FindBy(xpath="//*[text()='Congratulations Gift Card']")
	WebElement  Congocard;
	
	@FindBy(xpath="//img[@id='38893']")
	WebElement Newjob;
	
	@FindBy(xpath="//*[@id=\"funValidateControls\"]/div[1]/div/div[1]/div[5]/div[1]/div/div[1]/div/div[2]/input")
	WebElement Amount;
	
	@FindBy(xpath="//textarea[@placeholder='Your Message:']")
	WebElement Msg;
	
	@FindBy(xpath="//select[@id='quantity']")
	WebElement seloptn;

	
	@FindBy(xpath="//label[contains(text(),'Send Later')]")
	WebElement SendLater;
	
	@FindBy(xpath="//a[normalize-space()='26']")
	WebElement DateofMonth;
	
	@FindBy(xpath="//a[normalize-space()='Preview E-Gift card']")
	WebElement PreviewEGC;
	
	@FindBy(xpath="//a[normalize-space()='×']")
	WebElement ClosePrvw;
	
	@FindBy(xpath="//input[@placeholder=\"Sender's Name *\"]")
	WebElement Sname;
	
	@FindBy(xpath="//input[@placeholder=\"Sender's e-mail Address *\"]")
	WebElement SEmail;
	
	@FindBy(xpath="//input[@placeholder='Address line 1 *']")
	WebElement SAdrs1;
	
	@FindBy(xpath="//input[@placeholder='Address line 2/Landmark']")
	WebElement SAdrs2;
	
	@FindBy(xpath="//input[@placeholder='Enter pincode to fetch city and state *']")
	WebElement SPinCode;
	
	@FindBy(xpath="//input[@placeholder='City*']")
	WebElement SCity;
	
	@FindBy(xpath="//input[@placeholder='State *']")
	WebElement Sstate;
	
	@FindBy(xpath="//input[@placeholder='Mobile Number *']")
	WebElement SMobile;
	
	@FindBy(xpath="//span[@class='hide-for-small-only']//input[@name='userdetails']")
	WebElement Rsas;
	
	@FindBy(xpath="//*[@id=\"paymentSection\"]/div[2]/div/div[2]/div/div[2]/div/small/span/input")
	WebElement Agree;
	
	@FindBy(xpath="//input[@value='PAY NOW']")
	WebElement Paynow;
	
	public SjEgc(WebDriver driver) 
	{
		 AjaxElementLocatorFactory fac = new AjaxElementLocatorFactory(driver,10); 
		  PageFactory.initElements(driver, this);
		//this.driver=driver;
	}
	
	public WebElement getGiftcard() 
	{
		System.out.println("giftcard");
		return Giftcard;
		
	}
	
	public WebElement getCongocard()
	{
		System.out.println("Congocard");
		return Congocard;
	}
	
	public WebElement getNewjob()
	{
		System.out.println("getNewjob()");
		return Newjob;
	}
	
	public WebElement getAmount()
	{
		System.out.println("getAmount()");
		return Amount;
	}
	
	public WebElement getMsg()
	{
		System.out.println("getMsg()");
		return Msg;
		
	}
	
   public Select getQuantity() 
    {     
	   Select quanty = new Select(seloptn);
	   System.out.println("getQuantity()");
       return quanty; 
	}
	 
	
	public WebElement getSendLater()
	{
		System.out.println("getSendLater()");
		return SendLater;
	}
	
	public WebElement getDateofMonth()
	{
		System.out.println("getDateofMonth()");
		return DateofMonth;
	}
	
	public WebElement getPreviewEGC()
	{
		System.out.println("getPreviewEGC()");
		return PreviewEGC;
	}
	
	public WebElement getClosePrvw()
	{
		System.out.println("getClosePrvw()");
		return ClosePrvw;
	}
	
	public WebElement getSname()
	{
		System.out.println("getSname()");
		return Sname;
	}
	
	public WebElement getSEmail()
	{
		System.out.println("getSEmail()");
		return SEmail;
	}
	
	public WebElement getSAdrs1()
	{
		System.out.println("getSAdrs1()");
		return SAdrs1;
	}
	
	public WebElement getSAdrs2()
	{
		System.out.println("getSAdrs2()");
		return SAdrs2;
	}
	
	public WebElement getSPinCode()
	{
		System.out.println("getSPinCode()");
		return SPinCode;
	}
	
	public WebElement getSCity()
	{
		System.out.println("getSCity()");
		return SCity;
	}
	
	public WebElement getSstate()
	{
		System.out.println("getSstate()");
		return Sstate;
	}
	
	public WebElement getSMobile()
	{
		System.out.println("getSMobile()");
		return SMobile;
	}
	
	public WebElement getRsameAsSender()
	{
		System.out.println("getRsameAsSender()");
		return Rsas ; 
	}
	
	public WebElement getAgree()
	{
		System.out.println("getAgree()");
		return Agree ; 
	}
	
	public WebElement getPaynow()
	{
		System.out.println("getPaynow()");
		return Paynow ; 
	}
}
