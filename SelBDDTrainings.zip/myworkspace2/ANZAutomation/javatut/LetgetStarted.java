package com.anz.javatut;

import athtutorial.Beginner;
import athtutorial.Conditioninnng;

public class LetgetStarted 
{
	public static void main(String[] args) 
	{
		System.out.println("Just Got Organized!");
		Beginner b=new Beginner();
		Conditioninnng c=new Conditioninnng();
		
	}
}
