package com.anz.javatut;

public class Datatypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i =10;
char c ='Q';
boolean b= false;
float f= 5;
double d= 3.5489;

System.out.println(c);
System.out.println(b);
System.out.println(f);
System.out.println(d);
System.out.println(i);
	}

}
