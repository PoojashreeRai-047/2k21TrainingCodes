package com.anz.javatut;
import java.util.Scanner;

public class Calsum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Calgetnum g = new Calgetnum();
g.gnr();
	}

}
