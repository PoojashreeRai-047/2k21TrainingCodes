package com.anz.javapract;

public class Day1 
{
	public static void main(String[] args) 
	{
		
	}
}
