package test;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class CodefrmMm 
{
	public void readExcel() throws IOException
	{
	FileInputStream file=new FileInputStream("C:\\Users\\RALAMANI\\Desktop\\capgemini training\\selenium\\practice.xlsx");
	Workbook book=new XSSFWorkbook(file);
	int sheets=book.getNumberOfSheets();
	List<String>getData=new ArrayList<String>();
	Sheet sheet = book.getSheetAt(0);
	Iterator<Row>rows=sheet.iterator();
	while(rows.hasNext())
	{
	Row row=rows.next();
	Iterator<Cell>cols=row.cellIterator();
	while(cols.hasNext())
	{
	String data;
	Cell value=cols.next();
	if(value.getCellType()==CellType.NUMERIC)
	{
	//System.out.println((int)value.getNumericCellValue());
	String result=(int)value.getNumericCellValue()+"";
	getData.add(result);
	}
	else {
	// System.out.println(value);
	getData.add(value+"");
	}
	}
	}

	System.out.println("*******************************************************************************************************************");

	String Arr[][] ;
	Arr= new String[6][7];
	int row=Arr.length;
	int col=Arr[0].length;

	int k=0;
	for(int i=0;i<row;i++)
	{
	for(int j=0;j<col;j++)
	{
	Arr[i][j] = getData.get(k);
	System.out.print(" "+Arr[i][j]+" ");
	k++;
	}

	System.out.println();

	}
	System.out.println("*******************************************************************************************************************");
	int flag=1;
	outerloop:
	for(int i=1;i<row;i++)
	{
	for(int j=0;j<col;j++)
	{
	if(Arr[i][j]=="")
	{
	flag=0;
	System.out.println("student "+Arr[i][1]+" "+Arr[0][j]+" marks are empty");
	break outerloop;
	}


	}

	}
	if(flag==1)
	{
	System.out.println("Excel uploaded");
	}

	}


	public static void main(String args[]) throws IOException{

//	ReadExcel rdd=new ReadExcel();
//	rdd.readExcel();

	}

}
