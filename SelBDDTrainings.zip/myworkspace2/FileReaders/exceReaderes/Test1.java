package test;

import java.io.IOException;
import java.util.List;

import org.junit.*;
import org.junit.Test;


import excel.ReadE;

public class Test1 
{
	List<String> data;
	@Before 
	public void setup() throws IOException 
	{
		System.out.println("Before\n");
		
		ReadE rde= new ReadE();
//		data=rde.readExcel();
//		System.out.println(data);
	}
	@Test
	public void test() 
	{
		System.out.println("Test\n");
		
		System.out.println(data+"\n");
		
		
	}
	@After
	public void teardown()
	{
		System.out.println("After\n");
		
		
		
	}
}
