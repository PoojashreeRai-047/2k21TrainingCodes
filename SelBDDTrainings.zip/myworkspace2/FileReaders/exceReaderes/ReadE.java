package excel;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadE 
{
	public static void main(String[] args) throws IOException
	//	public List<String>readExcel() throws IOException
	{
		FileInputStream file=new FileInputStream("C:\\Users\\poojasra\\eclipse-workspace\\Excel_Validation\\Markslist.xlsx");
		Workbook book=new XSSFWorkbook(file);
		int sheets=book.getNumberOfSheets();
		
		
		Sheet sheet = book.getSheetAt(0);
		Iterator<Row>rows=sheet.iterator();
		int i=0;
		
		List<String> marklist=new ArrayList<String>();
		
		while(rows.hasNext()) 
		{
			Row row = rows.next();
			Iterator<Cell> celit = row.cellIterator();
			
			int r1=row.getRowNum();
			
			
			
			while(celit.hasNext()) 
			{
				Cell cell= celit.next();
				if(i==0)
				{
					switch(cell.getCellType())
					{
					case BLANK:
						System.out.print("\n\n !!The  students list subject marksheet is still empty!!\n");
						i++;
						break;
						
					case NUMERIC:
						System.out.print(cell.getNumericCellValue() + "\t"); 
						String markN = cell.getNumericCellValue()+"";
						marklist.add(markN);
						break;
					case STRING:
						System.out.print(cell.getStringCellValue() + "\t"); 
						String markS = cell.getStringCellValue()+"";
						marklist.add(markS);
						break;
					
					default:
						System.out.print( "\n Students marklist is successfully saved \t"); 
					}
				}
		   	 }
			int r2=row.getRowNum();
			System.out.print("\n");	
		}
//		return marklist;
		int r=6, c=7;
		String MarksArray[][];
		MarksArray= new String[r][c];
		
		
		if(i>0) 
		{
			System.out.print( "\n!!! Please fill completely...!!! \t"); 
		}
		else
		{
			System.out.print( "\n Students marklist is successfully saved \t"); 

		}
	
		
	}
	}
