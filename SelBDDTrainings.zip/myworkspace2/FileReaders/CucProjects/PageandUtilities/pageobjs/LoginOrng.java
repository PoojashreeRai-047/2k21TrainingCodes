package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginOrng 
{
	WebDriver driver;
	
	@FindBy(id="txtUsername")
	WebElement  username;
	@FindBy(id="txtPassword")
	WebElement password ;
	@FindBy(id="btnLogin")
	WebElement  login;
	
	public LoginOrng(WebDriver driver) 
	{
		PageFactory.initElements(driver, this);
	}
	public WebElement getUsername()
	{
		return username;
	}
	public WebElement getPassword()
	{
		return password;	
	}
	public WebElement getLogin()
	{
		return login;
	}
	
}
