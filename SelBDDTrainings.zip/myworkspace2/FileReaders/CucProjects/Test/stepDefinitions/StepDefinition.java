package stepDefinitions;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.*;
import cucumber.api.java.en.*;
import pageobjects.LoginOrng;
import utilities.InitializeDriver;
import utilities.ReadExcelFile;

public class StepDefinition extends InitializeDriver {
	
	
	
	
	LoginOrng login;
	List<String> data;

	@Before
	public void setup() throws IOException 
	{
		this.getBrowser();
		login = new LoginOrng(driver);
		ReadExcelFile exceldata = new ReadExcelFile();
		data = exceldata.readExcel();
		System.out.println("Before Setup()");
	}
	  @Given("User is on the website") public void user_is_on_the_website() throws IOException 
	  { 
		  driver.get(getUrl());
	  
	  // Write code here that turns the phrase above into concrete actions
	  //https://opensource-demo.orangehrmlive.com/
	  //driver.get("https://opensource-demo.orangehrmlive.com/"); //
	  System.out.println("**************@Given*****************"); 
	  }
	  
	 @When("Username entered") public void username_entered() 
	 { 
		 // Write code herethat turns the phrase above into concrete actions
	  login.getUsername().sendKeys(data.get(0)); 
	  System.out.println("**************@When*****************");
	  }
	  
	  @When("password entered") public void password_entered() 
	  { // Write code here that turns the phrase above into concrete actions
	  login.getPassword().sendKeys(data.get(2));
	  System.out.println("**************@When*****************");
	  }

		/*
		 * @When("Username entered and password") public void
		 * username_entered_and_password() { // Write code here that turns the phrase
		 * above into concrete actions login.getUsername().sendKeys(data.get(0));
		 * login.getPassword().sendKeys(data.get(2));
		 * System.out.println("**************@When*****************"); }
		 */
	  @Then("User should login") 
	  public void user_should_login() throws InterruptedException 
	  {
		  // Write code here that turns the phrase above into
	  
	  login.getLogin().click(); Thread.sleep(8000);
	  System.out.println("**************@Then*****************"); 
	  }
	  @After
	public void teardown() 
	  {
		driver.close();
		}
	 
	
	  
	  
	  
	  
	
	  @Given("^I want to write a step with (.+)$") public void
	  i_want_to_write_a_step_with(String name) throws Throwable 
	  {
	  System.out.println("**************@Given*****************");
	  System.out.println("*********"+name+"*******"); }
	  
	  @When("^I check for the (.+) in step$") public void
	  i_check_for_the_in_step(Integer value) throws Throwable {
	  System.out.println("\n**************@When*****************");
	  System.out.println("*********"+value+"*******"); }
	  
	  @Then("^I verify the (.+) in step$") public void i_verify_the_in_step(String
	  status) throws Throwable {
	  System.out.println("\n**************@Then*****************");
	  System.out.println("*********"+status+"*******"); 
	  }
	 
	  
	  
	  
	@BeforeStep(order=1)
	public void bs1()
	{
		System.out.println("Before Step1 ");
	}
	@BeforeStep(order=2)
	public void bs2()
	{
		System.out.println("Before Step2 ");
	}
	
	
	
	
	@Given("User is on the site")
	public void userIsOnTheSite(io.cucumber.datatable.DataTable dataTable) 
	{
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
	    // Map<K, List<V>>. E,K,V must be a String, Integer, Float,
	    // Double, Byte, Short, Long, BigInteger or BigDecimal.
	    //
	    // For other transformations you can register a DataTableType.
		System.out.println(dataTable.asList().get(0));
	    System.out.println(dataTable.asList().get(1));
	    System.out.println(dataTable.asList().get(2));
	}
	
}
