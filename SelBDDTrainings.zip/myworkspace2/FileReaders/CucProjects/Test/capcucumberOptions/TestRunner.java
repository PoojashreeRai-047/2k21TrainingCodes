package capcucumberOptions;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import cucumber.api.SnippetType;




@RunWith(Cucumber.class)
    @CucumberOptions(
          features="src/test/java/features",
          glue={"stepDefinitions"},
          //tags= {"@RegressionTest"},
          strict=false,
         // dryRun=true,
          plugin= {"pretty","html:report","json:json_object/cucumber.json"
        		  ,"junit:test/cucumber.xml"},
          monochrome=true,
          snippets=SnippetType.CAMELCASE
          )
public class TestRunner 
{
// cucpjct\src\test\java\features\login.feature
}
