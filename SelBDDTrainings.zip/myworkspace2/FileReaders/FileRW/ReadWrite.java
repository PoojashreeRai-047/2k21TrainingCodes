import java.io.*;

class Rww{
	void ww() throws IOException {
		FileReader fr= null;
		Writer write= null;
		try
		{
			fr= new FileReader("D:\\File Example\\Sub Folder Ex\\NewTest.tst");
			write= new FileWriter("D:\\File Example\\Sub Folder Ex\\text.tst");
			//Reading SourceFile and writing content to
			//target file character by character
			int temp;
			while((temp=fr.read())!=-1) {
				System.out.println((byte)temp);
			}
		}
		catch( IOException e) {}
	
			finally {
				//Closing stream as no longer in use
				if(fr !=null)
					fr.close();
			}
		}
	}

public class ReadWrite {

	public static void main(String[] args) throws IOException {
		Rww r=new Rww();
		r.ww();
	}

}
